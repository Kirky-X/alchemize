# kueiku — compact edition (2026 Huawei Developer Competition · Xiaohongshu Skill track)

Aggregated packaging of [kueiku](https://github.com/Kirky-X/kueiku) v0.1.16 (MIT): same 19 categories x 156
methodologies, flattened to fit the competition's 30-file / 40MB submission limit.

## Layout

| Path | Role |
| --- | --- |
| `SKILL.md` | agent-facing navigation & calling protocol (unchanged logic) |
| `data/methodologies.tsv` | one row per methodology: category, name, one-line description, best scenario |
| `data/fulltext/<category>.md` | all methodology full text for a category, one `## <name>` section each |
| `scripts/get_methodology.sh` | print one methodology's full text |
| `scripts/kueiku_calc.py` | the 19 computation-heavy automations, merged into one file (same CLI) |

## Usage

```sh
# look up the catalogue
column -t -s $'\t' data/methodologies.tsv | less

# read one methodology
scripts/get_methodology.sh strategy "SWOT"

# run a calculation (same subcommands as upstream scripts/main.py)
python scripts/kueiku_calc.py rice -i items.csv
```

Agents without shell access may equally Read the `## <methodology>` section of
`data/fulltext/<category>.md` directly — the layout is plain text by design.
