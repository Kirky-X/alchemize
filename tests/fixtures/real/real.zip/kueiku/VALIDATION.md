# kueiku calc — merged-file validation
This file exists to keep the competition package auditable: the original 8-module
calculator was merged verbatim into `scripts/kueiku_calc.py` (internal imports
stripped, stdlib imports kept, module order utils->decision->risk->financial->
data->strategy->quant->main). Differential tests against upstream v0.1.16 are
recorded in the submission notes.
