"""kueiku_calc — single-file merge of scripts/{utils,decision,risk,financial,data,strategy,quant,main}.py

(kueiku v0.1.16 compact edition). Usage unchanged:

  python scripts/kueiku_calc.py <subcommand> -i <input.csv> [--json]

"""

# ===== merged from: utils.py =====
"""Utility functions — CSV I/O, formatting, matrix operations, statistical helpers."""

import csv
import io
import math
import sys
from pathlib import Path


# ───────────────────────── I/O Tool ─────────────────────────

def read_csv(source):
    """Read CSV from file path or stdin, return list[dict].

    Exits with a friendly error if the CSV is empty or has no data rows.
    """
    if source == "-" or source is None:
        text = sys.stdin.read()
    else:
        text = Path(source).read_text(encoding="utf-8")
    reader = csv.DictReader(io.StringIO(text))
    rows = [row for row in reader]
    if not rows:
        where = "stdin" if (source == "-" or source is None) else f"'{source}'"
        print(f"Error: CSV input {where} is empty (no header or no data rows).", file=sys.stderr)
        sys.exit(1)
    return rows


def fnum(value, field, row_no):
    """Parse a float from a CSV cell; exit with a friendly error on bad values."""
    try:
        return float(value)
    except (TypeError, ValueError):
        print(f"Error: row {row_no}: invalid number for field '{field}': {value!r} (expected a number)", file=sys.stderr)
        sys.exit(1)


def inum(value, field, row_no):
    """Parse an int from a CSV cell; exit with a friendly error on bad values."""
    try:
        return int(value)
    except (TypeError, ValueError):
        print(f"Error: row {row_no}: invalid integer for field '{field}': {value!r} (expected an integer)", file=sys.stderr)
        sys.exit(1)


def write_output(content, output_path=None):
    """Output to file or stdout."""
    if output_path:
        Path(output_path).write_text(content, encoding="utf-8")
        print(f"Report written: {output_path}", file=sys.stderr)
    else:
        print(content)


# ───────────────────────── FormatTool ─────────────────────────

def md_table(headers, rows):
    """Generate Markdown table string."""
    if not rows:
        return "(empty table)\n"
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))
    fmt = " | ".join(f"{{:<{w}}}" for w in col_widths)
    sep = "-|-".join("-" * w for w in col_widths)
    lines = [fmt.format(*headers), sep]
    for row in rows:
        lines.append(fmt.format(*[str(c) for c in row]))
    return "\n".join(lines) + "\n"


def fmt_num(n, decimals=2):
    """Format number with thousands separator and decimal places."""
    if isinstance(n, int):
        return f"{n:,}"
    if abs(n) >= 1000:
        return f"{n:,.{decimals}f}"
    return f"{n:.{decimals}f}"


def pct(n, decimals=1):
    return f"{n:.{decimals}f}%"


# ───────────────────────── Matrix Tools (for quantitative investment) ─────────────────────────

def mat_mult(A, B):
    """Matrix multiplication A(m×n) × B(n×p)."""
    n = len(A)
    m = len(B[0])
    k = len(B)
    return [[sum(A[i][x] * B[x][j] for x in range(k)) for j in range(m)] for i in range(n)]


def mat_inv(M):
    """Gauss-Jordan elimination matrix inverse (partial pivoting)."""
    n = len(M)
    aug = [row[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, row in enumerate(M)]
    for col in range(n):
        mx = max(range(col, n), key=lambda r: abs(aug[r][col]))
        aug[col], aug[mx] = aug[mx], aug[col]
        if abs(aug[col][col]) < 1e-12:
            return None
        pivot = aug[col][col]
        aug[col] = [x / pivot for x in aug[col]]
        for row in range(n):
            if row != col:
                f = aug[row][col]
                aug[row] = [aug[row][j] - f * aug[col][j] for j in range(2 * n)]
    return [row[n:] for row in aug]


def mat_transpose(M):
    """Matrix transpose."""
    return [list(row) for row in zip(*M)]


def quad_form(w, M):
    """Quadratic form w'Mw."""
    n = len(w)
    return sum(w[i] * M[i][j] * w[j] for i in range(n) for j in range(n))


# ───────────────────────── Statistical Tools ─────────────────────────

def rank_data(values):
    """Rank data (1-based, average tie-breaking)."""
    indexed = sorted(enumerate(values), key=lambda x: x[1])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(indexed):
        j = i
        while j < len(indexed) and indexed[j][1] == indexed[i][1]:
            j += 1
        avg_rank = (i + j + 1) / 2.0
        for k in range(i, j):
            ranks[indexed[k][0]] = avg_rank
        i = j
    return ranks


def spearman_ic(x, y):
    """Spearman rank correlation (IC)."""
    rx = rank_data(x)
    ry = rank_data(y)
    n = len(x)
    if n < 3:
        return 0.0
    mx = sum(rx) / n
    my = sum(ry) / n
    cov = sum((rx[i] - mx) * (ry[i] - my) for i in range(n)) / n
    sx = math.sqrt(sum((r - mx) ** 2 for r in rx) / n)
    sy = math.sqrt(sum((r - my) ** 2 for r in ry) / n)
    if sx == 0 or sy == 0:
        return 0.0
    return cov / (sx * sy)


def norm_cdf(x):
    """Standard normal CDF approximation (Abramowitz & Stegun)."""
    a1, a2, a3, a4, a5 = 0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429
    p = 0.3275911
    sign = 1 if x >= 0 else -1
    x = abs(x) / math.sqrt(2)
    t = 1.0 / (1.0 + p * x)
    y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * math.exp(-x * x)
    return 0.5 * (1.0 + sign * y)


def z_test(p1, n1, p2, n2):
    """Two-proportion z-test, return (z_stat, p_value_approx)."""
    p_pool = (n1 * p1 + n2 * p2) / (n1 + n2)
    se = math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    if se == 0:
        return 0, 1.0
    z = (p2 - p1) / se
    p_val = 2 * (1 - norm_cdf(abs(z)))
    return z, p_val


def quintile_score(values, reverse=False):
    """Map values to 1-5 quintile scores. reverse=True means lower value gets higher score (e.g. recency)."""
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    scores = {}
    for i, v in enumerate(sorted_vals):
        q = min(4, int(i / n * 5))
        scores[v] = (5 - q) if reverse else (q + 1)
    return [scores[v] for v in values]

# ===== merged from: decision.py =====
"""Decision & prioritization methodologies — RICE / Decision Matrix / ICE"""

import json
import sys


# ───────────────────────── RICE Scoring ─────────────────────────

RICE_HELP = """
RICE priority scoring: Score = (Reach × Impact × Confidence) ÷ Effort

CSV Format (headers must match):
  name,reach,impact,confidence,effort

  name       : Requirement/feature name
  reach      : Number of users reached (users/month)
  impact     : Impact (0.25 / 0.5 / 1 / 2 / 3)
  confidence : Confidence percentage (100 / 80 / 50)
  effort     : Effort (person-months)

Example:
  name,reach,impact,confidence,effort
  Feature A,50000,2,80,2
  Feature B,20000,3,50,1
"""


def cmd_rice(args):
    rows = read_csv(args.input)
    required = {"name", "reach", "impact", "confidence", "effort"}
    if not required.issubset(rows[0].keys()):
        missing = required - set(rows[0].keys())
        print(f"CSV missing columns: {missing}", file=sys.stderr)
        sys.exit(1)

    scored = []
    for row_no, r in enumerate(rows, 2):
        reach = fnum(r["reach"], "reach", row_no)
        impact = fnum(r["impact"], "impact", row_no)
        conf = fnum(r["confidence"], "confidence", row_no) / 100.0
        effort = fnum(r["effort"], "effort", row_no)
        if effort <= 0:
            print(f"Warning: '{r['name']}' has Effort={effort}, skipped", file=sys.stderr)
            continue
        score = (reach * impact * conf) / effort
        scored.append({
            "name": r["name"], "reach": reach, "impact": impact,
            "confidence": float(r["confidence"]), "effort": effort, "score": score,
        })

    scored.sort(key=lambda x: x["score"], reverse=True)

    lines = ["# RICE Priority Scoring Report\n"]
    lines.append(f"Items evaluated: {len(scored)}\n")
    lines.append("## Sorted Results\n")
    headers = ["Rank", "Name", "Reach", "Impact", "Confidence", "Effort", "RICE Score"]
    table_rows = []
    for i, s in enumerate(scored, 1):
        table_rows.append([
            i, s["name"], fmt_num(s["reach"], 0), s["impact"],
            f"{s['confidence']:.0f}%", s["effort"], fmt_num(s["score"], 0)
        ])
    lines.append(md_table(headers, table_rows))

    if len(scored) >= 3:
        # Standard three-way split: top third / middle third / bottom third.
        # (n < 3: tiers are skipped entirely — with fewer than 3 items a
        # three-way split is meaningless, all items simply rank above.)
        top_third = max(1, len(scored) // 3)
        mid_end = top_third * 2
        lines.append("## Tier Recommendations\n")
        lines.append(f"- **Must do (Top {top_third})**: {', '.join(s['name'] for s in scored[:top_third])}")
        lines.append(f"- **Target**: {', '.join(s['name'] for s in scored[top_third:mid_end])}")
        lines.append(f"- **Backlog**: {', '.join(s['name'] for s in scored[mid_end:])}")

    if args.json:
        write_output(json.dumps(scored, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Decision Matrix ─────────────────────────

DMATRIX_HELP = """
Decision Matrix (Pugh Matrix): Multi-option × Multi-criteria weighted scoring

CSV Format (long table, one option-criterion pair per row):
  option,criterion,weight,score

  option    : Option name
  criterion : Evaluation criterion
  weight    : Weight (percentage, e.g. 30 means 30%)
  score     : Score (1-5 or 1-10)

Example:
  option,criterion,weight,score
  Node.js,Dev Efficiency,30,5
  Node.js,Performance,25,3
  Go,Dev Efficiency,30,4
  Go,Performance,25,5
"""


def cmd_dmatrix(args):
    rows = read_csv(args.input)
    required = {"option", "criterion", "weight", "score"}
    if not required.issubset(rows[0].keys()):
        missing = required - set(rows[0].keys())
        print(f"CSV missing columns: {missing}", file=sys.stderr)
        sys.exit(1)

    options = []
    criteria = []
    data = {}
    weights = {}

    for row_no, r in enumerate(rows, 2):
        opt = r["option"].strip()
        crit = r["criterion"].strip()
        w = fnum(r["weight"], "weight", row_no)
        s = fnum(r["score"], "score", row_no)
        if opt not in options:
            options.append(opt)
        if crit not in criteria:
            criteria.append(crit)
        data[(opt, crit)] = s
        weights[crit] = w

    total_weight = sum(weights.values())
    if abs(total_weight - 100) > 1:
        print(f"Warning: Total weight = {total_weight}% (should be 100%)", file=sys.stderr)

    totals = {}
    details = {}
    for opt in options:
        total = 0
        detail = {}
        for crit in criteria:
            s = data.get((opt, crit), 0)
            w = weights.get(crit, 0) / 100.0
            weighted = s * w
            total += weighted
            detail[crit] = {"score": s, "weight": weights.get(crit, 0), "weighted": weighted}
        totals[opt] = total
        details[opt] = detail

    ranked = sorted(options, key=lambda o: totals[o], reverse=True)

    sensitivity = []
    for crit in criteria:
        orig_w = weights[crit]
        new_w = orig_w * 0.8
        new_totals = {}
        for opt in options:
            nt = 0
            for c in criteria:
                s = data.get((opt, c), 0)
                w = weights[c] / 100.0
                if c == crit:
                    w = new_w / 100.0
                nt += s * w
            new_totals[opt] = nt
        new_ranked = sorted(options, key=lambda o: new_totals[o], reverse=True)
        changed = new_ranked[0] != ranked[0]
        sensitivity.append({
            "criterion": crit, "orig_weight": orig_w,
            "winner_if_reduced": new_ranked[0], "changed": changed,
        })

    lines = ["# Decision Matrix Analysis Report\n"]
    lines.append(f"Options: {len(options)} | Criteria: {len(criteria)} | Total weight: {total_weight}%\n")

    lines.append("## Scoring Matrix\n")
    headers = ["Criterion", "Weight"] + options
    table_rows = []
    for crit in criteria:
        row = [crit, f"{weights[crit]}%"]
        for opt in options:
            row.append(f"{data.get((opt, crit), 0):.0f}")
        table_rows.append(row)
    total_row = ["**Total**", ""]
    for opt in options:
        total_row.append(f"**{fmt_num(totals[opt])}**")
    table_rows.append(total_row)
    lines.append(md_table(headers, table_rows))

    lines.append("## Ranking\n")
    for i, opt in enumerate(ranked, 1):
        marker = " ← Recommended" if i == 1 else ""
        lines.append(f"{i}. **{opt}** — {fmt_num(totals[opt])} pts{marker}")
    lines.append("")

    lines.append("## Sensitivity Analysis\n")
    sens_headers = ["Criterion", "Original Weight", "Winner if Reduced", "Change?"]
    sens_rows = []
    for s in sensitivity:
        sens_rows.append([
            s["criterion"], f"{s['orig_weight']}%",
            s["winner_if_reduced"], "Yes ⚠️" if s["changed"] else "No"
        ])
    lines.append(md_table(sens_headers, sens_rows))

    if len(ranked) >= 2:
        gap = totals[ranked[0]] - totals[ranked[1]]
        lines.append(f"\nGap between 1st and 2nd: **{fmt_num(gap)}**")
        if gap < 0.3:
            lines.append("⚠️ Gap < 0.3, options are closely matched, further evaluation recommended.")

    if args.json:
        result = {
            "options": {opt: {"total": totals[opt], "details": details[opt]} for opt in options},
            "ranking": [{"rank": i + 1, "option": opt, "score": totals[opt]} for i, opt in enumerate(ranked)],
            "sensitivity": sensitivity,
        }
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── ICE Framework ─────────────────────────

ICE_HELP = """
ICE scoring: Score = Impact × Confidence × Ease

CSV Format:
  name,impact,confidence,ease

  name       : Idea/feature name
  impact     : Impact (1-10)
  confidence : Confidence (1-10)
  ease       : Ease (1-10, higher = easier)

Example:
  name,impact,confidence,ease
  User Referral,8,7,9
  Paywall Optimization,6,5,4
"""


def cmd_ice(args):
    rows = read_csv(args.input)
    required = {"name", "impact", "confidence", "ease"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    items = []
    for row_no, r in enumerate(rows, 2):
        i, c, e = fnum(r["impact"], "impact", row_no), fnum(r["confidence"], "confidence", row_no), fnum(r["ease"], "ease", row_no)
        score = i * c * e
        items.append({"name": r["name"], "impact": i, "confidence": c, "ease": e, "score": score})

    items.sort(key=lambda x: x["score"], reverse=True)

    lines = ["# ICE Scoring Report\n"]
    lines.append(f"Items evaluated: {len(items)}\n")
    lines.append("## Sorted Results\n")
    headers = ["Rank", "Name", "Impact", "Confidence", "Ease", "ICE Score"]
    trows = [[i + 1, it["name"], it["impact"], it["confidence"], it["ease"], fmt_num(it["score"], 0)] for i, it in enumerate(items)]
    lines.append(md_table(headers, trows))

    if len(items) >= 3:
        top = max(1, len(items) // 3)
        lines.append("## Tier Recommendations\n")
        lines.append(f"- **Must do (Top {top})**: {', '.join(it['name'] for it in items[:top])}")
        lines.append(f"- **Candidates**: {', '.join(it['name'] for it in items[top:])}")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: risk.py =====
"""Risk assessment methodologies — Risk Matrix / FMEA / Pareto"""

import json
import sys


# ───────────────────────── Risk Matrix ─────────────────────────

RISK_HELP = """
Risk Matrix: Probability × Impact quick risk assessment and prioritization

CSV Format:
  name,probability,impact,category

  name        : Risk description
  probability : Probability (1-5)
  impact      : Impact (1-5)
  category    : Risk category (optional, for grouping)

Example:
  name,probability,impact,category
  Server Outage,3,5,Technical
  Key Personnel Departure,2,4,Personnel
  Frequent Requirement Changes,4,3,Requirements
"""


def cmd_risk(args):
    rows = read_csv(args.input)
    required = {"name", "probability", "impact"}
    if not required.issubset(rows[0].keys()):
        missing = required - set(rows[0].keys())
        print(f"CSV missing columns: {missing}", file=sys.stderr)
        sys.exit(1)

    risks = []
    for row_no, r in enumerate(rows, 2):
        p = inum(r["probability"], "probability", row_no)
        i = inum(r["impact"], "impact", row_no)
        risk_value = p * i
        if risk_value >= 15:
            zone, zone_en, action = "Red", "CRITICAL", "Act immediately"
        elif risk_value >= 8:
            zone, zone_en, action = "Orange", "HIGH", "Proactive mitigation"
        elif risk_value >= 4:
            zone, zone_en, action = "Yellow", "MEDIUM", "Continuous monitoring"
        else:
            zone, zone_en, action = "Green", "LOW", "Accept risk"
        risks.append({
            "name": r["name"], "probability": p, "impact": i,
            "risk_value": risk_value, "zone": zone, "zone_en": zone_en,
            "action": action, "category": r.get("category", ""),
        })

    risks.sort(key=lambda x: x["risk_value"], reverse=True)

    zone_counts = {"Red": 0, "Orange": 0, "Yellow": 0, "Green": 0}
    for r in risks:
        zone_counts[r["zone"]] += 1

    lines = ["# Risk Assessment Report\n"]
    lines.append(f"Total risks identified: {len(risks)}\n")
    lines.append("## Risk Distribution\n")
    lines.append(f"- 🔴 Red (extreme 15-25): {zone_counts['Red']} items")
    lines.append(f"- 🟠 Orange (high 8-14): {zone_counts['Orange']} items")
    lines.append(f"- 🟡 Yellow (medium 4-7): {zone_counts['Yellow']} items")
    lines.append(f"- 🟢 Green (low 1-3): {zone_counts['Green']} items\n")

    lines.append("## Risk Register (sorted by risk value)\n")
    headers = ["Rank", "Risk", "Probability", "Impact", "Risk Value", "Zone", "Response Strategy"]
    table_rows = []
    for idx, r in enumerate(risks, 1):
        table_rows.append([
            idx, r["name"], r["probability"], r["impact"],
            r["risk_value"], r["zone"], r["action"]
        ])
    lines.append(md_table(headers, table_rows))

    lines.append("## Risk Matrix\n")
    grid = {}
    for r in risks:
        grid[(r["probability"], r["impact"])] = r["name"][:8]
    lines.append("```\nImpact →  1    2    3    4    5")
    lines.append("Probability ↓")
    for p in range(5, 0, -1):
        row_str = f"  {p}  "
        for i in range(1, 6):
            val = p * i
            cell = grid.get((p, i), "·")
            if val >= 15:
                cell = f"🔴{cell}" if cell != "·" else "🔴·"
            elif val >= 8:
                cell = f"🟠{cell}" if cell != "·" else "🟠·"
            elif val >= 4:
                cell = f"🟡{cell}" if cell != "·" else "🟡·"
            row_str += f" {cell:>5}"
        lines.append(row_str)
    lines.append("```\n")

    critical = [r for r in risks if r["risk_value"] >= 8]
    if critical:
        lines.append("## Risks Requiring Immediate Attention\n")
        for r in critical:
            lines.append(f"- **{r['name']}** (RiskValue {r['risk_value']}, {r['zone']}) → {r['action']}")

    if args.json:
        write_output(json.dumps(risks, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── FMEA ─────────────────────────

FMEA_HELP = """
FMEA Failure Mode and Effects Analysis: RPN = Severity(S) × Occurrence(O) × Detection(D)

CSV Format:
  name,severity,occurrence,detection,category

  name      : Failure mode description
  severity  : Severity (1-10)
  occurrence: Occurrence (1-10)
  detection : Detection (1-10, 1=certain detection, 10=undetectable)
  category  : Category (optional)

Example:
  name,severity,occurrence,detection,category
  Power Overload,8,4,3,Hardware
  Data Loss,9,3,5,Software
"""


def cmd_fmea(args):
    rows = read_csv(args.input)
    required = {"name", "severity", "occurrence", "detection"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    items = []
    for row_no, r in enumerate(rows, 2):
        s = inum(r["severity"], "severity", row_no)
        o = inum(r["occurrence"], "occurrence", row_no)
        d = inum(r["detection"], "detection", row_no)
        rpn = s * o * d
        if rpn >= 200:
            zone, action = "Critical", "Immediate corrective action required"
        elif rpn >= 100:
            zone, action = "High", "Develop mitigation plan ASAP"
        elif rpn >= 50:
            zone, action = "Medium", "Include in monitoring and plan improvement"
        else:
            zone, action = "Low", "Routine monitoring"
        items.append({"name": r["name"], "s": s, "o": o, "d": d, "rpn": rpn,
                       "zone": zone, "action": action, "category": r.get("category", "")})

    items.sort(key=lambda x: x["rpn"], reverse=True)

    lines = ["# FMEA Failure Mode Analysis Report\n"]
    lines.append(f"Number of failure modes: {len(items)}\n")
    lines.append("## Risk Priority Number Ranking\n")
    headers = ["Rank", "Failure Mode", "S", "O", "D", "RPN", "Risk Level", "Response Strategy"]
    trows = [[i + 1, it["name"], it["s"], it["o"], it["d"], it["rpn"], it["zone"], it["action"]] for i, it in enumerate(items)]
    lines.append(md_table(headers, trows))

    high = [it for it in items if it["rpn"] >= 100]
    if high:
        lines.append("## Failure Modes Requiring Priority Action\n")
        for it in high:
            lines.append(f"- **{it['name']}** (RPN={it['rpn']}, {it['zone']}) → {it['action']}")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Pareto Analysis ─────────────────────────

PARETO_HELP = """
Pareto Analysis: Identify the vital few (20% of causes produce 80% of impact)

CSV Format:
  name,value

  name  : Item name
  value : Impact value (numeric)

Example:
  name,value
  Payment Failure,420
  Login Error,300
  Order Sync Issue,180
  Refund Query,120
  Address Change,90
  Coupon Issue,60
  Other,30
"""


def cmd_pareto(args):
    rows = read_csv(args.input)
    required = {"name", "value"}
    if not required.issubset(rows[0].keys()):
        missing = required - set(rows[0].keys())
        print(f"CSV missing columns: {missing}", file=sys.stderr)
        sys.exit(1)

    items = []
    skipped = 0
    for row_no, r in enumerate(rows, 2):
        v = fnum(r["value"], "value", row_no)
        if v <= 0:
            skipped += 1
            continue
        items.append({"name": r["name"], "value": v})

    items.sort(key=lambda x: x["value"], reverse=True)
    total = sum(i["value"] for i in items)
    if total == 0:
        print("All values are 0, cannot analyze", file=sys.stderr)
        sys.exit(1)

    cumulative = 0
    for item in items:
        pct_val = item["value"] / total * 100
        cumulative += pct_val
        item["pct"] = pct_val
        item["cumulative"] = cumulative
        item["classification"] = "Vital Few" if cumulative <= 80 else ("Boundary" if cumulative - pct_val < 80 else "Trivial Many")

    vital = [i for i in items if i["classification"] == "Vital Few" or i["classification"] == "Boundary"]
    trivial = [i for i in items if i["classification"] == "Trivial Many"]

    lines = ["# Pareto Analysis Report\n"]
    if skipped:
        lines.append(f"⚠️ Skipped {skipped} input row(s) with value ≤ 0 (Pareto analysis requires positive values).\n")
    lines.append(f"Items analyzed: {len(items)} | Total value: {fmt_num(total)}\n")

    lines.append("## Sorted Results\n")
    headers = ["Rank", "Item", "Impact Value", "Percentage", "Cumulative %", "Classification"]
    table_rows = []
    for idx, item in enumerate(items, 1):
        marker = " ← 80% boundary" if (item["cumulative"] >= 80 and (item["cumulative"] - item["pct"]) < 80) else ""
        table_rows.append([
            idx, item["name"], fmt_num(item["value"]),
            pct(item["pct"]), pct(item["cumulative"]),
            item["classification"] + marker
        ])
    lines.append(md_table(headers, table_rows))

    vital_pct = sum(i["pct"] for i in vital)
    lines.append(f"\n## Vital Few ({len(vital)} items, contributing {pct(vital_pct)} impact)\n")
    for i, item in enumerate(vital, 1):
        lines.append(f"{i}. **{item['name']}** — ImpactValue: {fmt_num(item['value'])} ({pct(item['pct'])})")

    if trivial:
        trivial_pct = sum(i["pct"] for i in trivial)
        lines.append(f"\n## Trivial Many ({len(trivial)} items, contributing {pct(trivial_pct)} impact)\n")
        lines.append("Strategy: Reduce investment / Standardize process / Defer / Remove")

    lines.append("\n## Cumulative Distribution\n")
    lines.append("```")
    bar_max = 40
    for item in items:
        bar_len = int(item["cumulative"] / 100 * bar_max)
        bar = "█" * bar_len + "░" * (bar_max - bar_len)
        lines.append(f"  {item['name']:<15} {bar} {pct(item['cumulative'])}")
    lines.append("```\n")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: financial.py =====
"""Financial analysis methodologies — DuPont / DCF / EVA"""

import json
import sys


# ───────────────────────── DuPont Analysis ─────────────────────────

DUPONT_HELP = """
DuPont Analysis: ROE = Net Profit Margin × Asset Turnover × Equity Multiplier

CSV Format:
  period,revenue,net_income,total_assets,equity

  period       : Period identifier (e.g. 2023, 2024, Q1-2024)
  revenue      : Revenue
  net_income   : Net Income
  total_assets : Total Assets
  equity       : Shareholders' Equity

Example:
  period,revenue,net_income,total_assets,equity
  2023,1000000,150000,2000000,800000
  2024,1200000,180000,2200000,900000
"""


def cmd_dupont(args):
    rows = read_csv(args.input)
    required = {"period", "revenue", "net_income", "total_assets", "equity"}
    if not required.issubset(rows[0].keys()):
        missing = required - set(rows[0].keys())
        print(f"CSV missing columns: {missing}", file=sys.stderr)
        sys.exit(1)

    periods = []
    for row_no, r in enumerate(rows, 2):
        rev = fnum(r["revenue"], "revenue", row_no)
        ni = fnum(r["net_income"], "net_income", row_no)
        ta = fnum(r["total_assets"], "total_assets", row_no)
        eq = fnum(r["equity"], "equity", row_no)
        if rev == 0 or ta == 0 or eq == 0:
            print(f"Warning: '{r['period']}' has zero value, skipped", file=sys.stderr)
            continue
        net_margin = ni / rev
        asset_turnover = rev / ta
        equity_multiplier = ta / eq
        roe = net_margin * asset_turnover * equity_multiplier
        periods.append({
            "period": r["period"], "revenue": rev, "net_income": ni,
            "total_assets": ta, "equity": eq, "net_margin": net_margin,
            "asset_turnover": asset_turnover, "equity_multiplier": equity_multiplier, "roe": roe,
        })

    changes = []
    for i in range(1, len(periods)):
        prev = periods[i - 1]
        curr = periods[i]
        delta_margin = (curr["net_margin"] - prev["net_margin"]) * prev["asset_turnover"] * prev["equity_multiplier"]
        delta_turnover = curr["net_margin"] * (curr["asset_turnover"] - prev["asset_turnover"]) * prev["equity_multiplier"]
        delta_leverage = curr["net_margin"] * curr["asset_turnover"] * (curr["equity_multiplier"] - prev["equity_multiplier"])
        delta_roe = curr["roe"] - prev["roe"]
        changes.append({
            "from": prev["period"], "to": curr["period"],
            "delta_margin": delta_margin, "delta_turnover": delta_turnover,
            "delta_leverage": delta_leverage, "delta_roe": delta_roe,
        })

    lines = ["# DuPont Analysis Report\n"]
    lines.append("## Three-Factor Data\n")
    headers = ["Period", "Net Profit Margin", "Asset Turnover", "Equity Multiplier", "ROE"]
    table_rows = []
    for p in periods:
        table_rows.append([
            p["period"], pct(p["net_margin"] * 100),
            fmt_num(p["asset_turnover"]), fmt_num(p["equity_multiplier"]),
            pct(p["roe"] * 100)
        ])
    lines.append(md_table(headers, table_rows))

    lines.append("## Raw Financial Data\n")
    headers2 = ["Period", "Revenue", "Net Income", "Total Assets", "Shareholders' Equity"]
    table_rows2 = []
    for p in periods:
        table_rows2.append([
            p["period"], fmt_num(p["revenue"], 0), fmt_num(p["net_income"], 0),
            fmt_num(p["total_assets"], 0), fmt_num(p["equity"], 0)
        ])
    lines.append(md_table(headers2, table_rows2))

    if changes:
        lines.append("## Factor Contribution Analysis (Chain Substitution Method)\n")
        for c in changes:
            lines.append(f"### {c['from']} → {c['to']}\n")
            lines.append(f"- Net profit margin contribution: {c['delta_margin']:+.4f} ({pct(c['delta_margin'] / c['delta_roe'] * 100) if c['delta_roe'] != 0 else 'N/A'})")
            lines.append(f"- Turnover ratio contribution: {c['delta_turnover']:+.4f} ({pct(c['delta_turnover'] / c['delta_roe'] * 100) if c['delta_roe'] != 0 else 'N/A'})")
            lines.append(f"- Equity multiplier contribution: {c['delta_leverage']:+.4f} ({pct(c['delta_leverage'] / c['delta_roe'] * 100) if c['delta_roe'] != 0 else 'N/A'})")
            lines.append(f"- **Total ROE change**: {c['delta_roe']:+.4f}\n")

    if periods:
        latest = periods[-1]
        lines.append("## Diagnostic Recommendations\n")
        if latest["net_margin"] < 0.05:
            lines.append("- ⚠️ Low net profit margin (<5%): consider price increase / cost reduction / product mix upgrade")
        if latest["asset_turnover"] < 0.5:
            lines.append("- ⚠️ Low asset turnover (<0.5): consider inventory management / receivables optimization / asset disposal")
        if latest["equity_multiplier"] > 3:
            lines.append("- ⚠️ High equity multiplier (>3): high leverage risk, consider deleveraging")

    if args.json:
        result = {"periods": periods, "changes": changes}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── DCF ─────────────────────────

DCF_HELP = """
DCF Discounted Cash Flow: Enterprise value = Σ FCF/(1+r)^t + Terminal value/(1+r)^n

CSV Format:
  year,fcf

  year : Period index starting at 1 (1, 2, 3, ...). Calendar years
         (e.g. 2024) or non-consecutive sequences are rejected with an error.
  fcf  : Free cash flow

Additional parameters via command line:
  --rate       Discount rate (WACC), e.g. 0.10 for 10%
  --growth     Perpetual growth rate, e.g. 0.03 for 3%
  --shares     Shares outstanding (optional, for per-share valuation)

Example:
  python scripts/main.py dcf -i cashflows.csv --rate 0.10 --growth 0.03 --shares 1000000
"""


def cmd_dcf(args):
    rows = read_csv(args.input)
    required = {"year", "fcf"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    rate = float(args.rate) if hasattr(args, 'rate') and args.rate else 0.10
    growth = float(args.growth) if hasattr(args, 'growth') and args.growth else 0.03
    shares = float(args.shares) if hasattr(args, 'shares') and args.shares else 0

    cashflows = []
    for row_no, r in enumerate(rows, 2):
        cashflows.append({"year": int(fnum(r["year"], "year", row_no)), "fcf": fnum(r["fcf"], "fcf", row_no)})
    cashflows.sort(key=lambda x: x["year"])

    if not cashflows:
        print("No cash flow data", file=sys.stderr)
        sys.exit(1)

    # Validate years: the discount index t must be a period count starting at 1
    # (1, 2, 3, ...). Calendar years (e.g. 2024) or gaps would silently deflate
    # present values to ~0, so fail loudly instead.
    years = [cf["year"] for cf in cashflows]
    if years != list(range(1, len(years) + 1)) or years[-1] > 2100:
        print("Error: 'year' must be consecutive period indices starting at 1 (1, 2, 3, ...), "
              f"not calendar years or an irregular sequence. Got: {years}. "
              "Map calendar years to periods 1..n before running DCF.", file=sys.stderr)
        sys.exit(1)

    pv_items = []
    total_pv = 0
    for cf in cashflows:
        t = cf["year"]
        pv = cf["fcf"] / ((1 + rate) ** t)
        total_pv += pv
        pv_items.append({"year": t, "fcf": cf["fcf"], "pv": pv, "discount_factor": 1 / ((1 + rate) ** t)})

    last_fcf = cashflows[-1]["fcf"]
    n = cashflows[-1]["year"]
    terminal_value = last_fcf * (1 + growth) / (rate - growth)
    terminal_pv = terminal_value / ((1 + rate) ** n)
    enterprise_value = total_pv + terminal_pv
    per_share = enterprise_value / shares if shares > 0 else 0

    sensitivity = []
    for dr in [rate - 0.02, rate - 0.01, rate, rate + 0.01, rate + 0.02]:
        if dr <= growth:
            continue
        tv = last_fcf * (1 + growth) / (dr - growth)
        tpv = tv / ((1 + dr) ** n)
        spv = sum(cf["fcf"] / ((1 + dr) ** cf["year"]) for cf in cashflows)
        ev = spv + tpv
        sensitivity.append({"discount_rate": dr, "enterprise_value": ev,
                            "per_share": ev / shares if shares > 0 else 0})

    lines = ["# DCF Valuation Report\n"]
    lines.append(f"Discount rate: {pct(rate * 100)} | Perpetual growth rate: {pct(growth * 100)} | Projection period: {n} years\n")

    lines.append("## Cash Flow Discounting\n")
    headers = ["Year", "Free Cash Flow", "Discount Factor", "Present Value"]
    trows = [[it["year"], fmt_num(it["fcf"], 0), f"{it['discount_factor']:.4f}", fmt_num(it["pv"], 0)] for it in pv_items]
    lines.append(md_table(headers, trows))

    lines.append("## Valuation Summary\n")
    lines.append(f"- PV of projection period: **{fmt_num(total_pv, 0)}**")
    lines.append(f"- Terminal value (Gordon): **{fmt_num(terminal_value, 0)}**")
    lines.append(f"- PV of terminal value: **{fmt_num(terminal_pv, 0)}**")
    lines.append(f"- **Enterprise value**: **{fmt_num(enterprise_value, 0)}**")
    if shares > 0:
        lines.append(f"- Shares outstanding: {fmt_num(shares, 0)}")
        lines.append(f"- **Per-share value**: **{fmt_num(per_share)}**")

    lines.append(f"\n## Sensitivity Analysis (Discount rate variation)\n")
    s_headers = ["Discount Rate", "Enterprise Value"] + (["Per-Share Value"] if shares > 0 else [])
    s_rows = [[pct(s["discount_rate"] * 100), fmt_num(s["enterprise_value"], 0)] + ([fmt_num(s["per_share"])] if shares > 0 else []) for s in sensitivity]
    lines.append(md_table(s_headers, s_rows))

    if args.json:
        result = {"rate": rate, "growth": growth, "pv_items": pv_items,
                   "terminal_value": terminal_value, "terminal_pv": terminal_pv,
                   "enterprise_value": enterprise_value, "per_share": per_share, "sensitivity": sensitivity}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── EVA ─────────────────────────

EVA_HELP = """
EVA Economic Value Added: EVA = NOPAT - WACC × Invested Capital

CSV Format:
  period,ebit,tax_rate,invested_capital,wacc

  period          : Period identifier
  ebit            : Earnings before interest and tax
  tax_rate        : Tax rate (decimal, e.g. 0.25)
  invested_capital: Invested capital
  wacc            : Weighted average cost of capital (decimal, e.g. 0.10)

Example:
  period,ebit,tax_rate,invested_capital,wacc
  2023,500000,0.25,3000000,0.10
  2024,600000,0.25,3200000,0.09
"""


def cmd_eva(args):
    rows = read_csv(args.input)
    required = {"period", "ebit", "tax_rate", "invested_capital", "wacc"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    items = []
    for row_no, r in enumerate(rows, 2):
        ebit = fnum(r["ebit"], "ebit", row_no)
        tax = fnum(r["tax_rate"], "tax_rate", row_no)
        ic = fnum(r["invested_capital"], "invested_capital", row_no)
        wacc = fnum(r["wacc"], "wacc", row_no)
        nopat = ebit * (1 - tax)
        capital_charge = wacc * ic
        eva = nopat - capital_charge
        roic = nopat / ic if ic > 0 else 0
        spread = roic - wacc
        items.append({"period": r["period"], "ebit": ebit, "tax_rate": tax,
                       "invested_capital": ic, "wacc": wacc, "nopat": nopat,
                       "capital_charge": capital_charge, "eva": eva, "roic": roic, "spread": spread})

    lines = ["# EVA (Economic Value Added) Analysis Report\n"]
    lines.append(f"Periods analyzed: {len(items)}\n")

    lines.append("## Core Metrics\n")
    headers = ["Period", "NOPAT", "Capital Charge", "EVA", "ROIC", "Spread"]
    trows = [[it["period"], fmt_num(it["nopat"], 0), fmt_num(it["capital_charge"], 0),
              fmt_num(it["eva"], 0), pct(it["roic"] * 100), pct(it["spread"] * 100)] for it in items]
    lines.append(md_table(headers, trows))

    lines.append("## Raw Data\n")
    h2 = ["Period", "EBIT", "Tax Rate", "Invested Capital", "WACC"]
    t2 = [[it["period"], fmt_num(it["ebit"], 0), pct(it["tax_rate"] * 100),
           fmt_num(it["invested_capital"], 0), pct(it["wacc"] * 100)] for it in items]
    lines.append(md_table(h2, t2))

    lines.append("## Diagnostics\n")
    for it in items:
        if it["eva"] > 0:
            lines.append(f"- **{it['period']}**: EVA > 0, creating value (Spread = {pct(it['spread'] * 100)})")
        else:
            lines.append(f"- **{it['period']}**: EVA < 0, destroying value! ROIC ({pct(it['roic'] * 100)}) < WACC ({pct(it['wacc'] * 100)})")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: data.py =====
"""Data analysis methodologies — A/B Test / RFM / Cohort"""

import json
import math
import sys


# ───────────────────────── A/B Test Analysis ─────────────────────────

ABTEST_HELP = """
A/B Test Analysis: Statistical significance testing + SRM detection + Decision matrix

CSV Format:
  variant,users,conversions

  variant     : Variant name (control / treatment)
  users       : Number of users
  conversions : Number of conversions

Two or more variants supported. The first two rows are treated as control and
primary treatment; any additional variants are summarized and compared against
the control in an 'Additional Variants' section (not part of the primary decision).

Example:
  variant,users,conversions
  control,10000,500
  treatment,10200,550
"""


def cmd_abtest(args):
    rows = read_csv(args.input)
    required = {"variant", "users", "conversions"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    variants = {}
    for row_no, r in enumerate(rows, 2):
        u = inum(r["users"], "users", row_no)
        c = inum(r["conversions"], "conversions", row_no)
        variants[r["variant"]] = {"users": u, "conversions": c, "rate": c / u if u > 0 else 0}

    if len(variants) < 2:
        print("At least 2 variants required", file=sys.stderr)
        sys.exit(1)

    names = list(variants.keys())
    ctrl_name = names[0]
    treat_name = names[1]
    extra_names = names[2:]  # 3rd+ variants: summarized below, never silently dropped
    ctrl = variants[ctrl_name]
    treat = variants[treat_name]

    # SRM detection: chi-square goodness-of-fit vs 50/50 split,
    # critical value chi2 > 3.841 (alpha = 0.05, df = 1)
    total_users = ctrl["users"] + treat["users"]
    expected_ctrl = total_users * 0.5
    srm_chi2 = (ctrl["users"] - expected_ctrl) ** 2 / expected_ctrl + (treat["users"] - expected_ctrl) ** 2 / expected_ctrl
    srm_detected = srm_chi2 > 3.841

    # z-test
    z, p_val = z_test(ctrl["rate"], ctrl["users"], treat["rate"], treat["users"])
    significant = p_val < 0.05
    lift = (treat["rate"] - ctrl["rate"]) / ctrl["rate"] * 100 if ctrl["rate"] > 0 else 0

    # MDE for 80% power: (z_alpha + z_beta) * SE, z_alpha = 1.96, z_beta = 0.84
    alpha = 0.05
    z_alpha = 1.96
    z_beta = 0.84
    p_pool = (ctrl["conversions"] + treat["conversions"]) / (ctrl["users"] + treat["users"])
    mde = (z_alpha + z_beta) * math.sqrt(2 * p_pool * (1 - p_pool) / min(ctrl["users"], treat["users"]))

    if srm_detected:
        decision = "⚠️ INVALID — SRM detected sample ratio mismatch, results unreliable"
    elif significant and lift > 0:
        decision = "✅ Ship — Significant positive result, recommend launch"
    elif significant and lift < 0:
        decision = "❌ Stop — Significant negative result, stop experiment"
    elif not significant:
        decision = "🔍 Investigate — Not significant, segment analysis needed"
    else:
        decision = "🤷 Indeterminate"

    lines = ["# A/B Test Analysis Report\n"]
    lines.append(f"Control: {ctrl_name} | Treatment: {treat_name}\n")
    if extra_names:
        lines.append(f"⚠️ **WARNING**: {len(variants)} variants provided. Only the first two "
                     f"('{ctrl_name}' vs '{treat_name}') are analyzed in the primary decision; the other "
                     f"{len(extra_names)} variant(s) ({', '.join(extra_names)}) are summarized in "
                     f"'Additional Variants' below and are **not** part of the primary decision.\n")

    lines.append("## Basic Data\n")
    headers = ["Variant", "Users", "Conversions", "Conversion Rate"]
    trows = [[ctrl_name, fmt_num(ctrl["users"], 0), ctrl["conversions"], pct(ctrl["rate"] * 100)],
             [treat_name, fmt_num(treat["users"], 0), treat["conversions"], pct(treat["rate"] * 100)]]
    lines.append(md_table(headers, trows))

    lines.append(f"**Lift**: {lift:+.2f}%\n")

    lines.append("## Statistical Test\n")
    lines.append(f"- z Statistic: {z:.4f}")
    lines.append(f"- p Value: {p_val:.6f}")
    lines.append(f"- Significance level α: {alpha}")
    lines.append(f"- Conclusion: {'Significant (p < 0.05)' if significant else 'Not significant (p ≥ 0.05)'}")
    lines.append(f"- MDE (Minimum Detectable Effect): {pct(mde * 100)}\n")

    lines.append("## SRM Check\n")
    lines.append(f"- Sample ratio difference: {abs(ctrl['users'] - treat['users']) / total_users * 100:.2f}%")
    lines.append(f"- SRM Status: {'⚠️ Mismatch detected' if srm_detected else '✅ Normal'}")
    lines.append(f"- χ² = {srm_chi2:.4f}\n")

    lines.append(f"## Decision: {decision}")

    if extra_names:
        lines.append("\n## Additional Variants (vs control, informational)\n")
        a_headers = ["Variant", "Users", "Conversions", "Conversion Rate", "Lift vs Control", "z", "p Value", "Significant?"]
        a_trows = []
        for name in extra_names:
            v = variants[name]
            vz, vp = z_test(ctrl["rate"], ctrl["users"], v["rate"], v["users"])
            v_lift = (v["rate"] - ctrl["rate"]) / ctrl["rate"] * 100 if ctrl["rate"] > 0 else 0
            a_trows.append([name, fmt_num(v["users"], 0), v["conversions"], pct(v["rate"] * 100),
                            f"{v_lift:+.2f}%", f"{vz:.4f}", f"{vp:.6f}",
                            "Yes" if vp < 0.05 else "No"])
        lines.append(md_table(a_headers, a_trows))
        lines.append("\nNote: for a decision across 3+ variants, control for multiplicity "
                     "(e.g. Bonferroni: use α = 0.05 / number of comparisons) or run a chi-square test first.")

    if args.json:
        result = {"control": ctrl, "treatment": treat, "z": z, "p_value": p_val,
                   "significant": significant, "lift": lift, "srm_detected": srm_detected,
                   "srm_chi2": srm_chi2, "mde": mde, "decision": decision}
        if extra_names:
            result["ignored_variants_warning"] = (f"Only the first two variants were compared; "
                                                   f"{len(extra_names)} additional variant(s) summarized separately.")
            result["additional_variants"] = {name: variants[name] for name in extra_names}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── RFM Model ─────────────────────────

RFM_HELP = """
RFM User Segmentation: Recency × Frequency × Monetary → 8 segments

CSV Format:
  customer_id,recency,frequency,monetary

  customer_id : Customer identifier
  recency     : Days since last purchase
  frequency   : Number of purchases
  monetary    : Total spend

Example:
  customer_id,recency,frequency,monetary
  C001,5,20,5000
  C002,90,3,300
  C003,15,10,2000
"""


def cmd_rfm(args):
    rows = read_csv(args.input)
    required = {"customer_id", "recency", "frequency", "monetary"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    data = []
    for row_no, r in enumerate(rows, 2):
        data.append({"id": r["customer_id"],
                      "recency": fnum(r["recency"], "recency", row_no),
                      "frequency": fnum(r["frequency"], "frequency", row_no),
                      "monetary": fnum(r["monetary"], "monetary", row_no)})

    r_vals = [d["recency"] for d in data]
    f_vals = [d["frequency"] for d in data]
    m_vals = [d["monetary"] for d in data]

    r_scores = quintile_score(r_vals, reverse=True)
    f_scores = quintile_score(f_vals)
    m_scores = quintile_score(m_vals)

    for i, d in enumerate(data):
        d["r"] = r_scores[i]
        d["f"] = f_scores[i]
        d["m"] = m_scores[i]
        r_hi = d["r"] >= 4
        f_hi = d["f"] >= 4
        m_hi = d["m"] >= 4
        if r_hi and f_hi and m_hi:
            d["segment"] = "Champions"
        elif not r_hi and f_hi and m_hi:
            d["segment"] = "Loyal Customers"
        elif r_hi and not f_hi and m_hi:
            d["segment"] = "Potential Loyalists"
        elif not r_hi and not f_hi and m_hi:
            d["segment"] = "At Risk"
        elif r_hi and f_hi and not m_hi:
            d["segment"] = "Promising"
        elif not r_hi and f_hi and not m_hi:
            d["segment"] = "Need Attention"
        elif r_hi and not f_hi and not m_hi:
            d["segment"] = "New Customers"
        else:
            d["segment"] = "Lost"

    segments = {}
    for d in data:
        seg = d["segment"]
        if seg not in segments:
            segments[seg] = []
        segments[seg].append(d)

    lines = ["# RFM User Segmentation Report\n"]
    lines.append(f"Total customers: {len(data)}\n")

    lines.append("## Segment Statistics\n")
    headers = ["Segment", "Count", "Percentage", "Avg R", "Avg F", "Avg M"]
    seg_order = ["Champions", "Loyal Customers", "Potential Loyalists", "At Risk",
                  "Promising", "Need Attention", "New Customers", "Lost"]
    trows = []
    for seg in seg_order:
        if seg in segments:
            members = segments[seg]
            avg_r = sum(m["recency"] for m in members) / len(members)
            avg_f = sum(m["frequency"] for m in members) / len(members)
            avg_m = sum(m["monetary"] for m in members) / len(members)
            trows.append([seg, len(members), pct(len(members) / len(data) * 100),
                           f"{avg_r:.0f}", f"{avg_f:.1f}", fmt_num(avg_m, 0)])
    lines.append(md_table(headers, trows))

    lines.append("## Customer Details (top 20)\n")
    headers2 = ["Customer", "R", "F", "M", "Recency", "Frequency", "Monetary", "Segment"]
    trows2 = [[d["id"], d["r"], d["f"], d["m"], f"{d['recency']:.0f}",
               f"{d['frequency']:.0f}", fmt_num(d["monetary"], 0), d["segment"]] for d in data[:20]]
    lines.append(md_table(headers2, trows2))

    if args.json:
        write_output(json.dumps(data, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Cohort Analysis ─────────────────────────

COHORT_HELP = """
Cohort retention analysis: Track retention rates by time group

CSV Format:
  cohort,period,active,initial

  cohort  : Cohort identifier (e.g. 2024-01, 2024-02)
  period  : Period (0=initial, 1=period 1, 2=period 2, ...)
  active  : Active users
  initial : Initial users

Example:
  cohort,period,active,initial
  2024-01,0,1000,1000
  2024-01,1,600,1000
  2024-01,2,400,1000
  2024-02,0,800,800
  2024-02,1,500,800
"""


def cmd_cohort(args):
    rows = read_csv(args.input)
    required = {"cohort", "period", "active", "initial"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    cohorts = {}
    max_period = 0
    for row_no, r in enumerate(rows, 2):
        c = r["cohort"]
        p = inum(r["period"], "period", row_no)
        a = inum(r["active"], "active", row_no)
        ini = inum(r["initial"], "initial", row_no)
        if c not in cohorts:
            cohorts[c] = {}
        cohorts[c][p] = {"active": a, "initial": ini, "retention": a / ini if ini > 0 else 0}
        max_period = max(max_period, p)

    cohort_names = sorted(cohorts.keys())
    periods = list(range(max_period + 1))

    lines = ["# Cohort Retention Analysis Report\n"]
    lines.append(f"Cohorts: {len(cohort_names)} | Max period: {max_period}\n")

    lines.append("## Retention Rate Matrix\n")
    headers = ["Cohort", "Initial"] + [f"P{p}" for p in periods if p > 0]
    trows = []
    for c in cohort_names:
        ini = cohorts[c].get(0, {}).get("initial", 0)
        row = [c, str(ini)]
        for p in periods:
            if p == 0:
                continue
            if p in cohorts[c]:
                row.append(pct(cohorts[c][p]["retention"] * 100))
            else:
                row.append("-")
        trows.append(row)
    lines.append(md_table(headers, trows))

    lines.append("## Average Retention Rate by Period\n")
    avg_headers = ["Period"] + [f"P{p}" for p in periods if p > 0]
    avg_row = ["Average"]
    for p in periods:
        if p == 0:
            continue
        vals = [cohorts[c][p]["retention"] * 100 for c in cohort_names if p in cohorts[c]]
        avg_row.append(pct(sum(vals) / len(vals)) if vals else "-")
    lines.append(md_table(avg_headers, [avg_row]))

    lines.append("## PMF Signal\n")
    for p in periods:
        if p == 0:
            continue
        vals = [cohorts[c][p]["retention"] * 100 for c in cohort_names if p in cohorts[c]]
        if vals:
            avg = sum(vals) / len(vals)
            trend = "stable" if avg > 30 else "low"
            lines.append(f"- P{p} Avg Retention: {pct(avg)} — {trend}")

    if args.json:
        result = {"cohorts": {c: {str(p): cohorts[c][p] for p in cohorts[c]} for c in cohort_names}}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: strategy.py =====
"""Strategy matrices methodologies — BCG Matrix / GE-McKinsey / Opportunity Score"""

import json
import sys


# ───────────────────────── Opportunity Score ─────────────────────────

OPPSCORE_HELP = """
Opportunity Scoring: Opportunity = Importance × (1 - Satisfaction)

CSV Format:
  name,importance,satisfaction

  name         : Requirement/feature name
  importance   : Importance (1-5)
  satisfaction : Current satisfaction (1-5)

Example:
  name,importance,satisfaction
  Fast Response,5,2
  UI Aesthetics,3,4
"""


def cmd_oppscore(args):
    rows = read_csv(args.input)
    required = {"name", "importance", "satisfaction"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    items = []
    for row_no, r in enumerate(rows, 2):
        imp = fnum(r["importance"], "importance", row_no)
        sat = fnum(r["satisfaction"], "satisfaction", row_no)
        imp_n = (imp - 1) / 4
        sat_n = (sat - 1) / 4
        opp = imp_n * (1 - sat_n)
        items.append({"name": r["name"], "importance": imp, "satisfaction": sat,
                       "imp_norm": imp_n, "sat_norm": sat_n, "opportunity": opp})

    items.sort(key=lambda x: x["opportunity"], reverse=True)

    lines = ["# Opportunity Scoring Report\n"]
    lines.append(f"Requirements evaluated: {len(items)}\n")
    lines.append("## Sorted Results\n")
    headers = ["Rank", "Requirement", "Importance", "Satisfaction", "Opportunity Score"]
    trows = [[i + 1, it["name"], it["importance"], it["satisfaction"], f"{it['opportunity']:.3f}"] for i, it in enumerate(items)]
    lines.append(md_table(headers, trows))

    opportunities = [it for it in items if it["opportunity"] >= 0.5]
    satisfied = [it for it in items if it["satisfaction"] >= 4 and it["importance"] >= 4]
    low_priority = [it for it in items if it["importance"] <= 2]

    lines.append("## Classification Recommendations\n")
    if opportunities:
        lines.append(f"### Blue Ocean Opportunities ({len(opportunities)} items)\n")
        for it in opportunities:
            lines.append(f"- **{it['name']}** — Importance {it['importance']}, Satisfaction {it['satisfaction']}, Opportunity {it['opportunity']:.3f}")
    if satisfied:
        lines.append(f"\n### Satisfied High-Importance Requirements ({len(satisfied)} items)\n")
        for it in satisfied:
            lines.append(f"- {it['name']} — Maintain current state")
    if low_priority:
        lines.append(f"\n### Low Priority ({len(low_priority)} items)\n")
        for it in low_priority:
            lines.append(f"- {it['name']} — Not worth investing")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── BCG Matrix ─────────────────────────

BCG_HELP = """
BCG Matrix: Market growth rate × Relative market share → 4-quadrant classification

CSV Format:
  product,market_growth,relative_share,revenue

  product        : Product/business name
  market_growth  : Market growth rate (decimal, e.g. 0.15 for 15%)
  relative_share : Relative market share (decimal, e.g. 1.5 means market leader)
  revenue        : Revenue (optional, for bubble size)

Example:
  product,market_growth,relative_share,revenue
  ProductA,0.25,1.8,5000
  ProductB,0.05,2.5,8000
  ProductC,0.30,0.6,2000
  ProductD,0.02,0.4,1000
"""


def cmd_bcg(args):
    rows = read_csv(args.input)
    required = {"product", "market_growth", "relative_share"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    growth_threshold = 0.10
    share_threshold = 1.0

    items = []
    for row_no, r in enumerate(rows, 2):
        g = fnum(r["market_growth"], "market_growth", row_no)
        s = fnum(r["relative_share"], "relative_share", row_no)
        rev = fnum(r.get("revenue", 0), "revenue", row_no)
        if g >= growth_threshold and s >= share_threshold:
            quadrant = "⭐ Star"
        elif g < growth_threshold and s >= share_threshold:
            quadrant = "💰 Cash Cow"
        elif g >= growth_threshold and s < share_threshold:
            quadrant = "❓ Question Mark"
        else:
            quadrant = "🐕 Dog"
        items.append({"product": r["product"], "growth": g, "share": s,
                       "revenue": rev, "quadrant": quadrant})

    quads = {}
    for it in items:
        q = it["quadrant"]
        if q not in quads:
            quads[q] = []
        quads[q].append(it)

    lines = ["# BCG Matrix Analysis Report\n"]
    lines.append(f"Products/Businesses: {len(items)} | Growth threshold: {pct(growth_threshold * 100)} | Share threshold: {share_threshold}\n")

    lines.append("## Classification Results\n")
    headers = ["Product", "Market Growth", "Relative Share", "Revenue", "Quadrant"]
    trows = [[it["product"], pct(it["growth"] * 100), f"{it['share']:.2f}",
              fmt_num(it["revenue"], 0) if it["revenue"] else "-", it["quadrant"]] for it in items]
    lines.append(md_table(headers, trows))

    lines.append("## Strategic Recommendations\n")
    for q_name, members in quads.items():
        lines.append(f"### {q_name} ({len(members)} items)\n")
        for m in members:
            lines.append(f"- **{m['product']}** — Growth {pct(m['growth'] * 100)}, Share {m['share']:.2f}")
        if "Star" in q_name:
            lines.append("→ Strategy: Increase investment, maintain growth\n")
        elif "Cash Cow" in q_name:
            lines.append("→ Strategy: Harvest profits, reduce investment\n")
        elif "Question" in q_name:
            lines.append("→ Strategy: Selective investment, or divest\n")
        else:
            lines.append("→ Strategy: Consider exit or restructuring\n")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── GE-McKinsey Matrix ─────────────────────────

GEMCKINSEY_HELP = """
GE-McKinsey Matrix: Industry Attractiveness × Competitive Strength → 9-cell classification

CSV Format:
  business,attractiveness,strength,revenue

  business       : Business/product name
  attractiveness : Industry attractiveness score (1-5)
  strength       : Competitive strength score (1-5)
  revenue        : Revenue (optional)

Example:
  business,attractiveness,strength,revenue
  BusinessA,4.5,4.0,5000
  BusinessB,2.0,3.5,3000
  BusinessC,3.8,2.0,2000
"""


def cmd_gemckinsey(args):
    rows = read_csv(args.input)
    required = {"business", "attractiveness", "strength"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    items = []
    for row_no, r in enumerate(rows, 2):
        a = fnum(r["attractiveness"], "attractiveness", row_no)
        s = fnum(r["strength"], "strength", row_no)
        rev = fnum(r.get("revenue", 0), "revenue", row_no)
        if a >= 3.67 and s >= 3.67:
            cell = "Invest/Grow"
        elif a >= 3.67 and s >= 2.33:
            cell = "Selective Investment"
        elif a >= 3.67:
            cell = "Selective Investment"
        elif a >= 2.33 and s >= 3.67:
            cell = "Selective Investment"
        elif a >= 2.33 and s >= 2.33:
            cell = "Selective Maintain"
        elif a >= 2.33:
            cell = "Harvest"
        elif s >= 3.67:
            cell = "Selective Maintain"
        elif s >= 2.33:
            cell = "Harvest"
        else:
            cell = "Exit/Divest"
        items.append({"business": r["business"], "attractiveness": a,
                       "strength": s, "revenue": rev, "cell": cell})

    cells = {}
    for it in items:
        c = it["cell"]
        if c not in cells:
            cells[c] = []
        cells[c].append(it)

    lines = ["# GE-McKinsey Matrix Analysis Report\n"]
    lines.append(f"Businesses: {len(items)}\n")

    lines.append("## Classification Results\n")
    headers = ["Business", "Industry Attractiveness", "Competitive Strength", "Revenue", "Strategy Zone"]
    trows = [[it["business"], f"{it['attractiveness']:.1f}", f"{it['strength']:.1f}",
              fmt_num(it["revenue"], 0) if it["revenue"] else "-", it["cell"]] for it in items]
    lines.append(md_table(headers, trows))

    lines.append("## Matrix View\n")
    lines.append("```")
    lines.append("              Competitive Strength")
    lines.append("              Strong(>3.67)  Medium(2.33-3.67)  Weak(<2.33)")
    for a_label, a_range in [("High(>3.67)", (3.67, 5.01)), ("Medium(2.33-3.67)", (2.33, 3.67)), ("Low(<2.33)", (0, 2.33))]:
        lines.append(f"Attractiveness {a_label}")
        for s_label, s_range in [("Strong", (3.67, 5.01)), ("Medium", (2.33, 3.67)), ("Weak", (0, 2.33))]:
            in_cell = [it for it in items if a_range[0] <= it["attractiveness"] < a_range[1]
                        and s_range[0] <= it["strength"] < s_range[1]]
            names = ", ".join(it["business"][:6] for it in in_cell) if in_cell else "·"
            lines.append(f"              {names:<20}")
    lines.append("```\n")

    lines.append("## Strategic Recommendations\n")
    for cell_name, members in cells.items():
        lines.append(f"### {cell_name} ({len(members)} items)\n")
        for m in members:
            lines.append(f"- **{m['business']}** — Attractiveness {m['attractiveness']:.1f}, Strength {m['strength']:.1f}")
        if cell_name == "Invest/Grow":
            lines.append("→ Aggressive investment, expand market share\n")
        elif cell_name == "Selective Investment":
            lines.append("→ Targeted investment, focus on strengths\n")
        elif cell_name == "Selective Maintain":
            lines.append("→ Maintain current position, control costs\n")
        elif cell_name == "Harvest":
            lines.append("→ Maximize cash flow, reduce new investment\n")
        else:
            lines.append("→ Consider exit or divestiture\n")

    if args.json:
        write_output(json.dumps(items, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: quant.py =====
"""Quantitative investment methodologies — Factor / Momentum / Risk Parity / Backtesting Performance"""

import json
import math
import sys



def get_ppy(args):
    """Periods per year for annualization (default 252 trading days)."""
    ppy = getattr(args, "periods_per_year", None)
    return float(ppy) if ppy else 252.0

# ───────────────────────── Factor Analysis ─────────────────────────

FACTOR_HELP = """
Factor Analysis: IC/IC_IR calculation + Group return + Monotonicity test

CSV Format (long table, one asset per cross-section):
  date,asset,factor_value,forward_return

  date           : Cross-section date
  asset          : Asset identifier
  factor_value   : Factor value
  forward_return : Forward return rate (decimal)

Additional parameters:
  --periods-per-year : Periods per year for annualization (default 252; use 12 for monthly)

Example:
  date,asset,factor_value,forward_return
  2024-01,A001,0.5,0.03
  2024-01,A002,-0.2,-0.01
  2024-01,A003,0.8,0.05
  2024-02,A001,0.6,0.02
"""


def cmd_factor(args):
    rows = read_csv(args.input)
    required = {"date", "asset", "factor_value", "forward_return"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    ppy = get_ppy(args)

    dates = {}
    for row_no, r in enumerate(rows, 2):
        d = r["date"]
        if d not in dates:
            dates[d] = []
        dates[d].append({
            "asset": r["asset"],
            "fv": fnum(r["factor_value"], "factor_value", row_no),
            "ret": fnum(r["forward_return"], "forward_return", row_no),
        })

    sorted_dates = sorted(dates.keys())
    if len(sorted_dates) < 2:
        print("At least 2 cross-section dates required", file=sys.stderr)
        sys.exit(1)

    ic_series = []
    group_returns = {g: [] for g in range(1, 6)}
    ls_returns = []
    skipped_sections = 0
    skipped_dates = []

    for d in sorted_dates:
        assets = dates[d]
        if len(assets) < 5:
            skipped_sections += 1
            skipped_dates.append(d)
            continue
        fvs = [a["fv"] for a in assets]
        rets = [a["ret"] for a in assets]

        ic = spearman_ic(fvs, rets)
        ic_series.append({"date": d, "ic": ic})

        sorted_assets = sorted(assets, key=lambda a: a["fv"])
        n = len(sorted_assets)
        group_means = []
        for g in range(5):
            start = g * n // 5
            end = (g + 1) * n // 5
            group = sorted_assets[start:end]
            avg_ret = sum(a["ret"] for a in group) / len(group)
            group_means.append(avg_ret)
            group_returns[g + 1].append(avg_ret)

        ls_returns.append(group_means[4] - group_means[0])

    ic_values = [x["ic"] for x in ic_series]
    ic_mean = sum(ic_values) / len(ic_values) if ic_values else 0
    ic_std = math.sqrt(sum((v - ic_mean) ** 2 for v in ic_values) / len(ic_values)) if len(ic_values) > 1 else 1
    ic_ir = ic_mean / ic_std if ic_std > 0 else 0
    ic_positive_rate = sum(1 for v in ic_values if v > 0) / len(ic_values) if ic_values else 0

    group_avg = {}
    for g in range(1, 6):
        vals = group_returns[g]
        group_avg[g] = sum(vals) / len(vals) if vals else 0

    monotonic = all(group_avg[i] <= group_avg[i + 1] for i in range(1, 5))
    ls_avg = sum(ls_returns) / len(ls_returns) if ls_returns else 0

    lines = ["# Factor Analysis Report\n"]
    if skipped_sections:
        lines.append(f"⚠️ Skipped {skipped_sections} cross-section(s) with fewer than 5 assets "
                     f"(IC and quintile grouping need ≥ 5 assets): {', '.join(skipped_dates[:10])}"
                     f"{'...' if len(skipped_dates) > 10 else ''}\n")
    lines.append(f"Cross-sections: {len(ic_series)} | Assets per cross-section: ~{len(rows) // max(len(sorted_dates), 1)}\n")

    lines.append("## IC Statistics\n")
    lines.append(f"- IC Mean: **{ic_mean:.4f}**")
    lines.append(f"- IC Std Dev: {ic_std:.4f}")
    lines.append(f"- IC_IR: **{ic_ir:.4f}**")
    lines.append(f"- IC > 0 ratio: {pct(ic_positive_rate * 100)}")
    lines.append(f"- Factor Effectiveness: {'✅ Effective (|IC| > 0.03)' if abs(ic_mean) > 0.03 else '⚠️ Weak (|IC| ≤ 0.03)'}")
    lines.append(f"- IC_IR Quality: {'✅ Excellent (>0.5)' if ic_ir > 0.5 else ('⚠️ Average' if ic_ir > 0.3 else '❌ Poor (<0.3)')}\n")

    lines.append("## Group Return (avg forward return)\n")
    headers = ["Group", "Avg Return", "Annualized"]
    trows = []
    for g in range(1, 6):
        label = f"G{g}" + (" (Bottom)" if g == 1 else " (Top)" if g == 5 else "")
        trows.append([label, pct(group_avg[g] * 100), pct(group_avg[g] * ppy * 100)])
    trows.append(["Long-Short (Top-Bottom)", pct(ls_avg * 100), pct(ls_avg * ppy * 100)])
    lines.append(md_table(headers, trows))

    lines.append(f"\n## Monotonicity Test: {'✅ Perfect monotonic' if monotonic else '⚠️ Non-perfect monotonic'}\n")

    lines.append("## IC Time Series (last 10 periods)\n")
    ic_headers = ["Date", "IC"]
    ic_trows = [[x["date"], f"{x['ic']:.4f}"] for x in ic_series[-10:]]
    lines.append(md_table(ic_headers, ic_trows))

    if args.json:
        result = {"ic_mean": ic_mean, "ic_std": ic_std, "ic_ir": ic_ir,
                   "ic_positive_rate": ic_positive_rate, "monotonic": monotonic,
                   "group_avg": {str(k): v for k, v in group_avg.items()},
                   "ls_avg": ls_avg, "ic_series": ic_series}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Momentum Analysis ─────────────────────────

MOMENTUM_HELP = """
Momentum signal analysis: Multi-period return calculation + Cross-section ranking + Group return

CSV Format (wide table, one date per row, asset prices as columns):
  date,asset1,asset2,asset3,...

  date  : Date
  assetN: Asset price (closing price)

Example:
  date,A001,A002,A003
  2024-01-01,100,50,200
  2024-01-02,102,49,203
  2024-01-03,105,48,205
"""


def cmd_momentum(args):
    rows = read_csv(args.input)
    if len(rows) < 2:
        print("At least 2 rows of data required", file=sys.stderr)
        sys.exit(1)

    assets = [k for k in rows[0].keys() if k != "date"]
    if len(assets) < 3:
        print("At least 3 assets required", file=sys.stderr)
        sys.exit(1)

    dates = []
    prices = {a: [] for a in assets}
    for row_no, r in enumerate(rows, 2):
        dates.append(r["date"])
        for a in assets:
            prices[a].append(fnum(r[a], a, row_no))

    n_dates = len(dates)

    lookbacks = [1, 5, 10, 21, 63]
    returns_by_lb = {}
    for lb in lookbacks:
        if n_dates <= lb:
            continue
        rets = {}
        for a in assets:
            p_now = prices[a][-1]
            p_prev = prices[a][-1 - lb]
            rets[a] = (p_now - p_prev) / p_prev if p_prev != 0 else 0
        returns_by_lb[lb] = rets

    lines = ["# Momentum Signal Analysis Report\n"]
    lines.append(f"Assets: {len(assets)} | Data points: {n_dates} | Date range: {dates[0]} ~ {dates[-1]}\n")

    lines.append("## Multi-Period Returns\n")
    headers = ["Asset"] + [f"{lb} periods" for lb in returns_by_lb.keys()]
    trows = []
    for a in assets:
        row = [a]
        for lb in returns_by_lb:
            row.append(pct(returns_by_lb[lb].get(a, 0) * 100))
        trows.append(row)
    lines.append(md_table(headers, trows))

    if returns_by_lb:
        main_lb = max(returns_by_lb.keys())
        rets = returns_by_lb[main_lb]
        ranked = sorted(assets, key=lambda a: rets.get(a, 0), reverse=True)

        lines.append(f"## Cross-Section Ranking ({main_lb} period momentum)\n")
        r_headers = ["Rank", "Asset", "Return", "Quintile"]
        r_trows = []
        for i, a in enumerate(ranked, 1):
            q = "Top" if i <= len(ranked) * 0.2 else ("Bottom" if i > len(ranked) * 0.8 else "Mid")
            r_trows.append([i, a, pct(rets.get(a, 0) * 100), q])
        lines.append(md_table(r_headers, r_trows))

        n = len(ranked)
        lines.append("## Group Return\n")
        g_headers = ["Group", "Assets", "Avg Return"]
        g_trows = []
        for g in range(5):
            start = g * n // 5
            end = (g + 1) * n // 5
            group = ranked[start:end]
            avg = sum(rets.get(a, 0) for a in group) / len(group) if group else 0
            label = f"G{g + 1}" + (" (Top)" if g == 0 else " (Bottom)" if g == 4 else "")
            g_trows.append([label, len(group), pct(avg * 100)])
        top_avg = sum(rets.get(a, 0) for a in ranked[:max(1, n // 5)]) / max(1, n // 5)
        bot_avg = sum(rets.get(a, 0) for a in ranked[-max(1, n // 5):]) / max(1, n // 5)
        g_trows.append(["Long-Short (Top-Bottom)", "-", pct((top_avg - bot_avg) * 100)])
        lines.append(md_table(g_headers, g_trows))

    if n_dates > 21:
        lines.append("## Rolling Momentum Signal\n")
        ppy = get_ppy(args)
        lb_ts = min(21, n_dates - 1)
        skip = 1
        eff_lb = lb_ts + skip
        portfolio_rets = []
        skipped_signals = 0
        for t in range(eff_lb, n_dates):
            if t + 1 >= n_dates:
                # No next-period price for this signal: skip it instead of
                # counting a fabricated 0% return.
                skipped_signals += 1
                continue
            mom = {}
            for a in assets:
                p1 = prices[a][t - eff_lb]
                p2 = prices[a][t - skip]
                mom[a] = (p2 - p1) / p1 if p1 != 0 else 0
            ranked_a = sorted(assets, key=lambda x: mom.get(x, 0), reverse=True)
            top_n = max(1, len(ranked_a) // 5)
            top_assets = ranked_a[:top_n]
            port_ret = sum(
                (prices[a][t + 1] - prices[a][t]) / prices[a][t]
                for a in top_assets if prices[a][t] != 0
            ) / len(top_assets)
            portfolio_rets.append(port_ret)

        if portfolio_rets:
            avg_ret = sum(portfolio_rets) / len(portfolio_rets)
            vol = math.sqrt(sum((r - avg_ret) ** 2 for r in portfolio_rets) / len(portfolio_rets)) if len(portfolio_rets) > 1 else 0
            sharpe = (avg_ret * ppy) / (vol * math.sqrt(ppy)) if vol > 0 else 0
            win_rate = sum(1 for r in portfolio_rets if r > 0) / len(portfolio_rets)
            lines.append(f"- Lookback period: {lb_ts} periods, skip last {skip} period")
            if skipped_signals:
                lines.append(f"- ⚠️ Skipped {skipped_signals} trailing signal(s) with no next-period return (excluded, not counted as 0%)")
            lines.append(f"- Equal-weight Top 20% Portfolio avg daily return: {pct(avg_ret * 100)}")
            lines.append(f"- Annualized volatility: {pct(vol * math.sqrt(ppy) * 100)}")
            lines.append(f"- Annualized Sharpe: {sharpe:.2f}")
            lines.append(f"- Daily win rate: {pct(win_rate * 100)}")

    if args.json:
        result = {"assets": assets, "n_dates": n_dates,
                   "returns": {lb: rets for lb, rets in returns_by_lb.items()}}
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Risk Parity ─────────────────────────

RISKPARITY_HELP = """
Risk Parity Weighting: Iterative risk contribution equal weighting + Risk decomposition

CSV Format (wide table, one period per row, asset returns as columns):
  period,asset1,asset2,asset3,...

  period : Period identifier
  assetN : Period return (decimal)

Additional parameters:
  --periods-per-year : Periods per year for covariance annualization (default 252; use 12 for monthly)

Example:
  period,stocks,bonds,commodities,reits
  2020-01,0.02,-0.01,0.03,0.01
  2020-02,-0.03,0.02,-0.01,-0.02
  2020-03,0.01,0.01,0.02,0.03
"""


def cmd_riskparity(args):
    rows = read_csv(args.input)
    ppy = get_ppy(args)
    assets = [k for k in rows[0].keys() if k != "period"]
    n_assets = len(assets)
    if n_assets < 2:
        print("At least 2 assets required", file=sys.stderr)
        sys.exit(1)

    returns = []
    for row_no, r in enumerate(rows, 2):
        returns.append([fnum(r[a], a, row_no) for a in assets])
    n_obs = len(returns)
    if n_obs < n_assets + 1:
        print(f"Insufficient data: {n_obs} periods, recommend at least {n_assets + 1} periods", file=sys.stderr)

    means = [sum(returns[t][i] for t in range(n_obs)) / n_obs for i in range(n_assets)]
    cov = [[0.0] * n_assets for _ in range(n_assets)]
    for i in range(n_assets):
        for j in range(n_assets):
            s = sum((returns[t][i] - means[i]) * (returns[t][j] - means[j]) for t in range(n_obs))
            cov[i][j] = s / (n_obs - 1) * ppy

    # Volatility-inverse weighting as initial value
    asset_vols_init = [math.sqrt(max(cov[i][i], 1e-12)) for i in range(n_assets)]
    w = [1.0 / v for v in asset_vols_init]
    total = sum(w)
    w = [x / total for x in w]

    lr = 0.05
    eps = 1e-7
    for iteration in range(5000):
        sw = mat_mult(cov, [[w[i]] for i in range(n_assets)])
        sp2 = max(sum(w[i] * sw[i][0] for i in range(n_assets)), 1e-15)
        sp = math.sqrt(sp2)
        target = sp / n_assets
        rc = [w[i] * sw[i][0] / sp for i in range(n_assets)]

        obj = sum((rc[i] - target) ** 2 for i in range(n_assets))
        if obj < 1e-14:
            break

        grad = [0.0] * n_assets
        for k in range(n_assets):
            wp = w[:]
            wp[k] += eps
            sw_p = mat_mult(cov, [[wp[i]] for i in range(n_assets)])
            sp_p = math.sqrt(max(sum(wp[i] * sw_p[i][0] for i in range(n_assets)), 1e-15))
            target_p = sp_p / n_assets
            rc_p = [wp[i] * sw_p[i][0] / sp_p for i in range(n_assets)]
            obj_p = sum((rc_p[i] - target_p) ** 2 for i in range(n_assets))
            grad[k] = (obj_p - obj) / eps

        w_new = [max(1e-8, w[i] - lr * grad[i]) for i in range(n_assets)]
        total = sum(w_new)
        w_new = [x / total for x in w_new]

        if max(abs(w_new[i] - w[i]) for i in range(n_assets)) < 1e-10:
            w = w_new
            break
        w = w_new

    sigma_w_final = mat_mult(cov, [[w[i]] for i in range(n_assets)])
    sigma_p_final = math.sqrt(sum(w[i] * sigma_w_final[i][0] for i in range(n_assets)))
    rc_final = [w[i] * sigma_w_final[i][0] / sigma_p_final for i in range(n_assets)]
    rc_pct = [rc / sigma_p_final * 100 if sigma_p_final > 0 else 0 for rc in rc_final]
    mrc = [sigma_w_final[i][0] / sigma_p_final if sigma_p_final > 0 else 0 for i in range(n_assets)]

    w_eq = [1.0 / n_assets] * n_assets
    sigma_eq = math.sqrt(quad_form(w_eq, cov))
    asset_vols = [math.sqrt(cov[i][i]) for i in range(n_assets)]

    lines = ["# Risk Parity Configuration Report\n"]
    lines.append(f"Assets: {n_assets} | Data periods: {n_obs}\n")

    lines.append("## Asset Volatility\n")
    v_headers = ["Asset", "Annualized Volatility"]
    v_trows = [[assets[i], pct(asset_vols[i] * 100)] for i in range(n_assets)]
    lines.append(md_table(v_headers, v_trows))

    lines.append("## Risk Parity Weights\n")
    headers = ["Asset", "RP Weight", "Risk Contribution", "Risk Contribution %", "Marginal Risk"]
    trows = []
    for i in range(n_assets):
        trows.append([
            assets[i], pct(w[i] * 100), f"{rc_final[i]:.4f}",
            pct(rc_pct[i]), f"{mrc[i]:.4f}"
        ])
    trows.append(["Total", pct(sum(w) * 100), f"{sigma_p_final:.4f}", pct(sum(rc_pct)), "-"])
    lines.append(md_table(headers, trows))

    div_rp = sigma_eq / sigma_p_final if sigma_p_final > 0 else 1
    lines.append("## Comparison Analysis\n")
    c_headers = ["Approach", "Portfolio Volatility", "Diversification Ratio"]
    c_trows = [
        ["Risk Parity", pct(sigma_p_final * 100), f"{div_rp:.2f}x"],
        ["Equal Weight", pct(sigma_eq * 100), "1.00x"],
    ]
    lines.append(md_table(c_headers, c_trows))

    lines.append("## Risk Balance Check\n")
    max_dev = max(abs(rc_pct[i] - 100 / n_assets) for i in range(n_assets))
    lines.append(f"- Target risk contribution: {pct(100 / n_assets)} (per asset)")
    lines.append(f"- Max deviation: {pct(max_dev)}")
    lines.append(f"- Balance status: {'✅ Converged' if max_dev < 1 else '⚠️ Not fully converged'}")

    if args.json:
        result = {
            "assets": assets, "weights": {assets[i]: w[i] for i in range(n_assets)},
            "risk_contributions": {assets[i]: rc_final[i] for i in range(n_assets)},
            "risk_contrib_pct": {assets[i]: rc_pct[i] for i in range(n_assets)},
            "portfolio_vol": sigma_p_final, "equal_weight_vol": sigma_eq,
            "diversification_ratio": div_rp,
        }
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)


# ───────────────────────── Strategy Performance ─────────────────────────

PERF_HELP = """
Strategy Performance Metrics: Sharpe / Sortino / Calmar / Max Drawdown / VaR / Win Rate

CSV Format:
  date,return

  date   : Date
  return : Period return (decimal)

Optional column:
  benchmark : Benchmark return (decimal, for information ratio/excess return)

Additional parameters:
  --periods-per-year : Periods per year for annualization (default 252; use 12 for monthly)

Example:
  date,return,benchmark
  2024-01-02,0.005,0.003
  2024-01-03,-0.002,0.001
  2024-01-04,0.008,0.005
"""


def cmd_perf(args):
    rows = read_csv(args.input)
    required = {"date", "return"}
    if not required.issubset(rows[0].keys()):
        print(f"CSV missing columns: {required - set(rows[0].keys())}", file=sys.stderr)
        sys.exit(1)

    has_benchmark = "benchmark" in rows[0].keys()
    ppy = get_ppy(args)
    dates = []
    rets = []
    bench_rets = []
    for row_no, r in enumerate(rows, 2):
        dates.append(r["date"])
        rets.append(fnum(r["return"], "return", row_no))
        if has_benchmark:
            bench_rets.append(fnum(r["benchmark"], "benchmark", row_no))

    n = len(rets)
    if n < 5:
        print("At least 5 periods of data required", file=sys.stderr)
        sys.exit(1)

    mean_ret = sum(rets) / n
    var_ret = sum((r - mean_ret) ** 2 for r in rets) / (n - 1) if n > 1 else 0
    std_ret = math.sqrt(var_ret)
    ann_ret = mean_ret * ppy
    ann_vol = std_ret * math.sqrt(ppy)

    cum = 1.0
    cum_rets = []
    for r in rets:
        cum *= (1 + r)
        cum_rets.append(cum)
    total_ret = cum - 1

    peak = cum_rets[0]
    max_dd = 0
    dd_start = 0
    dd_end = 0
    current_dd_start = 0
    for i, c in enumerate(cum_rets):
        if c > peak:
            peak = c
            current_dd_start = i
        dd = (peak - c) / peak
        if dd > max_dd:
            max_dd = dd
            dd_start = current_dd_start
            dd_end = i

    dd_duration = dd_end - dd_start

    # Downside deviation, standard definition: sum of squared negative returns
    # divided by the FULL sample size n (not the count of loss periods), so a
    # strategy with few losing periods is not under-penalized.
    downside_rets = [r for r in rets if r < 0]
    down_std = math.sqrt(sum(r ** 2 for r in downside_rets) / n) if downside_rets else 0
    ann_down_std = down_std * math.sqrt(ppy)

    sharpe = ann_ret / ann_vol if ann_vol > 0 else 0
    sortino = ann_ret / ann_down_std if ann_down_std > 0 else 0
    calmar = ann_ret / max_dd if max_dd > 0 else 0

    win_rate = sum(1 for r in rets if r > 0) / n

    avg_win = sum(r for r in rets if r > 0) / sum(1 for r in rets if r > 0) if any(r > 0 for r in rets) else 0
    avg_loss = abs(sum(r for r in rets if r < 0) / sum(1 for r in rets if r < 0)) if any(r < 0 for r in rets) else 0
    pl_ratio = avg_win / avg_loss if avg_loss > 0 else 0

    sorted_rets = sorted(rets)
    var_95 = sorted_rets[max(0, int(n * 0.05))]
    var_99 = sorted_rets[max(0, int(n * 0.01))]

    cvar_95_n = max(1, int(n * 0.05))
    cvar_95 = sum(sorted_rets[:cvar_95_n]) / cvar_95_n

    if std_ret > 0:
        skew = sum((r - mean_ret) ** 3 for r in rets) / n / (std_ret ** 3)
        kurt = sum((r - mean_ret) ** 4 for r in rets) / n / (std_ret ** 4) - 3
    else:
        skew = 0
        kurt = 0

    excess_data = {}
    if has_benchmark:
        bench_mean = sum(bench_rets) / n
        bench_cum = 1.0
        bench_cum_rets = []
        for r in bench_rets:
            bench_cum *= (1 + r)
            bench_cum_rets.append(bench_cum)
        bench_total = bench_cum - 1
        bench_ann = bench_mean * ppy

        excess_rets = [rets[i] - bench_rets[i] for i in range(n)]
        excess_mean = sum(excess_rets) / n
        excess_ann = excess_mean * ppy
        excess_var = sum((r - excess_mean) ** 2 for r in excess_rets) / (n - 1)
        te = math.sqrt(excess_var * ppy)
        ir = excess_ann / te if te > 0 else 0

        excess_data = {
            "bench_total": bench_total, "bench_ann": bench_ann,
            "excess_ann": excess_ann, "te": te, "ir": ir,
        }

    lines = ["# Strategy Performance Analysis Report\n"]
    lines.append(f"Data periods: {n} | Date range: {dates[0]} ~ {dates[-1]}\n")

    lines.append("## Return Metrics\n")
    lines.append(f"- Cumulative return: **{pct(total_ret * 100)}**")
    lines.append(f"- Annualized return: **{pct(ann_ret * 100)}**")
    lines.append(f"- Daily avg return: {pct(mean_ret * 100)}")
    if has_benchmark:
        lines.append(f"- Benchmark cumulative return: {pct(excess_data['bench_total'] * 100)}")
        lines.append(f"- Annualized excess return: {pct(excess_data['excess_ann'] * 100)}")
    lines.append("")

    lines.append("## Risk Metrics\n")
    lines.append(f"- Annualized volatility: {pct(ann_vol * 100)}")
    lines.append(f"- Max drawdown: **{pct(max_dd * 100)}**")
    lines.append(f"- Drawdown period: {dates[dd_start]} ~ {dates[dd_end]} ({dd_duration} periods)")
    lines.append(f"- VaR (95%): {pct(var_95 * 100)}")
    lines.append(f"- CVaR (95%): {pct(cvar_95 * 100)}")
    lines.append(f"- VaR (99%): {pct(var_99 * 100)}")
    lines.append("")

    lines.append("## Risk-Adjusted Return\n")
    lines.append(f"- Sharpe ratio: **{sharpe:.2f}**")
    lines.append(f"- Sortino ratio: **{sortino:.2f}**")
    lines.append(f"- Calmar ratio: **{calmar:.2f}**")
    if has_benchmark:
        lines.append(f"- Information ratio: **{excess_data['ir']:.2f}**")
        lines.append(f"- Tracking error: {pct(excess_data['te'] * 100)}")
    lines.append("")

    lines.append("## Trading Statistics\n")
    lines.append(f"- Win rate: {pct(win_rate * 100)}")
    lines.append(f"- Profit/loss ratio: {pl_ratio:.2f}")
    lines.append(f"- Avg win: {pct(avg_win * 100)}")
    lines.append(f"- Avg loss: {pct(avg_loss * 100)}")
    lines.append(f"- Max single-day gain: {pct(max(rets) * 100)}")
    lines.append(f"- Max single-day loss: {pct(min(rets) * 100)}")
    lines.append("")

    lines.append("## Distribution Features\n")
    lines.append(f"- Skewness: {skew:.3f}")
    lines.append(f"- Excess kurtosis: {kurt:.3f}")
    lines.append("- Positive skew indicates longer right tail; high kurtosis indicates extreme events more likely than normal")

    lines.append("\n## Quality Rating\n")
    if sharpe >= 2:
        lines.append("- Sharpe: ✅ Excellent (≥2)")
    elif sharpe >= 1:
        lines.append("- Sharpe: ⚠️ Acceptable (1-2)")
    else:
        lines.append("- Sharpe: ❌ Poor (<1)")
    if max_dd < 0.10:
        lines.append("- Max drawdown: ✅ Controllable (<10%)")
    elif max_dd < 0.20:
        lines.append("- Max drawdown: ⚠️ Moderate (10-20%)")
    else:
        lines.append("- Max drawdown: ❌ Severe (>20%)")
    if win_rate >= 0.55:
        lines.append("- Win rate: ✅ Good (≥55%)")
    else:
        lines.append("- Win rate: ⚠️ Low (<55%)")

    if args.json:
        result = {
            "n_periods": n, "total_return": total_ret, "ann_return": ann_ret,
            "ann_vol": ann_vol, "max_drawdown": max_dd, "dd_start": dates[dd_start],
            "dd_end": dates[dd_end], "sharpe": sharpe, "sortino": sortino,
            "calmar": calmar, "win_rate": win_rate, "pl_ratio": pl_ratio,
            "var_95": var_95, "cvar_95": cvar_95, "skewness": skew, "kurtosis": kurt,
        }
        if has_benchmark:
            result.update(excess_data)
        write_output(json.dumps(result, ensure_ascii=False, indent=2), args.output)
    else:
        write_output("\n".join(lines), args.output)

# ===== merged from: main.py =====
"""CLI entry point — argparse subcommand registration and dispatch."""

import argparse
import sys



def main():
    parser = argparse.ArgumentParser(
        prog="kueiku-calc",
        description="Kueiku Methodology calculation toolkit — 19 computation-heavy methodology automations",
    )
    subparsers = parser.add_subparsers(dest="command", help="subcommand")

    def add_common_args(p):
        p.add_argument("-i", "--input", required=True, help="CSV file path (- for stdin)")
        p.add_argument("-o", "--output", help="Output file path (default stdout)")
        p.add_argument("--json", action="store_true", help="Output in JSON format")

    # Decision & prioritization
    p = subparsers.add_parser("rice", help="RICE priority scoring", description=RICE_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("dmatrix", help="Decision Matrix (Pugh Matrix)", description=DMATRIX_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("ice", help="ICE scoring", description=ICE_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    # Risk assessment
    p = subparsers.add_parser("risk", help="Risk Matrix", description=RISK_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("fmea", help="FMEA FMEA failure mode analysis", description=FMEA_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("pareto", help="Pareto Analysis", description=PARETO_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    # Financial analysis
    p = subparsers.add_parser("dupont", help="DuPont Analysis", description=DUPONT_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("dcf", help="DCF valuation", description=DCF_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)
    p.add_argument("--rate", type=float, default=0.10, help="Discount rate (WACC), default 0.10")
    p.add_argument("--growth", type=float, default=0.03, help="Perpetual growth rate, default 0.03")
    p.add_argument("--shares", type=float, default=0, help="Shares outstanding (optional)")

    p = subparsers.add_parser("eva", help="Economic Value Added", description=EVA_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    # Data analysis
    p = subparsers.add_parser("abtest", help="A/B Test significance analysis", description=ABTEST_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("rfm", help="RFM UserSegmentation", description=RFM_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("cohort", help="Cohort retention analysis", description=COHORT_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    # Strategy matrices
    p = subparsers.add_parser("oppscore", help="Opportunity scoring", description=OPPSCORE_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("bcg", help="BCG Matrix", description=BCG_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    p = subparsers.add_parser("gemckinsey", help="GE-McKinsey Matrix", description=GEMCKINSEY_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)

    # Quantitative investment
    def add_periods_per_year(p):
        p.add_argument("--periods-per-year", type=float, default=252,
                       help="Periods per year for annualization (default 252 trading days; "
                            "use 12 for monthly data, 52 for weekly data)")

    p = subparsers.add_parser("factor", help="Factor analysis (IC/Group/Monotonicity)", description=FACTOR_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)
    add_periods_per_year(p)

    p = subparsers.add_parser("momentum", help="Momentum signal analysis", description=MOMENTUM_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)
    add_periods_per_year(p)

    p = subparsers.add_parser("riskparity", help="Risk parityWeight", description=RISKPARITY_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)
    add_periods_per_year(p)

    p = subparsers.add_parser("perf", help="StrategyPerformanceMetric", description=PERF_HELP,
                               formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common_args(p)
    add_periods_per_year(p)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "rice": cmd_rice, "dmatrix": cmd_dmatrix, "risk": cmd_risk,
        "dupont": cmd_dupont, "pareto": cmd_pareto, "fmea": cmd_fmea,
        "ice": cmd_ice, "oppscore": cmd_oppscore, "dcf": cmd_dcf,
        "eva": cmd_eva, "abtest": cmd_abtest, "rfm": cmd_rfm,
        "cohort": cmd_cohort, "bcg": cmd_bcg, "gemckinsey": cmd_gemckinsey,
        "factor": cmd_factor, "momentum": cmd_momentum,
        "riskparity": cmd_riskparity, "perf": cmd_perf,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
