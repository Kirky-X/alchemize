#!/bin/sh
# kueiku compact — extract one methodology's full text from the aggregated volume.
# usage: get_methodology.sh <category_dir> "<Methodology Name>"
#   category_dir: one of the data/fulltext/<category_dir>.md stems (see data/methodologies.tsv)
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cat_dir=${1:?usage: get_methodology.sh <category_dir> "<Methodology Name>"}
name=${2:?usage: get_methodology.sh <category_dir> "<Methodology Name>"}
file="$BASE/data/fulltext/$cat_dir.md"
[ -f "$file" ] || { echo "unknown category_dir: $cat_dir" >&2; exit 2; }
grep -Fqx "## $name" "$file" || { echo "methodology not found: $name (in $cat_dir)" >&2; exit 3; }
awk -v pat="## $name" '
  $0 == pat { if (found) exit; found = 1; buf = $0 "\n"; next }
  found && /^## / { exit }
  found { buf = buf $0 "\n" }
  END { if (found) { sub(/\n+$/, "\n", buf); printf "%s", buf } }
' "$file"
