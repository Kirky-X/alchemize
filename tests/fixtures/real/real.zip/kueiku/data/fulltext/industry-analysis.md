# Industry Analysis (compact aggregate)
> Aggregated from `references/industry-analysis/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh industry-analysis "<methodology>"`

## Industry Value Chain
> source: industry-value-chain.md
### Core Concept
Map the full chain from raw materials to end users, identifying value creation and profit distribution at each stage. Reveals profit pools, shift trends, and strategic positioning opportunities.

### Applicable Scenarios
✅ **Best for**
- Industry entry decisions
- Value chain positioning
- M&A target screening

⚠️ **When NOT to use**
- Digital products with no physical chain — raw materials to retail decomposes into nothing, and the real constraints are channel and network effects → **Wardley Mapping**
- You compete inside one stage, not across the chain — mapping the chain tells you nothing about your own unit economics or segment attractiveness → segment-level pricing and margin analysis instead
- The chain is stable and the question is growth mechanics — value-chain mapping is a positioning tool, not an execution plan → **North Star Framework** and **Cohort Analysis**
- Stage data is thin or hearsay — profit pools claimed from memory or a single vendor report; a chain built on invented numbers produces confident nonsense → source each stage's economics before drawing conclusions

### Key Steps
1. Map the industry value chain stages (raw materials → manufacturing → distribution → retail → end user)
2. For each stage, estimate: revenue pool, profit margin, growth rate
3. Identify profit pool shifts: where are margins migrating?
4. Assess your current position and potential entry points
5. Evaluate competitive dynamics at each stage
6. Make positioning decision based on profit pool trends

### Output Template

```
Chain definition: [stages from [upstream source] to end user, named for this industry]
Stage economics: [stage | revenue pool | margin % | growth % | concentration | data source]
Profit pool shift: [from stage → to stage | direction | time window | driver]
Our position: [stage we compete in | what we own vs. what we outsource]
Entry candidates: [stage | why it is attractive | what we would need | main barrier]
Chosen positioning: [stage + what we do differently | why it is defensible]
```

### Failure Modes
- Generic chain: the same raw-materials-to-retail template pasted onto every industry → draw the chain from this industry's actual transactions; a generic chain produces generic strategy
- Unsupported numbers: profit pools estimated from memory and presented as fact → tag every estimate with its source and confidence, and mark unknowns as unknown rather than interpolating them
- Chain as a snapshot: margins move faster than the map → re-derive the pool split on a fixed cadence and note which single assumption the conclusion depends on
- Entry chosen by the map alone: an attractive pool is assumed to be enterable → test entry feasibility (capital, channel access, incumbent response) before committing

### Evidence Strength
Practitioner consensus — Porter's value chain is a durable structuring tool with a large strategy-practice and consulting base, and the underlying mechanics (value accrues where differentiation and buyer power are favorable) are well established. The mapping itself is an interpretive act rather than a measurement, and stage-level profit data is frequently thin, proprietary, or estimated, so the framework reliably generates hypotheses and entry candidates while its conclusions inherit the quality of the numbers fed into it.

### Source
Michael Porter, *Competitive Advantage* (1985); value chain analysis framework.

## Gartner Hype Cycle
> source: gartner-hype-cycle.md
### Core Concept
5-stage technology maturity model: Technology Trigger → Peak of Inflated Expectations → Trough of Disillusionment → Slope of Enlightenment → Plateau of Productivity. Helps time technology investments and adoption decisions.

### Applicable Scenarios
✅ **Best for**
- Technology investment timing
- New technology adoption decisions
- Technology roadmap planning

⚠️ **When NOT to use**
- Timing an individual product bet — stage labels describe technology categories, not your one product; a product built on a "trough" technology can still fail on its own merits → validate the bet with **A/B Test Analysis** and unit economics
- Technology maturity is not the decision variable — when the real question is distribution, pricing, or regulation, the cycle stage changes nothing → **Industry Value Chain**
- No credible published stage exists for the technology — for genuinely new technology there is no assessment to cite, and assigning a stage from a blog post manufactures false precision
- Using a stage label to describe your own company — the cycle is descriptive, so "we are early on a hype-cycle technology" is an unfalsifiable claim that reframes any outcome as success

### Key Steps
1. Identify the target technology
2. Determine current Hype Cycle stage using Gartner reports or equivalent assessment
3. Assess: is the technology past the Trough (approaching productivity) or still inflated?
4. For early-stage tech: plan for experimentation, not production
5. For maturing tech: plan pilots and proof-of-concepts
6. For mature tech: plan production adoption and optimization

### Output Template

```
Technology: [name + the category it belongs to]
Cycle position: [stage name] — basis: [analyst report or equivalent assessment + date]
Signal evidence: [what supports the placement — deployments, standards, funding, adoption numbers]
Decision mode: [experiment | pilot | production adoption | hold]
Budget + horizon: [spend | date to revisit]
If wrong: [the assumption that breaks first | the trigger that pivots the decision]
```

### Failure Modes
- Stage label as the decision: "it is in the trough, so adopt" — the label carries no cost, timeline, or integration requirement → name the actual investment and the trigger that starts it
- False precision on unknown technology: a stage is assigned to a technology no analyst has covered → mark the position "unassessed" and run a small pilot to generate your own evidence
- Vendor narrative capture: the publisher of the cycle also sells research and advisory into the same technology space → triangulate with deployment counts and standards progress, not analyst commentary alone
- Hype as strategy: pairing a cycle position with a marketing claim ("we are at the innovation trigger") → the label lends credibility that the underlying facts have to earn
- Plateau misread as safety: the plateau phase is where incumbents with distribution attack → compare against incumbent incentives, not against the curve position

### Evidence Strength
Contested — the Gartner Hype Cycle is a descriptive communication device, not a measurement instrument. Stage placement is an analyst judgment published as a narrative rather than derived from a repeatable method, and its predictive validity is contested: published placements are frequently disputed or revised as technologies develop, and the framework's survival is better explained by its value as shared vocabulary than by its forecasting accuracy. It works well as a forcing function — it makes the team state a decision mode and a timing horizon — and it should be treated as a prompt to think about adoption, never as evidence for the answer.

### Source
Gartner Group (1995); annual Hype Cycle reports across 30+ technology domains.

## Category Guide
## Industry Analysis

**When to use**: Need to understand industry structure, value distribution, technology maturity for entry/investment decisions


### Minimum Information Requirements per Methodology

- **Industry Value Chain**: Industry chain stage list + financial/profit data per stage
- **Gartner Hype Cycle**: Target technology name + Gartner current year report or equivalent maturity assessment

### Routing Trigger Signals

- "Industry value distribution / profit pool / value chain positioning / M&A target" → Industry Value Chain (primary)
- "Technology maturity / new technology adoption timing / technology roadmap" → Gartner Hype Cycle (primary)
- "Entering new industry / industry structure analysis" → Industry Value Chain (primary)

### Common Combinations

- **Industry entry decision**: Systematic Research Process (information gathering) → Industry Value Chain (value distribution) → Porter's Five Forces (competitive landscape) → Gartner Hype Cycle (technology timing)
- **Technology investment decision**: Gartner Hype Cycle (maturity) → Industry Value Chain (value chain positioning) → DCF (ROI assessment)
- **M&A target screening**: Industry Value Chain (identify value shift direction) → Comparable Company (valuation) → DuPont Analysis (financial quality)
