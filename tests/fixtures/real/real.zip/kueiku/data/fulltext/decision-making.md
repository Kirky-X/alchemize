# Decision Making (compact aggregate)
> Aggregated from `references/decision-making/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh decision-making "<methodology>"`

## RICE Scoring
> source: rice.md
### Core Concept
Quantify priority using Reach × Impact × Confidence ÷ Effort. Each dimension is scored on a defined scale, producing a comparable priority number for ranking features, projects, or initiatives.

### Applicable Scenarios
✅ **Best for**
- Product roadmap prioritization
- Requirement ranking across teams
- Resource allocation decisions

⚠️ **When NOT to use**
- Effort is the binding constraint and the question is sequencing, not value density — RICE says "value per person-month", not "what ships first"; pair with delivery capacity and **Reversibility Grading** for quick-win ordering
- Strategic bets and platform infrastructure — low Reach today, compounding payoff later; RICE structurally starves them, so keep a strategic reserve outside the scoring
- Confidence has no evidence behind it — the 50/80/100% knob launders vibes into a number; if no data or user input exists, run discovery first
- Compliance or executive-mandated items — they don't compete for score; exempt them from the ranking before it starts

### Key Steps
1. List all candidate items (features, projects, initiatives)
2. Score Reach: how many users/customers will this affect per period?
3. Score Impact: how much will this move the metric? (3=massive, 2=high, 1=medium, 0.5=low, 0.25=minimal)
4. Score Confidence: how sure are we? (100%=high, 80%=medium, 50%=low)
5. Score Effort: person-months required
6. Calculate RICE = (Reach × Impact × Confidence) / Effort
7. Sort by RICE score descending

### Output Template
```
RICE Prioritization:
| Item | Reach | Impact | Confidence | Effort | RICE Score |
|------|-------|--------|------------|--------|------------|
| A    | 1000  | 3      | 80%        | 2      | 1200       |
| B    | 500   | 2      | 100%       | 1      | 1000       |

Tier Recommendations:
  High priority (top 30%): [...]
  Medium priority: [...]
  Low priority (defer): [...]
```

### Failure Modes
- Effort estimated by the proposer is systematically optimistic: the denominator drives the score as hard as Reach → take Effort from an independent estimate or cap it in calendar time
- Impact numbers without a metric: "3 = massive" of what? → bind each Impact score to a named metric with a directional estimate before scoring
- Reach inflated to the whole user base for features only a segment touches → define Reach as the users who actually encounter the change per period
- Confidence as comfort: the percentage expresses stakeholder mood, not evidence → attach an evidence tag (data / user input / opinion) to every Confidence score
- Score worship: RICE becomes the roadmap instead of an input → treat the ranking as a proposal; strategy, dependencies, and commitments can override it with stated reasons

### Evidence Strength
Practitioner consensus — Intercom's published prioritization scheme, widely adopted in product management; it disciplines prioritization conversations by forcing explicit Reach, metric-bound Impact, and evidence-tagged Confidence. The arithmetic is exact only on judgment inputs: no research validates the specific scales or shows RICE rankings outperform other prioritization schemes on delivered outcomes.

### Source
Intercom product team; widely adopted in product management.

## Eisenhower Matrix
> source: eisenhower.md
### Core Concept
Time management using Importance × Urgency 4-quadrant classification: Do (important+urgent), Schedule (important+not urgent), Delegate (not important+urgent), Eliminate (not important+not urgent).

### Applicable Scenarios
✅ **Best for**
- Personal/team task management
- Resource allocation decisions
- Time management improvement

⚠️ **When NOT to use**
- Tasks with wildly different effort or consequence sizes — a 5-minute email and a quarter-long project don't share a quadrant; bucket by scale first
- Parallel identical workstreams — throughput queueing (WIP limits) fits better than 2×2 sorting
- Using it as the team's only prioritization tool — it sequences work but cannot value it; pair with RICE/MoSCoW for the what, not just the when

### Key Steps
1. List all current tasks
2. For each task, assess: Is it important? (does it contribute to long-term goals?)
3. For each task, assess: Is it urgent? (does it require immediate attention?)
4. Place each task in the appropriate quadrant
5. Act: Do Q1 tasks now, Schedule Q2 tasks, Delegate Q3 tasks, Eliminate Q4 tasks

### Output Template

```
Q1 Do (important + urgent)          — cap: [n], else escalate/renegotiate
  1. [prod incident] — owner [x], by [today]
Q2 Schedule (important, not urgent) — the growth quadrant; timebox: [calendar blocks protected]
  1. [quarterly architecture review] — block: [Fri 10-12]
Q3 Delegate (not important, urgent) — delegate to [who], with what authority
  1. [vendor scheduling] → [ops] — full authority
Q4 Eliminate (neither)              — say no explicitly
  1. [reply-all thread] — dropped

Q1 source check: how many Q1 items originated as neglected Q2 items? [answer — the real lever]
```

### Failure Modes
- Importance judged by requester loudness — Q3 tasks arrive dressed as Q1 → define importance against written goals before sorting; loudness is urgency's costume
- Q2 perpetually postponed: the quadrant gets scheduled, then sacrificed to Q1 fires → protect Q2 with calendar blocks reviewed weekly, or the matrix only accelerates firefighting
- Elimination never happens: Q4 items linger out of guilt → deletion is the quadrant's action; if nothing was dropped this week, re-examine the sort

### Evidence Strength
Practitioner consensus — a widely taught heuristic whose value is the important/urgent distinction itself (documented failure mode: urgent crowds out important); the 2×2 packaging and quadrant prescriptions are convention, and there is no controlled evidence that matrix use alone improves productivity — its effect runs through protecting Q2 time.

### Source
Attributed to Dwight D. Eisenhower; popularized by Stephen Covey in *The 7 Habits of Highly Effective People*.

## OKR
> source: okr.md (original title: OKR — Objectives and Key Results)
### Core Concept
Goal-setting framework: Objectives define "what we want to achieve" (qualitative, inspiring), Key Results define "how we'll measure progress" (quantitative, time-bound). Typically set quarterly.

### Applicable Scenarios
✅ **Best for**
- Quarterly/annual goal setting
- Team alignment
- Tracking progress toward strategic goals

⚠️ **When NOT to use**
- The metrics are already agreed and on track — keep a dashboard; OKR buys focus and stretch, not bookkeeping
- Compensation or performance reviews tie directly to KR scores — sandbagging follows within a quarter; keep OKR and pay on separate tracks
- The team cannot commit to fewer than five Objectives — that is a prioritization failure (RICE / MoSCoW); OKR on an unpruned list is focus theater
- The open question is which metrics strategy should even be measured on → run the Balanced-Scorecard Recipe below first, then let OKR move the chosen metrics

### Key Steps
1. Define 3-5 Objectives (qualitative, inspiring, time-bound)
2. For each Objective, define 2-5 Key Results (quantitative, measurable)
3. Key Results should be ambitious (70% achievement = good)
4. Assign owners for each KR
5. Review weekly/monthly; adjust if needed
6. End-of-quarter retrospective: score each KR 0-1.0

### Output Template

```
Objective: [qualitative, inspiring, time-bound]
  KR1: [metric from X to Y by date] — owner: [name]
  KR2: [...] (2-5 per Objective)
Confidence at check-in: [per-KR estimate + current blocker]
Quarter score: [0.0-1.0 per KR]
```

### Failure Modes
- Sandbagged KRs: writing what would happen anyway defeats the 70% stretch rule → score honestly; four straight quarters above 0.9 means these are commitments, not Objectives
- Task-list KRs ("launch the export feature") with no measurable outcome → force the "from X to Y" form; output masquerading as outcome
- Pay-linked KRs: gaming and sandbagging within one cycle → separation from compensation is design, not plea
- Objective inflation: 6+ Objectives per team → nothing is a priority; cap 3-5 per org, fewer per team
- Set-and-forget: no weekly check-in cadence → dead by week 3; the review ritual is the system

### Strategy-to-Metrics Recipe (cross-reference)

Choosing WHAT to measure before writing KRs: **Balanced Scorecard** (Kaplan & Norton) translates strategy into financial / customer / internal-process / learning-growth perspectives — use it when strategy-execution measurement is the open question; OKR then drives movement on the chosen metrics. This entry holds the pointer, not a duplicate card.

**Admission verdict** (v0.1.13, corrected v0.1.15): Balanced Scorecard reviewed → Recipe, because OKR + North Star already own goal and metric mechanics; a full BSC card would duplicate measurement scaffolding without adding a distinct question. **Corrected**: the Recipe verdict assumed OKR/North Star covered the strategy→measures translation — they do not, so the pointer was a dead route. BSC is now its own entry (`../strategy/balanced-scorecard.md`); this pointer stays.

### Evidence Strength
**Practitioner consensus on adoption, mixed on causal lift.** The Grove/Doerr lineage and decades of industry use are well documented; evidence that OKR itself raises performance is confounded by selection effects and by the measurement/focus practices it bundles — treat the cadence and the stretch rule as the active ingredients.

### Source
Andy Grove, *High Output Management* (1983); John Doerr, *Measure What Matters* (2018). Balanced-Scorecard Recipe pointer added v0.1.13.

## Pre-mortem & Counterfactual
> source: premortem-counterfactual.md
### Core Concept
Before committing to a decision, imagine it has failed spectacularly. Work backward to identify what went wrong. Then develop counterfactuals: "if X had been different, would the outcome change?" This surfaces hidden risks and critical variables.

### Applicable Scenarios
✅ **Best for**
- Major decisions before commitment
- Project kickoff risk identification
- Investment evaluation

⚠️ **When NOT to use**
- Reversible, cheap-to-undo decisions — rehearsing failure costs more than iterating; grade with **Reversibility Grading** first
- The team has already publicly committed and morale is invested — the premortem's license to criticize works before commitment, not after
- Novel one-shot bets with no precedent and no hard constraints — imagined failures are free-floating anxiety; inversion needs constraints, counterfactuals need a causal skeleton
- Live incidents and time-critical response — you need **OODA Loop** tempo, not a structured imagination exercise

### Key Steps
1. Assume the plan has failed catastrophically (set the scene)
2. Each team member writes down reasons for failure independently
3. Share and cluster failure reasons
4. For each failure reason, assess: probability + impact + preventability
5. Develop mitigation plans for top risks
6. Create counterfactuals: "If we had [done differently], would [failure] still occur?"
7. Adjust the plan based on findings

### Output Template

```
Premortem — "It is [future date]. The plan has failed catastrophically."
Failure reasons (written independently before any discussion, then clustered):
  1. [reason, specific enough to be falsifiable] — probability [H/M/L] × impact [H/M/L] × preventability [H/M/L]
  2. [reason] — ...
Top risk cluster: [the cluster scoring high on all three]
Mitigations: [risk → concrete prevention / early-warning tripwire / owner]
Counterfactuals: "If we had [done X differently], would [failure] still occur?" → [yes — structural / no — controllable]
Plan changes adopted: [what changes because of this exercise]
```

### Failure Modes
- Premortem as ritual: everyone lists clichés ("scope creep", "poor communication") and nothing changes → require failure reasons specific enough to be falsifiable, and close with plan changes, not just a risk list
- Unranked dumping: 40 reasons, no prioritization → score each on probability × impact × preventability and work only the top cluster
- Hindsight creep in counterfactuals: "we should have known" smuggles hindsight bias into a forward-looking exercise → keep counterfactuals conditional on information available at decision time
- Facilitator speaks first: the leader's stated failure reasons anchor the room → independent written reasons before any discussion; that is the Klein protocol's core mechanic

### Inversion (folded entry)

The failure-rehearsal mechanism run in reverse: pre-mortem imagines the failure and works backward to its causes; inversion starts from the present and asks **"what would guarantee failure?"** — then avoids that list.

- Use when the plan has no precedent to premortem against (genuinely novel): imagined failure modes are speculative, but the guarantee-failure list is derivable from hard constraints (no users, no distribution, no cash, no retention)
- Use as the opening move of a Pre-mortem: the inversion list seeds step 2's independent failure reasons
- When NOT to invert alone: regulatory/safety domains where failure modes are already catalogued by others — start from the catalogue, not from imagination

**Admission verdict** (v0.1.6): standalone Inversion entries reviewed in external mental-model collections — folded here rather than built as a separate entry, because both are failure-rehearsal mechanisms and SKILL.md's combination rules bar near-synonym stacking. Escalate to a Build verdict only if a task appears that needs inversion without any premortem framing.

### Evidence Strength
Mixed — prospective hindsight has real experimental support: imagining an event as already having occurred reliably increases the number and specificity of risks people generate, and Klein's premortem is built on that mechanism; but the strongest results are lab-rooted single-session effects, and field evidence that premortems change real project outcomes is thinner. The counterfactual half inherits hindsight-bias research — useful for surfacing critical variables, prone to "we should have known" readings.

### Source
Gary Klein, *Performing a Project Premortem* (2007); Harvard Business Review.
Inversion absorbed with Fold verdict, 2026-10-01 — sources: cyperx84/claude-skills-mental-models (inversion.md), mattnowdev/thinking-partner (MIT).

## Decision Matrix
> source: decision-matrix.md
### Core Concept
Multi-option, multi-criteria weighted scoring that quantifies choices. Each option is scored against each criterion, weights reflect relative importance, and the highest total score wins.

### Applicable Scenarios
✅ **Best for**
- Technology selection with custom criteria
- Strategy comparison
- Candidate evaluation

⚠️ **When NOT to use**
- Options have probabilistic, quantifiable payoffs — weighted preference scoring ignores expectation; use **Decision Tree & Expected Value**
- One uncertain quantity to estimate, no multi-option comparison — scoring answers the wrong question; use **Probabilistic Reasoning**
- The cause-effect structure of the situation is still unclear — criteria chosen before understanding encode the confusion; classify with **Cynefin** first
- Criteria and weights are genuinely contested among stakeholders — the matrix launders politics into arithmetic; negotiate the criteria openly first or the total is theater

### Key Steps
1. Define the decision to be made
2. List all options (at least 3 alternatives)
3. Define evaluation criteria (5-7 recommended)
4. Assign weights to each criterion (must sum to 1.0 or 100%)
5. Score each option per criterion (1-5 or 1-10 scale)
6. Calculate weighted score = score × weight for each cell
7. Sum weighted scores per option; highest total wins
8. Conduct sensitivity analysis: vary weights to test robustness

### Output Template
```
Decision Matrix:
| Criterion (weight) | Option A | Option B | Option C |
|--------------------|----------|----------|----------|
| Cost (0.3)         | 4 (1.2)  | 3 (0.9)  | 5 (1.5)  |
| Performance (0.4)  | 3 (1.2)  | 5 (2.0)  | 4 (1.6)  |
| Risk (0.3)         | 4 (1.2)  | 2 (0.6)  | 3 (0.9)  |
| **Total**          | **3.6**  | **3.5**  | **4.0**  |

Winner: Option C (4.0)
Sensitivity: [robust / sensitive to criterion X]
```

### Failure Modes
- Weights chosen to crown the preferred option: the winner was implicitly picked before scoring started → elicit and freeze weights before any option is scored, then sensitivity-check whether the ranking survives weight swings
- Double-counted criteria: "cost" scored directly and again inside "risk" → each factor belongs in exactly one criterion; merge or drop duplicates before weighting
- Unanchored scales: 1-5 scores on undefined levels read as measurements → publish anchors per score level before scoring
- Straw-man option set: only weak variants of one alternative listed → include the honest rival and a do-nothing baseline
- Arithmetic laundering: the total implies an objectivity the inputs never had → report the result as weighted judgment and flag near-ties as effectively tied

### Evidence Strength
Mixed — the arithmetic is exact but every input is judgment: weighted scoring has a long operational record (Pugh, AHP, SMART lineage), yet outputs are highly sensitive to weight elicitation, scale anchoring, and criterion framing, and no evidence shows the top total outperforms a well-argued ranking. The matrix's real product is the explicit criteria-and-weights conversation; treat the winner as a structured opinion and lean on the sensitivity step for the verdict.

### Source
Standard decision analysis methodology; Pugh matrix variant.

## MoSCoW Method
> source: moscow.md
### Core Concept
Requirement scoping using 4 categories: Must have (non-negotiable), Should have (important but not vital), Could have (nice to have), Won't have (explicitly out of scope this time). Creates clear boundaries for delivery.

### Applicable Scenarios
✅ **Best for**
- Scope management
- Requirement classification
- Sprint planning

⚠️ **When NOT to use**
- Solo decision-maker, small scope — four buckets add ceremony a simple ordered list doesn't; the method's value is stakeholder negotiation, not classification
- No shared delivery deadline — Must/Should only bites against a fixed release; without one, everything drifts into "eventually"
- The real question is sizing or value-per-effort — MoSCoW orders requirements but never measures them; use **RICE Scoring** when ranking needs numbers
- Backlog as long-lived wishlist archive — buckets decay as Musts ship and Shoulds fossilize; re-classify per release, not once forever

### Key Steps
1. List all requirements/features
2. Classify each into M/S/C/W with stakeholder agreement
3. Must have: if removed, the deliverable is useless
4. Should have: important but the deliverable still works without it
5. Could have: desirable but not necessary
6. Won't have: explicitly excluded from this delivery (may be future)
7. Validate: Must haves should be ≤ 60% of total effort

### Output Template

```
Delivery: [release / sprint + date]
Must have (≤60% of effort):
  - [requirement] — the deliverable is useless without it
Should have:
  - [requirement] — deliverable works without it, degraded
Could have:
  - [requirement] — nice to have, first to drop under pressure
Won't have (this round):
  - [requirement] — explicitly out; revisit on [trigger]
Check: Must effort [n% of total] — [under cap / rebalance needed]
Stakeholders agreeing: [names]
```

### Failure Modes
- Everything lands in Should: nobody will kill a requirement, so the buckets fill with S → force a Won't list every round; an empty W means the classification didn't happen
- Must inflation: every stakeholder's pet feature is declared critical → apply the test in writing ("if removed, the deliverable is useless") and enforce the ≤60% effort cap
- Could as consolation prize: disagreements get parked in C instead of resolved → a C item must be droppable with no follow-up promise; otherwise it is an S or a W
- Buckets without negotiation: one person silently bucket-lists the backlog → MoSCoW is a stakeholder agreement ritual; classifying without the disagreement on the table produces fiction

### Evidence Strength
Practitioner consensus — standard scope vocabulary since DSDM, kept alive by the one thing it forces: an explicit Won't list and a visible scope cut. Evidence on delivery outcomes is anecdotal, and its known failure (bucket inflation without a facilitator) is documented in agile practice rather than controlled studies.

### Source
Dai Clegg, *MoSCoW Method* (1994); used in DSDM agile methodology.

## FMEA
> source: fmea.md (original title: FMEA — Failure Mode and Effects Analysis)
### Core Concept
Systematic identification and ranking of potential failure modes using Severity × Occurrence × Detection = Risk Priority Number (RPN). Higher RPN = higher priority for mitigation.

### Applicable Scenarios
✅ **Best for**
- Product/process risk identification
- Quality engineering
- Safety-critical systems

⚠️ **When NOT to use**
- The question is top-down deductive ("what could cause THIS top event?") → Fault-Tree Recipe below; FMEA is bottom-up inductive per component
- Conceptual design with no component decomposition yet → Pre-mortem is faster and catches design-level blind spots
- Failure modes dominated by human/organizational factors, where S×O×D becomes false numerics → qualitative scan (Risk Matrix)
- Fast-moving software failure surfaces: a static RPN ages in weeks → incident-response data (observability) supersedes the worksheet

### Key Steps
1. Decompose the system/process into components/steps
2. For each component, identify potential failure modes
3. For each failure mode, score: Severity (1-10), Occurrence (1-10), Detection (1-10)
4. Calculate RPN = S × O × D
5. Sort by RPN descending
6. Develop mitigation actions for top RPNs
7. Re-score after mitigation to verify risk reduction

### Output Template
```
FMEA Results:
| Component | Failure Mode | S | O | D | RPN | Action |
|-----------|-------------|---|---|---|-----|--------|
| Auth      | Token leak   | 9 | 4 | 6 | 216 | Encrypt + rotate |
| API       | Timeout      | 6 | 5 | 3 | 90  | Circuit breaker |

Risk Classification:
  Critical (RPN ≥ 200): [...]
  High (100-199): [...]
  Medium (50-99): [...]
  Low (< 50): [...]
```

### Failure Modes
- RPN theater: multiplying three invented numbers and sorting the product → treat RPN as an ordering heuristic; severity ≥ 9 goes to the top regardless of the product
- Decomposing by code structure instead of function → failure modes live in functions; a component map without functions misses them
- Detection scored on hope ("tests will catch it") → score by current evidence of what detection actually catches
- One-and-done worksheet: no re-score after mitigation → the loop closes nothing; schedule the re-score with the action

### Fault-Tree Recipe (cross-reference)

Top-down deductive twin: start from a named top event and enumerate the AND/OR combinations that reach it — **Fault Tree Analysis** (IEC 61025). Use FTA when one specific failure demands causal decomposition; use FMEA to sweep components for what could fail. This entry holds the pointer, not a duplicate method.

**Admission verdict** (v0.1.13, corrected v0.1.15): Fault Tree Analysis reviewed → Recipe, because it complements rather than duplicates FMEA's question, and a separate card would split one bottom-up/top-down pairing across two files. **Corrected**: the Recipe verdict assumed another entry held FTA — none did, so this pointer was a dead route. FTA is now its own entry (`fault-tree-analysis.md`); the pointer stays, and the bottom-up/top-down pairing is documented in one place.

### Evidence Strength
**Practitioner consensus in its industries, heuristic arithmetic.** FMEA is standard in automotive (AIAG-VDA), aerospace, and medical devices with decades of institutional use; the RPN product itself is criticized (ordinal scales multiplied as if cardinal) — use rankings, not the absolute number.

### Source
Military standard MIL-P-1629 (1949); adopted by automotive (AIAG) and aerospace industries. Fault-Tree Recipe pointer added v0.1.13.

## Death Filter
> source: death-filter.md
### Core Concept
An existential decision filter: "If this were the last decision I ever make, would I still choose this?" Forces confrontation with mortality to clarify true values and priorities. Not for daily decisions — reserved for major, irreversible life/career/startup decisions.

### Applicable Scenarios
✅ **Best for**
- Major life decisions
- Career direction choices
- Startup direction decisions

⚠️ **When NOT to use**
- The decision is a quantifiable trade-off wearing values clothing — the filter ranks by existential resonance and will bless an option that is numerically ruinous; run **Decision Tree & Expected Value** first, then apply the filter to the surviving candidates
- Group decisions — "whose deathbed?" has no answer, and one person's terminal values get laundered as the team's; use **Decision Matrix** with elicited weights instead
- The option set is not yet real (no concrete alternatives to weigh) — the filter ranks options, it does not generate them; diverge first
- Assumed irreversibility — many "one-way doors" are two-way at a known cost; grade with **Reversibility Grading** before spending existential weight

⚠️ **Not for**
- Daily operational decisions
- Urgent/time-critical decisions
- Reversible decisions

### Key Steps
1. Confirm this is a major, irreversible decision (not daily/urgent)
2. List all candidate options
3. Apply the Death Filter to each: "On my deathbed, would I regret NOT choosing this?"
4. Rank options by existential resonance
5. Validate: does the top option align with your core values?
6. Commit to the decision

### Output Template

```
Decision: [the one major, irreversible choice on the table]
Options: [A / B / C — concrete, not straw alternatives]
Death Filter per option: "On my deathbed, would I regret NOT choosing this?"
  [A]: [yes/no + the value it serves or violates, one line]
  [B]: [yes/no + why]
Ranking by existential resonance: [A > B > C]
Values check: top option aligns with [named core values] — [holds / conflict noted]
Commitment: [decision + what you stop doing to make it real]
```

### Failure Modes
- Regret answered by present fear: "would I regret not choosing this?" returns current anxiety (fear of missing out, fear of failure), not terminal values → restate as "at 90, looking back, which choice do I want to have made?" and write each option's answer before comparing
- Existential gravity on small decisions: everything gets deathbed framing until the filter stops filtering → reserve it for options that fail **Reversibility Grading**'s one-way-door test; everything else gets decided normally
- Post-hoc blessing: the option was already chosen and the ritual just sanctifies it → run the filter per option independently and in writing before ranking; let an option die if it fails
- Values never named: "existential resonance" stays vague, so the ranking is vibes → name the 2-3 core values the filter serves before applying it

### Evidence Strength
Contested — popular as a reflection prompt (Jobs' deathbed speech, existential decision-making traditions) with no research validating deathbed simulation as a decision aid; affective-forecasting research shows people systematically mispredict what they will regret, which undercuts the premise that imagined deathbed regret tracks real values. Treat it as values clarification for genuinely irreversible choices, not as a validated instrument.

### Source
Existential decision-making framework; inspired by Steve Jobs' "deathbed" reflection.

## Risk Matrix
> source: risk-matrix.md
### Core Concept
Quick 2-dimensional risk assessment using Probability × Impact. Plot identified risks on a grid to visually classify and prioritize them into zones: Critical, High, Medium, Low.

### Applicable Scenarios
✅ **Best for**
- Project kickoff risk screening
- Strategic planning risk scan
- Technology selection risk comparison

⚠️ **When NOT to use**
- Risks need quantitative treatment (expected loss in dollars) — a 3×3 grid cannot sum exposures; use FMEA for ranked failure modes or Monte Carlo Simulation for quantified exposure
- Probability estimates have no basis (novel one-shot projects) — the plot implies precision nobody has
- Safety-critical domains with mandated methods — use the prescribed standard; the matrix is a screening tool, not a compliance artifact

### Key Steps
1. List all identified risks
2. For each risk, assess Probability (1-5 scale) and Impact (1-5 scale)
3. Plot on the Probability × Impact matrix
4. Classify into zones: Critical (high P + high I), High, Medium, Low
5. Develop response strategies: Critical = avoid/transfer; High = mitigate; Medium = monitor; Low = accept

### Output Template

```
Risk register (scoring anchors declared up front: what a 2 vs 4 impact means in $/time/scope)

| # | Risk                          | P | I | Zone     | Response            | Owner | Trigger/review   |
| --- | --------------------------- | - | - | -------- | ------------------- | ----- | ---------------- |
| 1  | [key vendor folds]           | 2 | 5 | High     | [dual-source now]   | [x]   | [monthly]        |
| 2  | [migration data loss]        | 3 | 5 | Critical | [avoid: dry runs + backup restore test] | [x] | [before cutover] |
| 3  | [minor UI regression]        | 4 | 1 | Low      | [accept]            | —     | —                |

Zone summary: [n critical / n high] — criticals must carry avoid/transfer plans, not just mitigation intent
Residual risk after responses: [re-plot post-mitigation? at least for criticals]
```

### Failure Modes
- Unanchored scales: everyone's "3" means something different, zones become noise → publish concrete anchors ("impact 4 = >$100k or >2wk slip") before scoring
- Probability by vibes for novel risks: anchoring on imagination, not base rates → demand a reference class ("similar migrations failed X% of the time") or mark the estimate low-confidence
- Mitigation theater: critical risks get "monitor" — the response contradicts the zone → each zone maps to an allowed response set; criticals must show avoid/transfer/mitigate with owner and trigger

### Evidence Strength
Practitioner consensus — the standard PMBOK-era screening device; useful for shared visualization, but research on risk matrices documents systematic weaknesses (category compression, poor discrimination between risks, false precision) — treat zone boundaries as conventions and keep quantitative analysis for stakes that justify it.

### Source
Standard project risk management; PMI PMBOK methodology.

## Reversibility Grading
> source: reversibility.md
### Core Concept
Size the process to the cost of un-deciding. Most commitments prove easier to unwind than they feel — ceremony on a days-reversible call steals time from the few that truly lock in. Grade undo cost first; deliberate only as deeply as the grade demands.

### Applicable Scenarios
✅ **Best for**
- No shared answer for how much analysis a choice deserves (tech, product, process, org)
- Low-blast-radius calls drifting toward committee review; high-lock-in ones toward snap decisions
- Wrong moves and waiting recover very differently
- Room to reshape the move (pilot, flag, abstraction, time-box) into something cheaper to undo

⚠️ **When NOT to use**
- Choices so small grading outlasts deciding — just make the call (names, local cleanups)
- Optionality never yours (mandate, signed obligation, date fixed elsewhere) — nothing left to grade
- Gates valued for being right, not fast (security review, data integrity)
- Already graded this session — execute at that depth; re-grade only on new undo-cost evidence

### Key Steps
1. **Name the decision and its reverse route**: what gets committed, concretely how to walk it back — re-deploy the previous build, restore the prior schema. No nameable reverse route → treat as more binding until one is demonstrated
2. **Grade the undo cost**: reversal effort, clock time, cash, reputation, who depends on the status quo, learning discarded:
   - **Type 2** — walk back within days, cheap → decide now
   - **Type 1.5** — weeks away, moderate cost → light structure with active monitoring
   - **Type 1** — months or effectively final → deliberate, then stage commitment
3. **Weigh the downside asymmetrically** (Type 1/1.5): wrong move — how bad, recoverable at what price? No move — what closes for good (window, exclusivity, forked-away path)? Recoverable damage + closing window → staged commitment, not indefinite delay; unrecoverable or third-party harm → refuse or reshape first
4. **Reversibilize before deliberating**: pilots, feature flags, interface abstractions, versioned rollouts, time-boxed vendor terms — each turns a would-be Type 1 commitment into a cheap Type 2 probe; deliberate only the irreducible core
5. **Commit at the graded depth**: Type 2 — pick a sound option, ship, watch it. Type 1 — record load-bearing assumptions, argue the strongest opposing case, escalate if stakes demand. Grade and depth set → stop; reopen only on new undo-cost evidence

### Output Template

```
Decision: …
Reverse route: …
Grade: Type 2 | Type 1.5 | Type 1 (weighed on: …)
Wrong-move damage / recovery: …
What waiting closes for good: …
Reversibilizing move: pilot | flag | abstraction | time-box | none
Depth of process: decide now | pilot first | deliberate fully
Commitment: …
```

### Failure Modes
- "We can always change later" with no named reverse route or cost → reversibility asserted, not demonstrated; raise the grade until produced
- Two-way-door vocabulary used to skip verification on data, security, or public commitments — verification effort tracks blast radius, not the metaphor
- Deliberation machinery on routine Type 2 work — the grading exists to buy speed where it is safe, not a ritual on every choice

### Boundaries with Adjacent Methodologies
- `death-filter.md` answers **whether** — a values-level existential filter for major life/career/startup calls; Reversibility Grading answers **how deep a process the decision deserves**. On big calls they compose: filter first, then grade
- `premortem-counterfactual.md` rehearses the risks of a chosen plan before commitment; Reversibility Grading decides how much rehearsal the plan deserves in the first place

### Evidence Strength
Practitioner consensus — the two-way/one-way door distinction is widely credited for speeding reversible calls and slowing irreversible ones; the intermediate grade and staging moves are practitioner refinements, undo-cost estimates remain prone to optimism bias, and no formal research validates the specific thresholds.

### Source
Practitioner decision-speed heuristics; the Type 1 / Type 2 door framing was popularized by Jeff Bezos's shareholder letters, extended here with an intermediate grade and option-preserving redesign moves.
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) `thinking-reversibility` (MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns execution-level process grading by undo cost; Death Filter covers the values-level should-we-do-it question at a different layer.

## OODA Loop
> source: ooda-loop.md
### Core Concept
When the situation is still moving and you must act before certainty, cycle Observe → Orient → Decide → Act faster than the situation compounds: for reversible moves, act at ~70% confidence, then immediately re-observe. A late perfect plan loses to a fast loop — but the bottleneck is usually **Orient** (synthesis), not raw speed; a team that orients badly just produces wrong decisions faster.

### Applicable Scenarios
✅ **Best for**
- Incident response, outage, or ongoing degradation where state is still moving
- Debugging a moving target (intermittent failure, live traffic shift)
- Any time-bounded decision where waiting for full certainty costs more than a reversible action
- Competitive or adversarial settings where the faster cycle time is itself the advantage

⚠️ **When NOT to use**
- The situation is static and you have time — deliberate analysis or a hypothesis differential wins
- The next action is irreversible or high blast-radius — raise the evidence bar; 70% is not enough
- A cheap localization check (failing diff, log line, one metric) would end the uncertainty — test that hypothesis directly instead of looping
- No time pressure and no changing environment — the loop adds churn without value

### Key Steps
1. **Observe (time-boxed)**: gather the cheapest high-signal state now — metrics, logs, alerts, recent deploys/config, and feedback from the last action. Cap the window; never collect forever
2. **Orient**: match observations to a pattern and form **≥2 competing explanations**. Update or discard the mental model when data contradicts it — refuse single-hypothesis lock
3. **Decide**: pick one reversible action that tests the leading hypothesis. State the confidence (~70% threshold for reversible moves), the predicted effect, the next observation to check, and a time box for that check
4. **Act**: execute once, decisively, with a known rollback or degrade path
5. **Re-observe immediately**: compare outcome to prediction within the time box; feed the result into the next Observe. If Act is never followed by re-observe, the loop is broken — fix that before another action
6. **Exit explicitly** when any of: the system is stable; the remaining work is static analysis; the next step requires irreversible commitment — then switch to the matching methodology

### Output Template

```
Cycle record (repeat per loop):
1. Observed — current signals, what changed since last cycle
2. Orientation — ≥2 hypotheses; which leads and why
3. Decision — action, confidence, predicted effect, next observation, time box
4. Act + result — what ran; what the immediate re-observe showed
5. Loop status — continue | stable | exit to another method
```

### Failure Modes
- Looping without a nameable reversible next action plus a refuting observation → stop and gather evidence or escalate instead
- Single-hypothesis Orient → confirmation spiral; force the second candidate explanation before every Decide
- Applying OODA to static design work or irreversible launches → wrong tool; use deliberation and raise the evidence bar instead
- Waiting for 100% confidence on reversible mitigations under active pressure → the 70% threshold exists for exactly this case

### Timing Trio
- **Before**: `premortem-counterfactual.md` — rehearse how the planned approach could fail
- **During**: OODA Loop — cycle reversible moves while the situation is still moving
- **After**: `engineering/incident-response-postmortem.md` — extract learning once stable

### Evidence Strength
Mixed — the loop is an enduring staple of military doctrine and operations practice, and cycle-time advantage is well-attested; the ~70% confidence threshold and "Orient is the bottleneck" diagnosis are practitioner heuristics, and the Korean War origin narrative is anecdotal rather than rigorously validated.

### Source
John Boyd's Observe–Orient–Decide–Act loop, derived from Korean War air-combat analysis (the faster-cycling pilot reacts to current information while the slower one reacts to obsolete information); the ~70% confidence threshold is a practitioner heuristic for reversible moves under pressure.
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) `thinking-ooda` and [knowledge-skills](https://github.com/deciqAI/knowledge-skills) `ooda-loop` (both MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns live-incident decision cycling (act before certainty); Incident Response & Postmortem requires the event to be over.

## Probabilistic Reasoning
> source: probabilistic-reasoning.md
### Core Concept
State beliefs as numbers and ranges, not vibes. Anchor on a reference-class base rate, update with an explicit likelihood ratio, and bound unmeasured quantities by order of magnitude — never invent false precision. Within this category, this card owns the **estimate-and-update** step: `risk-matrix.md` grades identified risks qualitatively, `decision-matrix.md` weighs options against criteria.

### Applicable Scenarios
✅ **Best for**
- Timeline, effort, or outcome forecasts where the true value is uncertain
- Risk sizing for a change, migration, launch, or bet
- Any moment you are about to state a confident single number you cannot actually know
- New evidence has arrived and a prior estimate should move

⚠️ **When NOT to use**
- The quantity is measurable or look-up-able — measure or look it up
- The decision is invariant across the whole plausible range — skip the estimate and act
- No real reference class exists — label the number a guess, not a calibrated forecast
- A binary gate plus one decisive observation already settles it — do not pad with ceremony

### Key Steps
1. **Define a checkable claim**: outcome + timeframe + unit. "Auth p95 latency under 300 ms within 2 weeks", not "performance will likely improve"
2. **Convert vague words to numbers**: declare a fixed mapping before estimating (e.g. "likely" ≈ 65–80%) so the same word means the same probability across the analysis
3. **Anchor the prior on a reference class**: what base rate do comparable cases show? Pull the prior toward it unless you can write a concrete reason for deviating. Then state the strongest evidence-based case that your prior is wrong, and revise if that countercase survives
4. **Express a range, not a point**: give at least one confidence interval (50% and 80% preferred); assume overconfidence and widen intervals when the outside view is thin
5. **Update with a likelihood ratio** when evidence arrives: LR = P(E|H) / P(E|¬H); LR > 1 supports H, LR ≈ 1 is noise, LR < 1 undermines H. Posterior odds = prior odds × LR — multiply even when LR < 1. Yesterday's posterior is today's prior for the next piece of evidence. For rare events, start from the base rate: one vivid positive still leaves most of the mass on false alarms
6. **Bound unmeasured quantities by magnitude**: decompose into factors, bound each factor with a range, multiply, and report "~X within 3–5×" — never report precision the inputs cannot support
7. **Stop** when the decision is stable across the remaining range, or the next update would need evidence you do not have

### Output Template

```
Claim: [checkable statement + timeframe + unit]
Prior: [reference-class base rate + deviation reason] → p = …
Range: 50% CI [a, b]; 80% CI [c, d]
Updates: [evidence → LR → new p] (one row per piece of evidence)
Bounds: [unmeasured factors → "~X within N×"]
Decision implication: what changes at the low vs high end of the range
```

### Two High-Frequency Traps
- **Base-rate neglect**: treating a rare event as probable because the evidence "looks like" it. Example: 0.1% prevalence with a 99:1 likelihood ratio still yields only a ~9% posterior after a positive test — anchor the prior before reading the evidence
- **Prosecutor's fallacy**: reading P(E|H) ("the evidence matches the hypothesis") as P(H|E) ("the hypothesis is true given the evidence"). Fix: you need both P(E|H) and P(E|¬H); without the false-positive rate you have half the story

### Failure Modes
- Three significant figures on a 5×-uncertain product → report magnitudes honestly instead
- An invented reference class → the output is a guess; label it as one
- The number does not move when new evidence arrives (or moves without an LR) → recompute rather than defend

### Boundaries with Adjacent Methodologies
- `risk-matrix.md` — qualitative Probability × Impact grading of an identified risk list; no calibrated updating
- `decision-matrix.md` — weighted scoring among options once criteria are fixed
- **Probabilistic Reasoning** — produces and revises the probability estimates those tools consume
- Pairs with `data-analysis/debias-checklist.md` (base-rate neglect and confirmation bias entries)

### Script Integration Note
The quantitative core (odds conversion, LR multiplication, posterior computation) is deliberately left as card guidance here; a `scripts/` helper for prior-odds → LR → posterior arithmetic is a natural future extension.

### Evidence Strength
Strong for the arithmetic — Bayes' theorem is formal mathematics and the base-rate/prosecutor's-fallacy errors are experimentally documented; the calibration layer (word→number mappings, interval widening heuristics) rests on forecasting research and convention, and interval quality degrades for novel one-off events.

### Source
Bayes' theorem (posterior odds = prior odds × likelihood ratio) combined with forecasting-calibration practice (reference-class forecasting, stated confidence intervals, word-to-number mappings).
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) `thinking-probabilistic` and [knowledge-skills](https://github.com/deciqAI/knowledge-skills) `bayesian-reasoning` (both MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns the estimate-and-update step (numeric belief revision); risk-matrix grades identified risks only qualitatively.

## Principled Negotiation
> source: principled-negotiation.md (original title: Principled Negotiation (Harvard Method))
### Core Concept
Negotiate over interests, not positions, and derive your walk-away power from alternatives, not aggression. Four principles: separate the people from the problem; bargain over interests behind stated positions; invent options for mutual gain before dividing; insist on objective criteria. BATNA — your Best Alternative To a Negotiated Agreement — is the load-bearing element: value your best fallback before the table, set the reservation point from it, and estimate the counterpart's BATNA to know where the zone of agreement actually sits.

### Applicable Scenarios
✅ **Best for**
- Salary, vendor, partnership, licensing negotiations
- Resource disputes and multi-round agreements where the relationship survives the deal
- Deadlocked positional bargaining that needs reframing

⚠️ **When NOT to use**
- No acceptable alternative exists — build the BATNA first (alternatives, option value via Reversibility Grading + Decision Matrix); negotiating without one is theater. Escalation: mapping who influences the outcome without a live counterpart → Stakeholder Mapping (Strategic Analysis)
- Pure one-shot price haggling against a professional positional counterpart — leverage math and anchoring dominate; principles add little
- Values or identity conflicts disguised as interest disputes — no clever package dissolves them; escalate or restructure the relationship instead
- The counterpart dictates terms unilaterally — that is decision-making under constraint, not negotiation

### Key Steps
1. Prepare interests: list yours and the counterpart's likely interests behind their stated position ("why" behind each demand)
2. Build BATNA: enumerate alternatives, value the best one concretely, set the reservation point (walk-away) from it; estimate their BATNA the same way
3. Run two tracks: relationship (soft) on one, substance (hard) on the other — never trade one for the other
4. Negotiate interests: restate the position, ask the why, propose against the underlying interest
5. Invent options before committing: expand the pie (scheduling, scope, risk-sharing, sequencing) before splitting it
6. Insist on objective criteria: market benchmarks, industry standards, third-party appraisals as the fairness basis
7. Close or walk: written agreement against the criteria, or exercise the BATNA — a prepared walk-away is the strongest move in the room

### Conflict Mode Selection

Before bargaining, choose the stance on two axes — how hard to press for substance, how much the relationship must survive:

- **Collaborate** — both matter: full principled negotiation (the default this entry assumes)
- **Compete** — substance matters, relationship doesn't (one-shot price talk): anchor hard, hold the BATNA; the four principles buy little here
- **Accommodate** — relationship outweighs the issue: concede deliberately, price the goodwill, log the trade so it is banked rather than lost
- **Compromise** — equal power, time-boxed: split the difference only after options for mutual gain are exhausted; it is the lazy default that silently leaves value on the table
- **Avoid** — neither matters now: defer explicitly with a revisit date; silent avoidance reads as consent and festers

### Output Template

```
Parties: [us / them / affected third parties]
Interests — ours: [listed]; theirs: [stated + inferred, tagged fact/inference]
BATNA — ours: [best alternative + valued reservation point]; theirs: [estimate + confidence]
Zone of agreement: [overlap of reservation points, or none]
Options for mutual gain: [packages varying scope/timing/risk-sharing]
Objective criteria: [benchmarks both sides would accept]
Concession plan: [what we give cheaply, what we hold, in what order]
Walk-away trigger: [the condition that ends talks]
```

### Failure Modes
- Positions-first bargaining: countering their number hardens identities → force the "why" question before any counteroffer
- Reservation point anchored on aspiration instead of BATNA: the walk-away must come from alternatives valued outside the room, or you either overhold or capitulate
- BATNA hallucination: an alternative that "sounds available" but would not survive scrutiny → pressure-test it before relying on it
- Winning the deal, losing the relationship (or relationship-smoothing that gives away substance): the two tracks must stay separate by design
- Revealing the reservation point through eagerness: sequence concessions deliberately, never bid against yourself

### Evidence Strength
Practitioner consensus with a strong research core — BATNA/reservation-point effects are among the most replicated findings in negotiation research; the "invent options for mutual gain" prescriptions transfer less reliably to adversarial one-shot settings and remain debated there.

### Source
Roger Fisher & William Ury, *Getting to Yes* (1981, where BATNA was coined); Howard Raiffa, *The Art and Science of Negotiation* (1982, reservation-price formalization). Admission verdict: **Build** (v0.1.11) — negotiation had no dedicated entry in the corpus; BATNA is folded into this entry as its preparation step rather than a separate stub (same mechanism, one file). Thomas–Kilmann conflict modes **Fold into** this entry (v0.1.13, Conflict Mode Selection section) — stance selection is the preamble to principled bargaining; a separate card would force a file hop to decide how to enter the negotiation.

## Decision Tree & Expected Value
> source: decision-tree.md
### Core Concept
Structure a one-shot choice under uncertainty as a tree: decision nodes (your options) branch into chance nodes (outcomes with probabilities) ending in payoffs; roll expected values back from the leaves and pick the maximum-EV branch. EV is the starting point, not the verdict — a decision survives only after a risk check (variance, ruin, reversibility) and a sensitivity read (which input actually swings the choice).

### Applicable Scenarios
✅ **Best for**
- Discrete options with probabilistic, quantifiable outcomes: build vs buy, settle vs litigate, pivot vs persevere
- Making explicit the probabilities a plan was silently assuming
- Pricing an information purchase (what is another month of research worth?)

⚠️ **When NOT to use**
- Estimating one uncertain quantity (no choice among gambles) → Probabilistic Reasoning — different question: a number vs a branch
- Scoring options on criteria without probability structure → Decision Matrix — different question: preference vs expectation
- Outcomes that cannot be assigned even rough monetary/utility values → Decision Matrix or qualitative frameworks
- Probabilities pure invention with no base rate → garbage EV; get a reference class first
- A strictly dominant option exists → skip the tree, state the dominance

### Key Steps
1. Frame the decision, time horizon, and alternatives — include "do nothing" as a branch
2. Identify the key uncertainties per branch (prune to decision-relevant ones)
3. Assign probabilities: base rates first, adjust by evidence (likelihood-ratio discipline)
4. Assign payoffs: full consequence per leaf (costs, second-order effects), not revenue alone
5. Roll back: EV at chance nodes, max-EV choice at decision nodes
6. Sensitivity: one-at-a-time swings — which probability or payoff flips the choice, and how far
7. Risk check: ruin/downside survival, variance tolerance, reversibility grading of the leading branch
8. Decide; record assumptions and the sensitivity verdict with the output

### Output Template

```
Decision: [question + horizon]
Branches: [option → chance node → outcomes (probability, payoff)]
EV per branch: [rolled-back values]
Sensitivity: [the input that flips the choice + flip threshold]
Risk check: [worst case per branch | survivable? | reversible?]
Verdict: [max-EV choice, risk-adjusted if needed, confidence + assumptions recorded]
```

### Failure Modes
- Invented probabilities laundered as math: the tree looks rigorous, the priors are vibes → base-rate anchoring mandatory; state confidence per probability
- Payoffs missing second-order effects: competitor response, precedent, morale → feed branches from Second-Order Thinking
- EV worship under ruin risk: maximizing expected value while risking non-survival is wrong for the decision-maker — risk-adjust or constrain the downside first
- Tree explosion: every contingency mapped → prune to branches that could change the choice
- Sunk-cost branches: only future payoffs belong in the tree; what was spent is spent

### Evidence Strength
Strong normative core — decision analysis is axiomatically grounded (Savage, Howard) and standard in energy, pharma, and litigation strategy; applied transfer is mixed because outputs are dominated by input quality, and sensitivity analysis is the part with the best practice record.

### Source
Howard Raiffa, *Decision Analysis* (1968); Ronald A. Howard, "Decision Analysis: Applied Decision Theory" (1966). Admission verdict: **Build** (v0.1.12) — choice-among-gambles is a third question type in this category, distinct from estimation (Probabilistic Reasoning) and preference scoring (Decision Matrix); folding it into either would blur all three.

## Fault Tree Analysis
> source: fault-tree-analysis.md
### Core Concept
Start from one named top event and work **downward** deductively: what must be true for the top event to occur? Each event branches through AND/OR gates until reaching basic events that need no further decomposition. The tree's value is in its **minimal cut sets** — the smallest combinations of failures whose joint occurrence alone produces the top event — which are exactly the things to fix first. Quantitative forms attach probabilities and compute the top-event probability.

### Applicable Scenarios
✅ **Best for**
- One specific, serious failure that demands causal decomposition ("the payment service failed")
- Safety-critical, reliability, and regulatory analysis (aerospace, nuclear, medical, chemical)
- Deciding which single fix breaks the most failure paths

⚠️ **When NOT to use**
- Sweeping a system for whatever might fail → FMEA is bottom-up per component; FTA starts from one event and is the wrong tool when the top event is not yet identified
- The failure is a vague sentence ("the platform failed") → FTA needs one crisp, falsifiable top event; a vague apex produces a meaningless tree
- Ranking many small risks → Risk Matrix (P×I) or FMEA (RPN) handle breadth; FTA is depth on one failure
- Symbolic gates past roughly three levels of OR → the tree stops being maintainable; switch to FMEA or Why Tree
- You cannot enumerate basic events → an unclosed tree is decoration; the leaves are where the work is

### Key Steps
1. Define the top event precisely: one sentence, falsifiable, with the boundary conditions (which system, which time window, what counts as failure)
2. Draw the tree level by level: each event decomposes through an explicit **AND gate** (all children must occur) or **OR gate** (any child suffices) — state the gate type on every branch
3. Stop at basic events: no further decomposition is possible or useful; record each one's boundary condition
4. Extract minimal cut sets: the minimal combinations of basic events that produce the top event (a cut set of size 1 is a single-point failure)
5. Rank by cut-set significance: single-point cuts first, then by expected contribution if quantified
6. Quantify (optional): assign each basic event a probability, compute the top-event probability by Boolean algebra or simulation, and state the independence assumption you relied on
7. Validate against evidence: check each basic event against logs, incident history, and tests — a tree that no incident ever matched is probably the wrong tree
8. Act on the cut sets: fix, add redundancy, or add detection, then re-derive

### Output Template

```
Top event: [one falsifiable sentence + boundary conditions]
Tree:
  [Top event]
   ├─ OR ─ [Event A] ─ AND ─ [basic] / [basic]
   └─ OR ─ [Event B]
Minimal cut sets:
  CS1: [basic A] (single-point — size 1)
  CS2: [basic C] + [basic D]
Significance: [CS1 > CS2 ...] + [what is protected by fixing each]
Quantification: P(top) ≈ [value] under [independence/correlation assumption], or qualitative only
Evidence check: [each basic event: confirmed by log/test | assumed | unknown]
Fixes: [cut set → action → residual risk]
```

### Failure Modes
- Gate confusion (AND vs OR) — the most damaging error, because it silently flips the logic: write the gate type explicitly on every branch and have someone else re-derive one level
- Vague apex event ("system unavailable") → decomposition becomes unfalsifiable; sharpen the top event before drawing anything
- Unclosed leaves: branches stop at "operator error" or "human factors" without the mechanism → drill to the specific condition, or the cut set is useless
- Probability without the independence assumption: basic events in the same subsystem are usually correlated → state the assumption, or run the simulation with correlation and compare
- Combinatorial explosion: the tree grows past what anyone can maintain → prune to the branches that change a decision, and record what you pruned
- Tree drawn but no cut-set analysis: the diagram is the deliverable, the decision never happens → cut sets and fixes are the deliverable
- Confirming bias in the evidence check: only looking for the leaves that fit the suspected cause → check the leaves you expect to be absent too

### Evidence Strength
**Mixed.** Safety-critical practice is standardized and long-established (IEC 61025 syntax, nuclear and aerospace certification), and the qualitative decomposition discipline is genuinely useful. The quantitative form is weaker than it looks: multiplying probabilities assumes independence among basic events, and in real systems basic events sharing a common cause are the rule — which is why industry practice leans on cut-set analysis and simulation over closed-form products.

### Source
IEC 61025, *Fault Tree Handbook* (1992); US NRC NUREG-0492, *Fault Tree Handbook* (1982); Edward F. Singleton, "The Essence of Fault Tree Analysis"; Edward O. Robinson, "Fault Tree Analysis" hmm — Robinson's is the standard textbook (1983). Admission verdict: **Build** (v0.1.15) — the v0.1.13 Recipe verdict (FMEA "owns" it) was factually wrong: no entry held FTA, so the pointer in `fmea.md` was a dead route; FTA complements rather than duplicates FMEA's question (one top event downward vs many components upward).

## Monte Carlo Simulation
> source: monte-carlo-risk.md (original title: Monte Carlo Simulation & Quantitative Risk)
### Core Concept
Turn a model whose inputs are uncertain into an output **distribution** instead of a point answer: give every uncertain input a distribution, sample them many times, push each sample through the model, and read the resulting spread. What a point estimate hides becomes visible — the median, the P10/P90 band, and above all the tail (VaR, Expected Shortfall) where ruin lives. The arithmetic is exact given the model; the judgment sits in the input distributions and, fatally, in the correlation assumptions.

### Applicable Scenarios
✅ **Best for**
- Financial exposure: expected loss, portfolio risk, pricing, reserves, project cash flow under variable rates and volumes
- Any risk whose aggregate must be summed across uncertain, partly dependent components
- "How bad can this get, and what drives it" on a model with several interacting uncertainties
- Decisions where the downside tail (not the mean) drives the choice

⚠️ **When NOT to use**
- One uncertain quantity → Probabilistic Reasoning (base rate + likelihood ratio) is cheaper and clearer
- A handful of countable discrete outcomes → Decision Tree & Expected Value gives the exact number; simulation adds sampling noise for nothing
- You cannot state input distributions credibly → the simulation is a precision costume over invented numbers; get a reference class first or state the model qualitatively
- Deterministic compliance, safety, or legal questions → these need a defensible answer, not a distribution
- The question is simply "big or small" → the overhead is not repaid
- Inputs are known and bounded, with no interaction → interval reasoning or FMEA ranks as well

### Key Steps
1. Define the model: write the output as an explicit function of the inputs; if you cannot, you cannot simulate it
2. Specify each input's distribution with a stated basis (empirical data, reference class, or justified assumption) — mark which are assumed
3. Handle correlation explicitly: state the copula or the common-factor structure; if you assume independence, say so and test the sensitivity of the answer to it
4. Sample and converge: run enough iterations that the output statistics stop moving (report the convergence check, not just the count)
5. Read the distribution, not the mean: median, P10/P90 band, tail measures (VaR at a stated confidence, Expected Shortfall beyond it), and the probability of breaching a hard limit
6. Find the drivers: rank inputs by their contribution to output variance (tornado chart, rank correlation) — this is usually the actionable output
7. Stress-test the correlated case: model the joint shock scenario (rates, demand, regulation moving together) and read the loss there
8. Document: distributions, correlation assumptions, seed, iteration count, and what the result does *not* cover

### Output Template

```
Model: [output = f(input1, input2, ...)]
Inputs:
  [input] — distribution: [dist + basis: empirical | reference class | assumed] — [flag]
Correlation: [structure assumed + which pairs are dependent + independence test result]
Simulation: [iterations] — convergence: [stat stable at N]
Output distribution: median [x], P10/P90 [a, b], VaR95 [y], ES95 [z]
Breach probability: [P(loss > limit) = ...]
Drivers (variance contribution): [ranked inputs]
Stress case: [joint shock scenario → result]
Limitations: [what is not modeled; confidence + assumptions recorded]
```

### Failure Modes
- Invented distributions tuned to a comfortable answer → every distribution needs a stated basis; if the basis is "it felt right", the output is a mirror
- Independence assumed where inputs move together → the most damaging error, because the tail is then badly understated; model the common factor and compare the two answers
- Simulation without a convergence check → 1,000 iterations looks authoritative and is noise; report when the statistics stabilize
- Reading the mean only → ruin lives in the tail; a project with positive expected value and 20% chance of bankruptcy is not a good project
- Precision costume: 6 inputs, 2 of them guessed → the output has more decimal places than the inputs deserve; screen inputs first, then simulate
- Correlation fudged to make the answer stable → if you cannot defend the correlation, present a range of correlation assumptions instead of one number
- Presenting P95 without naming what was modeled → the number travels and loses its conditions
- Simulating a model with no causal structure: correlations baked in as coefficients, then re-simulated → you are running your assumptions, not reality

### Evidence Strength
**Strong for the method, conditional on the inputs.** Monte Carlo is a deterministic computation over sampled distributions: the technique itself is exact and verifiable, and it is standard practice in financial risk, engineering reliability, and insurance. The uncertainty lives entirely in the distributional and correlation choices — and those are judgment, not computation, so a rigorous-looking result can rest on invented inputs. The technique earns its reputation precisely by making that dependence visible; use it for the spread, not for false certainty.

### Source
David Luenberger, *Investment Science* (1998); Edward O. Thorp, *The Mathematics of Finance* (2002); McNeil, Frey & Embrechts, *Quantitative Risk Management* (2005); Rockafellar & Uryasev, "Optimization of Conditional Value-at-Risk", *Journal of Risk* (2000). Admission verdict: **Build** (v0.1.15) — `risk-matrix.md` routed quantitative exposure to "FMEA or Monte Carlo", but no entry held Monte Carlo; the missing target was a genuine gap, not a duplicate of FMEA (continuous unbounded distributions vs ranked discrete failure modes).

## Category Guide
## Decision Making

**When to use**: Need to make a defensible decision among multiple options


### Minimum Information Requirements per Methodology

- **RICE**: Requires option list + basic magnitude awareness
- **OKR**: Requires clear time period and responsible entity
- **Pre-mortem**: Requires an existing clear plan/decision
- **Decision Matrix**: Requires at least 3 alternatives + criteria list
- **MoSCoW**: Requires requirement list + stakeholder involvement
- **FMEA**: Requires component decomposition of system/process
- **Death Filter**: Requires major irreversible decision + candidate options (not for daily/urgent decisions)
- **Eisenhower Matrix**: Requires task list to classify (personal/team task management)
- **Risk Matrix**: Requires identified risk list + probability/impact scale definitions
- **Reversibility Grading**: Requires a named decision + concrete undo path (rollback, revoke, re-negotiate)
- **OODA Loop**: Requires a still-moving situation + at least one reversible next action
- **Probabilistic Reasoning**: Requires a checkable claim (outcome + timeframe + unit) + a reference class or prior anchor
- **Principled Negotiation**: Requires a live counterpart + your own alternatives inventoried and valued (a BATNA you could actually exercise)
- **Decision Tree & Expected Value**: Requires discrete alternatives + base-rate-anchored probabilities + quantifiable payoffs (ordinal utility acceptable)
- **Fault Tree Analysis**: Requires one crisp falsifiable top event + an enumerable chain of intermediate causes (leaf enumeration happens during execution)
- **Monte Carlo Simulation**: Requires an explicit output function of several uncertain inputs + a stated basis for each input distribution (and for correlation)

### Routing Trigger Signals

- "Feature/requirement prioritization" → RICE Scoring (primary) ⚡ If evaluation dimensions need customization (not R/I/C/E) → use Decision Matrix; if need quick rough screening in 30 min → use ICE
- "Personal/team task management" → Eisenhower Matrix (primary)
- "Goal setting and tracking" → OKR (primary)
- "Risk rehearsal before major decision" → Pre-mortem & Counterfactual (primary)
- "Multi-option multi-criteria selection (custom evaluation dimensions)" → Decision Matrix (primary) ⚡ If evaluation dimensions are fixed as Reach/Impact/Confidence/Effort → use RICE
- "Requirement scoping / scope management" → MoSCoW Method (primary)
- "Systematic risk identification / failure mode analysis" → FMEA (primary)
- "Major life decision / career choice / startup direction (value-based decision)" → Death Filter (primary)
- "Quick risk assessment / risk ranking / risk panorama scan" → Risk Matrix (primary)
- "How much analysis does this decision deserve / is it reversible / one-way vs two-way door" → Reversibility Grading (primary) ⚡ If the question is values-level "should I do this at all" (life/career/startup direction) → use Death Filter
- "Situation still moving, must act under time pressure (incident, outage, moving-target debugging)" → OODA Loop (primary) ⚡ If already stabilized → use Incident Response & Postmortem (Engineering); if rehearsing before action → use Pre-mortem & Counterfactual
- "Forecast / estimate an uncertain number / how likely is X / update a belief with evidence" → Probabilistic Reasoning (primary) ⚡ If only qualitative ranking of known risks → use Risk Matrix; if weighing options against criteria → use Decision Matrix
- "Negotiate a deal / salary / vendor terms / reach agreement with another party / deadlock over positions" → Principled Negotiation (primary) ⚡ If no real alternative to walk away to → build the BATNA first (Decision Matrix + Reversibility Grading); if mapping who influences the outcome without a live counterpart → use Stakeholder Mapping (Strategic Analysis)
- "Build vs buy / settle vs litigate / what's the expected value of this gamble / weight the option by what could happen" → Decision Tree & Expected Value (primary) ⚡ If estimating one uncertain quantity (no choice among branches) → use Probabilistic Reasoning; if scoring options on criteria without probability structure → use Decision Matrix
- "One specific failure keeps happening / decompose why X failed / what single fix breaks the most failure paths / safety-critical reliability" → Fault Tree Analysis (primary) ⚡ If sweeping all components for whatever might fail → use FMEA; if ranking many risks by severity → use Risk Matrix
- "Expected loss in dollars / aggregate risk across uncertain components / how bad can this get / what drives the outcome / tail risk" → Monte Carlo Simulation (primary) ⚡ If the outcomes are countable and discrete → use Decision Tree & Expected Value; if ranking a known risk list → use Risk Matrix; if estimating one number → use Probabilistic Reasoning

### Common Combinations

- **Major decision**: Socratic questioning (clarify assumptions) → Decision Matrix → Pre-mortem (risk review)
- **Requirement full lifecycle**: Kano (classify nature) → MoSCoW (scope) → RICE (prioritize)
- **Comprehensive risk assessment**: FMEA (systematic identification) → Pre-mortem (imaginative supplement) → Second-Order Thinking (chain effects)
- **Major life/startup decision**: Death Filter (filter true inclination) → Pre-mortem (rehearse selected direction risks) → Second-Order Thinking (long-term effects)
- **Project kickoff risk assessment**: Pre-mortem (identify risks) → Risk Matrix (quantify and rank) → FMEA (deep analysis of high-risk items)
- **Technology selection risk**: Decision Matrix (option comparison) → Risk Matrix (risk ranking) → Second-Order Thinking (chain effects)
- **Uncertain reversible decision**: Reversibility Grading (classify undo cost) → Probabilistic Reasoning (bound the estimate) → OODA Loop (cycle if the situation keeps moving)
- **In-flight incident**: OODA Loop (cycle reversible moves while degraded) → Incident Response & Postmortem (extract learning after stabilization)

### Similar Methodology Disambiguation Decision Tree

When user intent is ambiguous between these methodologies, disambiguate per the decision tree:

```
"Multi-option evaluation and ranking"
  ├─ Evaluation dimensions fixed as Reach/Impact/Confidence/Effort?
  │   └─ Yes → RICE Scoring
  ├─ Evaluation dimensions need customization? (e.g. tech selection: performance/cost/risk)
  │   └─ Yes → Decision Matrix
  └─ Need quick rough screening in 30 min, no precise quantification needed?
      └─ Yes → ICE Framework

"Task/requirement ranking"
  ├─ Personal/team daily task management?
  │   └─ Yes → Eisenhower Matrix
  ├─ Product feature/requirement prioritization?
  │   └─ Yes → RICE Scoring
  └─ Requirement scope trimming (do / don't do)?
      └─ Yes → MoSCoW Method

"Risk assessment"
  ├─ Existing clear plan, need to rehearse failure scenarios?
  │   └─ Yes → Pre-mortem
  ├─ Need systematic failure mode identification?
  │   └─ Yes → FMEA
  └─ Need quick risk panorama scan and ranking?
      └─ Yes → Risk Matrix

"How much process does this decision deserve?"
  ├─ Values-level "should I do this at all" (life, career, startup direction)?
  │   └─ Yes → Death Filter
  ├─ Undo cost is the open question (tech, product, process, org call)?
  │   └─ Yes → Reversibility Grading
  └─ Situation moving + time pressure + reversible moves available?
      └─ Yes → OODA Loop

"Estimating an uncertain quantity"
  ├─ Qualitative screening of an identified risk list?
  │   └─ Yes → Risk Matrix
  ├─ Estimating / forecasting a number that updates with evidence?
  │   └─ Yes → Probabilistic Reasoning
  └─ Situation still moving and action cannot wait for the estimate?
      └─ Yes → OODA Loop (act on ~70% confidence for reversible moves)

"Reaching agreement with another party"
  ├─ Live counterpart, terms on the table (price, salary, scope, partnership)?
  │   └─ Yes → Principled Negotiation
  ├─ No live counterpart — deciding whether/how much to commit to a path?
  │   └─ Yes → Reversibility Grading (or Death Filter for values-level calls)
  └─ Multiple parties with veto power, no single negotiation table?
      └─ Yes → Stakeholder Mapping (Strategic Analysis)

"Choosing among probabilistic outcomes"
  ├─ Discrete options, outcomes with probabilities and quantifiable payoffs?
  │   └─ Yes → Decision Tree & Expected Value
  ├─ One uncertain quantity to estimate (no branch choice)?
  │   └─ Yes → Probabilistic Reasoning
  └─ Fixed evaluation criteria, no probability structure?
      └─ Yes → Decision Matrix
```

### Methodology Mutual Exclusion and Ordering Constraints

| Constraint pair | Rule | Reason |
| --- | --- | --- |
| RICE ↔ ICE | **ICE for rough screening → RICE for fine ranking**, don't use in parallel | ICE is a simplified version of RICE; parallel use produces redundant output |
| RICE vs Decision Matrix | **Choose by evaluation dimensions**: fixed R/I/C/E→RICE; custom dimensions→Decision Matrix | Core difference is whether dimensions are fixed; input structure is similar but purposes differ |
| FMEA → Pre-mortem | **FMEA before Pre-mortem** (comprehensive risk assessment scenario) | FMEA systematically identifies; Pre-mortem supplements imaginatively |
| Reversibility Grading vs Death Filter | **Choose by question level**: values-level "whether at all"→Death Filter; process depth "how much analysis"→Reversibility Grading | Different questions about the same decision; they compose on big calls (filter first, then grade) rather than run in parallel |
| OODA Loop → Incident Response & Postmortem | **Same event, by phase**: in-flight → OODA Loop; stabilized → Incident Response & Postmortem (`engineering/`) | Both on the same live event split attention from the loop; postmortem needs the stabilized outcome as input |
| Probabilistic Reasoning vs Risk Matrix | **Choose by treatment**: calibrated estimate that updates with evidence→Probabilistic Reasoning; qualitative P×I screening of a risk list→Risk Matrix | Same input (uncertainty), different output: a number to revise vs a zone to rank |
| Principled Negotiation vs Stakeholder Mapping | **Choose by state**: live counterpart with terms→Principled Negotiation; mapping all parties' influence before/without a table→Stakeholder Mapping (Strategic Analysis) | Negotiation works one counterpart's interests; stakeholder mapping works the whole influence field — feeding it into your BATNA estimate |
| Decision Tree vs Decision Matrix vs Probabilistic Reasoning | **Choose by question type**: choosing among probabilistic gambles→Decision Tree; scoring options on criteria→Decision Matrix; estimating one uncertain quantity→Probabilistic Reasoning | Same inputs recur (options, uncertainty) but the outputs differ: a choice, a ranking, a number |
| Fault Tree Analysis vs FMEA | **Choose by direction**: one top event decomposed downward→Fault Tree Analysis; sweeping components upward for failure modes→FMEA | FTA's output is minimal cut sets (what to fix first); FMEA's output is a ranked failure-mode list. Compose them: FTA finds the cut set, FMEA ranks the individual modes inside it |
| Monte Carlo vs Decision Tree & Expected Value | **Choose by outcome shape**: continuous/unbounded outcomes needing a tail→Monte Carlo; countable discrete branches needing an exact EV→Decision Tree & Expected Value | Simulation approximates with sampling error; a tree over discrete outcomes is exact. Do not pay sampling noise for a number you can compute |
