# Research Methodology (compact aggregate)
> Aggregated from `references/research-methodology/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh research-methodology "<methodology>"`

## Systematic Research Process
> source: systematic-research-process.md
### Core Concept
5-step closed-loop research: Question → Search → Evaluate → Synthesize → Output. Ensures research is thorough, evidence-based, and produces actionable conclusions.

### Applicable Scenarios
✅ **Best for**
- Complex problem research
- Industry research
- Technology selection research

⚠️ **When NOT to use**
- Simple factual lookups — the loop costs more than the answer
- Deadline-driven decisions where "search + first credible source" is the honest ceiling — say so rather than simulating depth
- Research questions you can't state precisely — vague questions generate unbounded search; refine the question first (that's a meta-step the loop presupposes)

### Key Steps
1. **Question**: Define the research question clearly; decompose into sub-questions
2. **Search**: Gather information from multiple source types (academic, industry, expert interviews, data)
3. **Evaluate**: Assess source credibility, cross-validate findings, flag biases
4. **Synthesize**: Integrate findings into a coherent narrative; identify patterns and gaps
5. **Output**: Produce actionable conclusions with evidence, confidence levels, and recommendations

### Output Template

```
Question: [precise, decidable] — sub-questions: 1. [...] 2. [...]
Decision this research serves: [what will change based on the answer]

Search log: [source → type (academic/industry/primary data) → date accessed]
  Sources by type: academic [n] / industry [n] / primary data [n] / expert [n]

Evidence table:
  | Finding | Sources (≥2 independent?) | Confidence (High/Med/Low) | Conflicting evidence |
  | [X]     | [S1, S2]                  | High                      | [S3 disagrees — why] |

Synthesis: [pattern across findings] — remaining gaps: [what we still don't know]
Output: answer to each sub-question + recommendation + confidence + [what would change our mind]
```

### Failure Modes
- Search-ending-at-confirmation: research stops at the first supporting source — the answer was chosen before the search → the evidence table requires ≥2 independent sources per finding, and conflicts must be shown, not smoothed
- Source-stacking without credibility weighting: vendor white papers and peer-reviewed work listed as equals → label source type and incentive per row; vendor claims about themselves get discounted explicitly
- Synthesis ghostwriting: the narrative smuggles in prior beliefs between the evidence rows → every synthesis claim must cite the evidence rows that support it; uncited narrative lines get cut

### Evidence Strength
Mechanism-level — the loop is a process discipline distilled from established research practice (systematic review norms, source triangulation); it has no outcome validation of its own, but its components (pre-registration of questions, multi-source triangulation, explicit confidence) map onto documented bias countermeasures.

### Source
Evidence-based research methodology; adapted from academic research practices.

## Qualitative Synthesis
> source: qualitative-synthesis.md
### Core Concept
Turn a pile of qualitative data — interview transcripts, field notes, support tickets — into a small set of themes, each backed by verbatim evidence and an honest confidence label. Five phases: Familiarize → Code → Theme → Synthesize → Report. Division of labor: Systematic Research Process runs the full research loop (question → search → output); this card owns the analysis half — what happens after data is already in hand. For study design before fieldwork, see Qualitative Research Plan (User Research).

### Applicable Scenarios
✅ **Best for**
- Data already collected: interview series, usability debriefs, open survey comments, support logs
- "We did 10 interviews — now what?"
- Producing findings someone can act on without re-reading every transcript

⚠️ **When NOT to use**
- Fewer than ~5 sources — patterns from 2 sources are anecdotes; write a memo or use Empathy Map instead
- Data is numeric or event logs — thematic coding adds subjectivity, not insight; analyze quantitatively
- The research question isn't framed yet — clarify it first (Systematic Research Process, step 1)

### Key Steps
1. **Familiarize**: read everything once before labeling anything. Per source, write a short memo: their story, 3-5 verbatim quotes, what they DO vs what they SAY, emotional intensity, what surprised you. Grade data quality — transcripts are richest; notes are pre-filtered by the note-taker; summaries are an interpretation layer (lowest trust).
2. **Code**: label meaningful excerpts. Start from interview questions and known frameworks (deductive), but let participants' own words become codes too (in-vivo) — the start list is a scaffold, not a cage. Maintain a tag table: code / one-line definition / example quote / frequency. Split codes that blur; merge codes only you can tell apart.
3. **Theme**: aggregate codes across participants. A theme is not a renamed code — apply the touch test: if you can physically touch it ("login screen", "pricing page"), it's a topic; keep abstracting until you can't ("users build private workarounds before ever asking for help"). Target 5-10 themes, each grounded in ≥2 independent sources.
4. **Synthesize**: map relations between themes — what conditions what, what leads to what, where themes contradict. Actively hunt negative cases and outliers: each one either sharpens a theme with a boundary condition or exposes it as overreach. Note absences — expected topics nobody raised are findings too.
5. **Report**: pearls, not oysters — the body explains; raw evidence goes to the appendix. Every theme ships with a claim, one luminous quote plus 2-3 echoes, prevalence (x of n), and a confidence label (High/Medium/Low) with its basis: source count, behavior vs stated, triangulation.

### Output Template

```
Theme 1: [untouchable insight phrase] — prevalence x/n — confidence H/M/L (basis: ...)
  Claim: [2-3 sentences, ties back to the research question]
  Evidence: > "[verbatim quote]" — [source ID, location]
             > "[echo]" — [ID]   > "[echo]" — [ID]
  Negative case: [who doesn't fit + why] | Absence: [expected, never heard]

Contradictions: [theme A vs theme B — who holds each side]
Open questions: [what this dataset cannot answer]
```

### Failure Modes
- Topic parade: "themes" that are touchable topics ("pricing", "onboarding") — labels, not insights → run the touch test on every theme
- Cherry-picked quotes: one vivid quote carrying a theme → every theme needs ≥2 independent sources and stated prevalence
- Premature coding: tagging during the first read → first pass is reading, memos precede codes; otherwise you code your expectations, not the data
- Buried disconfirmation: counter-evidence dropped to keep the story clean → negative cases go in the report, not the trash

### Evidence Strength
Practitioner consensus — thematic analysis is the standard qualitative method across UX and social science; its known limits are analyst subjectivity and small-n generalization, which evidence-linkage and confidence-labeling mitigate but cannot remove.

### Source
Thematic analysis tradition (Braun & Clarke).
Provenance: five-phase workflow absorbed from [cookiy-ai/user-research-skill](https://github.com/cookiy-ai/user-research-skill) (MIT license); sub-agent orchestration and platform bindings stripped, rewritten as a single-analyst method, absorbed 2026-09.
Admission: Build (new entry) — owns post-fieldwork qualitative analysis (code → theme → report); Systematic Research Process runs the research loop, not the analysis half.

## Category Guide
## Research Methodology

**When to use**: Need systematic research on complex problems, producing evidence-backed conclusions


### Minimum Information Requirements per Methodology

- **Systematic Research Process**: Clear research question + accessible multi-source information channels
- **Qualitative Synthesis**: ≥5 raw qualitative sources (transcripts/notes/logs) + a framed research question to tie themes back to

### Routing Trigger Signals

- "Research / investigate / analyze a complex problem" → Systematic Research Process (primary)
- "Need conclusions with multi-source cross-validation" → Systematic Research Process (primary)
- "Technology selection / industry trends / competitive deep dive" → Systematic Research Process (primary)
- "Interview transcripts → synthesis" / "make sense of interviews / notes / support tickets" → Qualitative Synthesis (primary)
- "Find themes in qualitative data / what did users tell us" → Qualitative Synthesis (primary)

### Common Combinations

- **Industry research**: Systematic Research Process (information gathering) → Industry Value Chain (value chain analysis) → Gartner Hype Cycle (technology maturity)
- **Competitive research**: Systematic Research Process (information gathering) → SWOT (competitive comparison)
- **Technology selection**: Systematic Research Process (information gathering) → Gartner Hype Cycle (maturity assessment) → DCF (ROI evaluation)
- **User interview study**: Qualitative Research Plan (study design, User Research) → Qualitative Synthesis (analysis) → Empathy Map (structure the user model, User Research)
- **Support-ticket mining**: Qualitative Synthesis (theme the tickets) → JTBD (frame underlying jobs, Product & Growth)
