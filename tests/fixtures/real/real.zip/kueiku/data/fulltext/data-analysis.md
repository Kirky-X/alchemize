# Data Analysis (compact aggregate)
> Aggregated from `references/data-analysis/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh data-analysis "<methodology>"`

## Cohort Analysis
> source: cohort-analysis.md
### Core Concept
Track user retention by grouping users into cohorts (typically by signup date) and measuring how many remain active over time. Reveals whether retention is improving, stable, or declining — a key PMF signal.

### Applicable Scenarios
✅ **Best for**
- Is retention improving over time?
- PMF (Product-Market Fit) assessment
- Identifying drop-off patterns and engagement trends

⚠️ **Use with caution**
- Very new products without enough cohort history
- Highly seasonal products where cohort timing biases results

⚠️ **When NOT to use**
- The question is causal, not descriptive — cohort curves show what happened to a group, never why; a change in the curve needs a controlled comparison → **A/B Test Analysis**
- The behavior is not recurring — a one-off purchase, a single event, or a lifetime-value read has no retention curve to trace → **RFM Model** for value segmentation
- Cohort cells are too thin to compare — small groups turn a retention difference into sampling noise; set a minimum cell size before reading the matrix
- Seasonality dominates the comparison — a holiday cohort is being compared against a normal one; align periods before concluding anything about the trend

### Key Steps
1. Define cohort grouping (typically by signup week/month)
2. For each cohort, track active users at each subsequent period (Week 1, Week 2, etc.)
3. Calculate retention rate = active users in period N / initial cohort size
4. Build a cohort retention matrix (cohorts as rows, periods as columns)
5. Look for patterns: are newer cohorts retaining better? Is there a drop-off cliff?

### Output Template
```
Cohort Retention Matrix:
           Period 1   Period 2   Period 3   ...
Cohort A:   100%       60%        45%
Cohort B:   100%       65%        52%
Cohort C:   100%       70%        ??

PMF Signal: [improving/stable/declining] retention trend
Key Insight: [notable pattern or anomaly]
```

### Failure Modes
- Undefined "active": the retention curve measures whatever the event definition happens to be → define the active event once, in measurable terms, and keep it stable across cohorts
- Definition changed mid-flight: a definitional change looks exactly like a retention improvement → freeze the definition per reporting period and flag any change next to the matrix
- Counts compared instead of rates: the largest cohort looks like the best-retaining one → normalize by initial cohort size and always show both the rate and the denominator
- Newest cohort read as a failure: a row observed for one week is not a decline, it is an unfinished row → compare only the periods that every cohort has reached

### Evidence Strength
Mixed — cohort retention is descriptive accounting over observed data with no randomization, so it can show whether retention is changing but never why; the matrix itself is reliable arithmetic given a stable definition and adequate cell sizes. Its main weaknesses are definitional drift (what counts as active) and the standing temptation to read a descriptive trend as a causal one, and its predictive reach is limited because it describes the cohorts that have already arrived rather than the ones yet to come — use it for trend and PMF signals and pair it with a controlled design for any causal claim.

### Source
Lean Analytics (Croll & Yoskovitz); standard product analytics methodology.

## A/B Test Analysis
> source: ab-test-analysis.md
### Core Concept
Statistical comparison of two or more variants to determine if observed differences are statistically significant. Includes sample size calculation, significance testing, decision framework (Ship/Extend/Stop/Investigate), and SRM (Sample Ratio Mismatch) detection.

The `abtest` script analyzes 3+ variant inputs as follows: the first two variants get the primary analysis (z-test, SRM, decision); every additional variant is explicitly summarized and compared against the control in a separate "Additional Variants" section — never silently dropped. For 3+ variant decisions, correct for multiplicity (e.g. Bonferroni α = 0.05 / number of comparisons).

### Applicable Scenarios
✅ **Best for**
- A/B test design and decision-making
- Determining if a change has a real effect
- Comparing multiple treatment variants

⚠️ **Use with caution**
- Very small sample sizes (underpowered tests)
- Multiple metrics without correction (multiple comparisons problem)

⚠️ **When NOT to use**
- Many simultaneous changes that may interact — a two-arm test cannot separate their effects; use factorial or sequential designs, and read the result as a bundle-level answer rather than a per-change one
- Individual-level assignment impossible (campaigns spanning regions, stores, or time periods) → randomize at the **geo/cluster level** and analyze cluster-level outcomes; for time-varying treatments use switchback designs — the power, SRM, and decision machinery below apply unchanged, only the unit of randomization changes
- Reading results before the pre-registered decision point — peeking converts a pre-registered test into a search for a lucky read; fix the sample size and the stopping rule first, then look
- Outcomes that cannot be observed soon enough to decide — if the metric takes a season to move, the experiment buys delay instead of an answer; ship and monitor instead
- Instrument changes or other measurement artifacts riding along with the treatment — novelty, notification, or instrumentation effects can dominate the signal → audit the data path with **Cognitive & Statistical Bias Checklist** before trusting the read

### Key Steps
1. Define hypothesis: H0 (no difference) and H1 (expected difference)
2. Calculate required sample size (power analysis)
3. Run test, collect data per variant
4. Check SRM: actual vs expected sample ratios (chi-squared test, χ² > 3.841 at α = 0.05, df = 1)
5. Run statistical test (z-test for proportions, t-test for continuous)
6. Apply decision framework: Ship / Extend / Stop / Investigate

### Output Template
```
A/B Test Results:
Variant A: [users] [conversions] [rate]
Variant B: [users] [conversions] [rate]

Statistical Test:
  p-value: [...]
  Confidence interval: [...]
  SRM check: [PASS/FAIL]

Decision: [Ship/Extend/Stop/Investigate]
Reason: [...]
```

### Failure Modes
- Peeking and early stopping: the result is read daily and the test is stopped at the first favorable p-value → set the sample size and the duration in advance, or use a sequential design built for repeated looks
- Unplanned multiple comparisons: several metrics or several segments are tested and only the winner is reported → count the comparisons actually run, correct the alpha, and pre-register the primary metric
- Metric gaming: a proxy that can be moved without moving value → pair the primary metric with a guardrail metric that cannot be moved cheaply, and read both
- Sample ratio mismatch ignored: the assignment path is broken, so the arms are not comparable no matter how small the p-value → treat any SRM as fatal; stop, debug the allocation and logging, then rerun
- Underpowered test read as a null result: "not significant" is reported as "no effect" → report the confidence interval and the power; a wide interval is an unknown, not a zero

### Evidence Strength
Strong — the randomization core is the most rigorously validated method in this corpus: random assignment with pre-registration genuinely identifies causal effect, the estimators are standard statistics, and the failure conditions are documented and fixable. The caveat is that validity is lost in practice far more often than in theory: peeking, unplanned multiple comparisons, metric gaming, and an ignored sample-ratio mismatch routinely convert a well-designed test into a confident wrong answer, which is why pre-registration, multiplicity correction, and the SRM check have to be treated as binding rather than optional.

### Source
Standard statistical methodology; Ron Kohavi et al., *Trustworthy Online Controlled Experiments*.

## Lean Analytics Metrics
> source: lean-analytics-metrics.md
### Core Concept
Framework for selecting the right metrics using 4 criteria + 8 metric types + North Star Metric (NSM) 4 layers. Helps teams avoid vanity metrics and focus on actionable, leading indicators.

### Applicable Scenarios
✅ **Best for**
- Metrics framework selection
- Defining what "good" looks like for your product
- Aligning team around actionable metrics

⚠️ **When NOT to use**
- Instrumentation doesn't exist — metric design without data plumbing produces aspirational dashboards
- Pre-product/market fit — the book's whole point is the metric changes per stage; installing a growth-stage NSM early misleads
- One-off analysis questions — use the analysis tool directly; this framework is for choosing standing metrics

### Key Steps
1. Apply the 4 criteria: Is it actionable? Accessible? Auditable? (4th: is it relevant?)
2. Identify which of the 8 metric types applies: Trending, Ranked, Ratio, Percentage, Average, Median, NPS, etc.
3. Define your NSM across 4 layers: Input metrics → Throughput metrics → Output metrics → Outcome metrics
4. Validate: does the metric drive decisions? Is it leading or lagging?
5. Build a metrics dashboard aligned to the NSM hierarchy

### Output Template

```
Stage: [empathy / stickiness / virality / revenue / scale] — business model: [type]
North Star Metric: [one metric, outcome-flavored] — why it's the best proxy for delivered value: [reason]

NSM hierarchy:
  Input metrics    → [signups started, content created]      (team moves these weekly)
  Throughput       → [activation rate, funnel conversion]    (process health)
  Output metrics   → [WAU, paid conversions]                 (product results)
  Outcome metrics  → [revenue, retention-adjusted growth]    (business results)

Vanity purge: [pageviews / total downloads / registered users] — why excluded: [only goes up, no decision attached]
4-criteria check on NSM: actionable [how a decision changes] / accessible [who can query it] / auditable [can we verify] / relevant [to this stage: y/n]
Review cadence: [weekly inputs / monthly outputs]
```

### Failure Modes
- NSM by committee averaging: a "blended" metric nobody can move → one metric, owned by one team, with a stated causal story to outcomes
- Input-output confusion: celebrating input spikes (ship count) as outcome progress → dashboards must label layers; inputs are levers, not wins
- Metric ossification: the stage changed, the metric didn't → re-derive NSM at every stage transition (and after major pivots)

### Evidence Strength
Practitioner consensus — the good-metric criteria (actionable, accessible, auditable) are standard measurement hygiene and the stage-model is a useful heuristic from lean practice; the specific 8-type taxonomy and NSM layering are organizing devices without independent empirical validation — metric quality is ultimately judged by whether decisions improve.

### Source
Alistair Croll & Benjamin Yoskovitz, *Lean Analytics* (2013).

## RFM Model
> source: rfm-model.md
### Core Concept
Segment users along 3 transaction-based dimensions: Recency (how recently they purchased), Frequency (how often), Monetary (how much they spend). Users are scored on each dimension and classified into 8 segments for targeted marketing.

### Applicable Scenarios
✅ **Best for**
- User tiering and segmentation
- Precision marketing strategies
- Churn early warning
- User value assessment

⚠️ **When NOT to use**
- Recency and frequency are not the axes of the business — a subscription, a daily-use app, or a marketplace buyer expresses value through something RFM never measures → **Cohort Analysis** for behavior over time
- There is no transaction history — new users, or a business whose value is not transacted, cannot be scored → fall back to engagement-based segmentation
- The scoring cutoffs are inherited from a textbook — quantiles computed on a distribution that has shifted with the business produce segments that quietly mean something different each quarter → recompute and re-label on a schedule
- Individual-level action decisions that need causal support — RFM says who bought, not what will make them act → validate the treatment with **A/B Test Analysis** before rolling it out

### Key Steps
1. Collect transaction data: customer_id, recency (days since last purchase), frequency (total purchases), monetary (total spend)
2. For each dimension, assign quantile scores (1-5 or 1-10)
3. Combine R/F/M scores into 8 user segments: Champions, Loyal, Potential Loyalist, Recent, Promising, Need Attention, At Risk, Lost
4. Design targeted strategies per segment
5. Monitor segment migration over time

### Output Template
```
RFM Segmentation:
  Champions:       [count] — strategy: [reward & refer]
  Loyal:           [count] — strategy: [upsell & cross-sell]
  Potential Loyal: [count] — strategy: [engage more]
  Recent:          [count] — strategy: [build habit]
  Promising:       [count] — strategy: [increase frequency]
  Need Attention:  [count] — strategy: [re-engage]
  At Risk:         [count] — strategy: [win-back campaign]
  Lost:            [count] — strategy: [reactivate or release]
```

### Failure Modes
- Stale cutoffs: the scores are computed once and reused as the customer base shifts → recompute on a fixed schedule and version the segmentation so old and new segments stay comparable
- Recency truncation: users with no recent purchase are folded into "Lost" even when they were the largest buyers → segment churners by historical value before treating them as one group
- Equal-weight percentile scores: one point of Frequency and one point of Recency may be worth very different amounts of money → weight or re-band the dimensions against their actual business impact
- Labels read as causes: "At Risk" describes past behavior, not the reason for it → test the win-back treatment on a holdout instead of assuming the segment responds
- Segment sizes quoted without denominators: "3,000 At Risk users" says nothing about whether that group grew → always report the segment as a share of the base alongside its count

### Evidence Strength
Practitioner consensus — RFM is a long-established direct-marketing technique with a large operational base, and the underlying logic (recent, frequent, and high-value customers respond differently to contact and to offers) is consistent with long-standing customer-value practice. The evidence is largely campaign-performance experience rather than controlled studies, and the segment boundaries are analyst-chosen quantile cutoffs rather than discovered structure, so the result depends heavily on the recency window, the scoring scheme, and whether the segments map onto treatments that were ever shown to work.

### Source
Direct marketing analytics; standard CRM methodology.

## Cognitive & Statistical Bias Checklist
> source: debias-checklist.md
### Core Concept
A pre-flight checklist for any data analysis, organized by the analysis lifecycle: **Design** (what to measure, on whom) → **Collection** (how reality got recorded) → **Interpretation** (what the numbers mean) → **Reporting** (what gets decided). Each entry names one bias, the signal that it may be active, and one concrete check action. The unit of value is not knowing the name — it is catching, at a specific stage, the flaw that would most cheaply invalidate the conclusion if caught now and most expensively if caught after the decision.

### Applicable Scenarios
✅ **Best for**
- Reviewing an analysis (yours or someone else's) before acting on it
- Designing metrics, dashboards, or experiments — choosing what to measure and how
- Post-mortems on a wrong decision: locating which lifecycle stage let the flaw through

⚠️ **When NOT to use**
- As rhetoric to dismiss inconvenient findings — name the specific bias and run its check, or the checklist itself becomes a confirmation-bias instrument
- Exhaustively on trivial reads — full checklist for consequential decisions; on quick reads, check the one stage you are least sure of

### Key Steps

#### Stage 1 — Design (what to measure, on whom)

1. **Survivorship bias** — signal: the dataset contains only winners (current customers, surviving funds, live products); the churned, exited, and failed are structurally missing → check: state which population is invisible in this data; if failed units cannot appear, restate conclusions as conditional on survival, and in retention reads confirm cohorts include churned users (`cohort-analysis.md`).
2. **Selection bias** — signal: the sample arrived through a channel correlated with the outcome (opt-in surveys, one platform's users, volunteers) → check: write down the sampling mechanism; if it plausibly correlates with the outcome, treat between-group comparisons as confounded by unmeasured differences.
3. **Perverse incentive (Cobra Effect)** — signal: the metric doubles as someone's target, bonus, or OKR → check: ask how a rational agent maximizes this metric while defeating its purpose; if a gaming path exists, pair the metric with a counter-metric that the gaming would hurt.

#### Stage 2 — Collection (how reality got recorded)

4. **Observer effect** — signal: subjects know they are measured, or measurement requires intervention (surveys, instrumented builds, shadowed support queues) → check: compare measured behavior against an unobserved baseline or a pre-announcement trend; assume reported behavior ≠ natural behavior until shown otherwise.

#### Stage 3 — Interpretation (what the numbers mean)

5. **Data dredging (p-hacking)** — signal: many metrics, subsets, or cutoffs were tried and only the "significant" one is reported; the hypothesis was stated after seeing the result → check: count the tests actually run and apply multiplicity correction (`ab-test-analysis.md`); require out-of-sample or pre-registered confirmation for findings nobody predicted.
6. **Simpson's paradox** — signal: an aggregate trend reverses inside subgroups, or the groups differ both in size and in base rates → check: recompute the comparison within natural segments; if aggregate and segmented answers disagree, report both and name the weighting that produces the difference.
7. **Base-rate neglect** — signal: a result is judged by its hit rate alone ("the test is 90% accurate", "the signal fired") without asking how rare the target event is → check: start from the prior probability and update via the likelihood ratio (`decision-making/probabilistic-reasoning.md`); for rare events a 90%-accurate indicator is usually wrong when it fires.
8. **Gambler's fallacy** — signal: short-run history is expected to "correct" itself ("failed three times, so it's due", "the streak must end") → check: ask whether the trials are actually dependent; for independent trials the past changes nothing — recompute from base rates, not from the recent sequence.

#### Stage 4 — Reporting (what gets decided)

9. **Confirmation bias** — signal: the write-up contains only evidence for the favored conclusion; null results and disconfirming cuts are absent → check: require a "What would change my mind" section carrying the strongest counter-evidence found; a report without one is advocacy, not analysis.

### Output Template
```
Bias review: [analysis / metric / decision]
Per bias: [pass | flagged → check run + what it showed]
Blocked by: [failed checks that must be fixed before acting]
Verdict: proceed | fix first (which stage) | redesign measurement
```

### Failure Modes
- Checklist theater: boxes ticked without running the checks → a "pass" requires written evidence per flagged item, not a Yes column
- Bias name-calling: "that's just survivorship bias" as a debate move → checks, not labels, decide; no check run, no finding
- Uniform depth: running all nine checks on a dashboard tweak → match review depth to decision stakes, not to checklist length

### Evidence Strength
Mixed — the individual biases are well documented in the judgment-and-decision-making literature (selection and survivorship effects empirically robust; Simpson's paradox mathematically demonstrable; multiplicity correction standard statistics), while the lifecycle grouping and the specific check actions are kueiku's practitioner synthesis, not a validated instrument.

### Source
Heuristics-and-biases research program (Tversky & Kahneman); Geckoboard's statistical fallacies collection.
Provenance: bias coverage absorbed from [awesome-concepts](https://github.com/lukasz-madon/awesome-concepts) README Fallacies section (CC0 1.0 license) and [knowledge-skills](https://github.com/deciqAI/knowledge-skills) `logical-fallacies` / `sunk-cost-fallacy` / `narrative-fallacy` (MIT license); lifecycle structure, trigger signals, and check actions authored for kueiku, absorbed 2026-09.
Admission: Build (new entry) — owns stage-by-stage bias checking across the analysis lifecycle; existing data-analysis entries assume unbiased measurement.

## Category Guide
## Data Analysis

**When to use**: Retention analysis, A/B testing, metrics framework


### Minimum Information Requirements per Methodology

- **Cohort Analysis**: Requires user retention data grouped by time
- **A/B Test Analysis**: Requires A/B testing platform + statistics foundation
- **Lean Analytics Metrics**: Requires dashboard data + NSM candidates
- **RFM Model**: Requires user transaction data (last purchase date / purchase frequency / spend amount)
- **Cognitive & Statistical Bias Checklist**: Requires the analysis or metric design under review (question, data source, sampling mechanism, conclusions)

### Routing Trigger Signals

- "Cohort retention analysis" → Cohort Analysis (primary)
- "A/B test design and decision" → A/B Test Analysis (primary)
- "Metrics framework selection / good metric criteria" → Lean Analytics Metrics (primary)
- "User tiering / precision marketing / churn early warning / user value assessment" → RFM Model (primary)
- "Is this analysis trustworthy / bias check on findings / review before acting on data" → Cognitive & Statistical Bias Checklist (primary)

### Common Combinations

- **User value operations**: RFM Model (tiering) → Cohort Analysis (retention evolution) → A/B Test (strategy validation)
- **Growth analysis**: Lean Analytics Metrics (select metrics) → Cohort Analysis (check retention) → RFM Model (tiered operations)
- **Findings trust gate**: Cognitive & Statistical Bias Checklist (catch threats to validity) → A/B Test Analysis (verify the causal claim)
- **Retention audit**: Cohort Analysis (retention curves) → Cognitive & Statistical Bias Checklist (check survivorship in who is counted)
