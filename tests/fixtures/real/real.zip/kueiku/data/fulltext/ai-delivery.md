# AI Delivery (compact aggregate)
> Aggregated from `references/ai-delivery/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh ai-delivery "<methodology>"`

## Shipping Artifacts
> source: shipping-artifacts.md
### Core Concept
Core 5 + Conditional 4 document standards for AI project delivery. Defines the anti-PRD rule: traditional PRDs are insufficient; AI projects need living documents that evolve with the product.

### Applicable Scenarios
- AI project delivery standards
- Defining documentation requirements for AI products
- Ensuring deliverable quality

⚠️ **When NOT to use**
- Internal experiments and prototypes that will never face users — the artifact gate would outlive the project
- Non-AI deliveries — "model card" and "data specification" assume model behavior; classic delivery needs other standards
- As a paperwork gate bolted on after the build — documents written to pass a checklist at ship time are theater, the exact failure the anti-PRD rule exists to prevent

### Key Steps
1. Identify the Core 5 documents required for every project (problem statement, architecture decision records, data specification, model card, deployment guide)
2. Identify Conditional 4 documents based on project type (ethics review, bias audit, user privacy impact, rollback plan)
3. Apply the Anti-PRD rule: replace static PRDs with living documents that update with each iteration
4. Validate all required documents exist and are current before shipping
5. Archive shipping artifacts as reference for future projects

### Output Template

```
Project: [name] — ship target: [date]

Core 5 (required, with currency date):
  Problem statement        [exists: y/n, updated: date]
  Architecture decisions   [ADRs: list, last: date]
  Data specification       [exists, updated: date]
  Model card               [exists, updated: date]
  Deployment guide         [exists, updated: date]

Conditional 4 (required for this project type):
  Ethics review [y/n/why not]  Bias audit [y/n]  Privacy impact [y/n]  Rollback plan [y/n]

Currency check: any document older than the last model/prompt change → [block ship / justify exception]
Living-document cadence: which doc updates on each iteration: [answer]
Archive: [location] — owner: [x]
```

### Failure Modes
- Checklist compliance without currency: all five docs "exist", none updated since three model changes ago → the currency check outranks the existence check
- Conditional 4 skipped silently: "not applicable" with no reason → every skipped conditional needs a one-line justification on the record
- Anti-PRD misread as anti-documentation: dropping the PRD without adopting living replacements leaves a vacuum → name which artifact now carries each former PRD responsibility

### Evidence Strength
Practitioner consensus — a process standard encoding widely shared AI-delivery lessons (model behavior shifts make static specs stale); effectiveness depends on enforcement cadence and tooling, and there is no comparative evidence that Core 5 specifically beats other minimal sets.

### Source
AI delivery standards; shipping quality frameworks.

## Intended vs Implemented
> source: intended-vs-implemented.md
### Core Concept
A framework for detecting drift between documented intent and cited code implementation. Tracks bidirectional references: does the design doc reference the right code? Does the code cite the right design doc? Identifies boundary mismatches where scope has shifted.

### Applicable Scenarios
- Detecting doc-code drift in AI-era projects
- Ensuring design documents stay aligned with implementation
- Auditing specification coverage

⚠️ **When NOT to use**
- Documentation debt is total (no docs to compare against) — fix documentation first; there is nothing to align
- A one-shot review before merge — a checklist catches the same drift cheaper
- Regenerated/AI-written code without stable references — citation links churn every generation and produce false drift

### Key Steps
1. Extract documented intents from design docs (features, behaviors, constraints)
2. Map each intent to its corresponding code implementation (cited code)
3. Check bidirectional references: does code reference back to the intent?
4. Identify boundary mismatches: scope changes, missing implementations, orphaned docs
5. Create a drift report with severity and recommended actions

### Output Template

```
Scope: [design docs] × [code area] — audited [date]

| Intent (doc §ref)        | Implementation (path) | Forward link | Back link | Drift type        | Severity |
| ------------------------ | --------------------- | ------------ | --------- | ----------------- | -------- |
| [rate limit 100/min]     | [src/middleware/rl.go]| ✓            | ✗         | undocumented change (now 200) | High |
| [retry with backoff]     | —                     | —            | —         | unimplemented     | High     |
| —                        | [src/cache/etag.go]   | —            | ✗         | orphaned code     | Medium   |

Drift summary: [n mismatches / n intents, worst boundary: auth scope]
Actions: [update doc / file ticket / flag orphan] — owner [x] by [date]
```

### Failure Modes
- Snapshot audits that rot immediately: drift resumes the day after the report → make bidirectional citation a template habit (doc PRs cite code, code PRs cite docs), not a periodic audit
- Severity by feeling: everything marked Medium → tie severity to user impact or contract breakage, and force a top-3 ordering
- Treating doc as truth by default: sometimes the code is right and the doc is stale → each drift row must decide which side is authoritative before assigning action

### Evidence Strength
Practitioner consensus — drift between docs and code is a well-observed failure mode and citation hygiene is a reasonable control; no controlled studies quantify drift reduction from bidirectional referencing, and tooling support (doc-to-code link checkers) determines how much of it is enforceable vs manual.

### Source
AI delivery best practices; doc-code alignment frameworks.

## LLM Output Evaluation
> source: llm-output-evals.md (original title: LLM Output Evaluation (Evals))
### Core Concept
A prompt or model change is a change to a stochastic system, and the only way to know whether it improved is a **fixed evaluation set scored identically before and after**. The mechanism has four parts: a golden set (curated input → expected-behavior pairs), scorers (deterministic checks first, LLM-as-a-judge with bias controls where judgment is needed), failure-first error analysis (read what broke before admiring the score), and a regression gate (a change that loses on the fixed set does not ship). It converts "the new prompt feels better" into a decidable comparison.

### Applicable Scenarios
✅ **Best for**
- Deciding whether a prompt, model, or retrieval-parameter change ships
- Building a regression gate so AI features stop silently degrading
- Comparing model vendors on your task (not on a leaderboard)
- Turning production failures into permanent test cases

⚠️ **When NOT to use**
- One-off generation read once by a human — just read it; an eval set for output nobody will compare is ceremony
- No fixed task definition yet — build the task and its output contract first; evals measure a defined job, not a vibe
- Product-level "did the feature move business metrics" → **A/B Test Analysis** (human users, online traffic)
- "Is this code secure / does this pass lint" → static analysis (**Security by Design**); evals judge model output quality, not code properties
- Sub-agent workflow scripts in ZCode → dynamic-workflows owns that authoring surface

### Key Steps
1. Define the task and output contract: what a good output must contain, forbid, and reference — if you cannot state it, you cannot score it
2. Build the golden set: 20-50 real cases spanning the happy path, known hard cases, adversarial inputs, and past production failures — composition matters more than size
3. Choose scorers in order: deterministic assertions (schema, exact substring, refusal check) → LLM-as-a-judge with a written rubric for the rest
4. Control judge bias: randomize answer order (position bias), pin output length or report it (verbosity bias), and use a judge model different from the tested one (self-preference)
5. Run baseline and candidate on the identical set, same temperature, same scorers — any difference outside the set invalidates the comparison
6. Do failure-first error analysis: read the losing cases before the aggregate score; the score says "worse", the failures say "what to fix"
7. Gate: block ship on regression of a fixed-set criterion; record the verdict with the score delta and the failing cases
8. Grow the set: every production failure becomes a golden-set case — the eval grows where the product actually breaks

### Output Template

```
Eval report — task: [one sentence + output contract]
Golden set: [n] cases — composition: [happy x, hard x, adversarial x, from-prod x]
Scorers: [deterministic: ... | judge: model X, rubric summary, bias controls applied]
Baseline: [score / case]   Candidate: [score / case]   Δ [±x]
Failure analysis: [case → what broke → suspected cause] (top 3)
Verdict: [ship | hold] — gate criterion [met | regressed on: ...]
Set updates: [production failures added as cases]
```

### Failure Modes
- Judging with the generator: the model grading its own output prefers it → use a different judge model, and spot-check judge verdicts against human labels
- Vibes-based comparison: two prompts tried on three ad-hoc inputs and a winner declared → no fixed set, no comparison; build the set before tuning anything
- Happy-path-only golden set: regressions live in the weird cases → the set must contain the adversarial and the previously-broken
- Score without error analysis: an aggregate number cannot tell you what to change → failures first, score second
- Set too small: n < ~20 makes every delta noise → 20-50 well-chosen cases beat 500 sloppy ones
- Contamination: eval cases leaked into the prompt (few-shot examples copied from the set) → the eval then measures memorization; keep the set out of all prompts
- Ignoring cost and latency: a 5% quality gain at 10× token cost is a loss → record tokens and latency per run alongside quality
- Frozen eval: the set never grows after launch → production failures are the highest-value cases; wire them in

### Evidence Strength
**Strong mechanism, crafted instrument.** Regression testing is standard engineering, and LLM-as-a-judge agreement with human preferences is documented (MT-Bench, Zheng et al. 2023) — but judge biases (position, verbosity, self-preference) are real and must be actively controlled, and eval-set design remains craft: a bad set certifies nothing. Treat judge scores as a relative signal between two runs on one set, not an absolute quality number.

### Source
Zheng et al., "Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena" (NeurIPS 2023); Liu et al., "G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment" (EMNLP 2023); Hamel Husain, "Your AI Product Needs Evals" (2024). Admission verdict: **Build** (v0.1.16) — ranked first by the independent necessity audit: highest frequency, zero sibling collision (diting reviews agent code, tiangang scans security; neither judges model output), and `shipping-artifacts.md`'s currency check ("documents older than the last model/prompt change → block ship") implies an eval gate this entry now owns. The stable residue of prompt/context design (its one durable rule: gate every prompt change on a fixed eval set) is folded in here; the unstable remainder is deferred.

## Category Guide
## AI Delivery

**When to use**: AI-era shipping artifacts standards, doc-code drift detection


### Minimum Information Requirements per Methodology

- **Shipping Artifacts**: Requires project scope + documentation version management
- **Intended vs Implemented**: Requires Design Doc + code reference relationships
- **LLM Output Evaluation**: Requires a defined task + output contract + a golden set of 20-50 real cases (composition over size)

### Routing Trigger Signals

- "AI project delivery standards" → Shipping Artifacts (primary)
- "Doc-code drift detection" → Intended vs Implemented (primary)
- "Did my prompt change make it better / compare two models on my task / stop AI regressions / build an eval set / LLM-as-a-judge" → LLM Output Evaluation (primary) ⚡ If measuring business metrics with real users → use A/B Test Analysis (Data Analysis); if reviewing the agent's code → diting; if the output is code and the question is security → use Security by Design (Engineering)

### Common Combinations

- **AI project delivery**: Shipping Artifacts (define the artifact set) → Intended vs Implemented (keep docs and cited code aligned as the project evolves)
- **Prompt/model change lifecycle**: LLM Output Evaluation (fixed-set gate before shipping) → Intended vs Implemented (update the docs the change invalidates)
