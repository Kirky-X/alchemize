# Quantitative Investment (compact aggregate)
> Aggregated from `references/quantitative-investment/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh quantitative-investment "<methodology>"`

## Factor Investing
> source: factor-investing.md
### Core Concept
Systematically capture risk premiums using multi-factor models (Fama-French etc.). Factors include Value, Momentum, Size, Quality, Low Volatility. Evaluate factors using IC, IC_IR, and group return monotonicity.

### Applicable Scenarios
✅ **Best for**
- Factor stock selection
- Portfolio construction
- Attribution analysis

⚠️ **When NOT to use**
- Sizing on raw historical premia — factor returns shrink after publication as capital crowds in; in-sample estimates overstate what remains, so haircut them or treat factors as risk exposures, not guaranteed alpha
- Single-company questions — factor models rank stocks across a universe; for one company's profitability or valuation use **DuPont Analysis**, **DCF**, or **Comparable Company**
- Thin or costly universes — small expected spreads are consumed by turnover and shorting costs; test net of costs or the "premium" is a cost machine
- Short holding horizons — factor premia arrive unevenly and multi-year drawdowns are normal; users who cannot sit through that will capitulate at the worst time

### Key Steps
1. Select factors based on theory and empirical evidence
2. Calculate factor exposures for each asset
3. Evaluate factor performance: IC (Information Coefficient), IC_IR (IC Information Ratio)
4. Test monotonicity: do 5-group returns increase/decrease monotonically?
5. Combine factors into multi-factor model
6. Construct portfolio based on factor scores

### Output Template

```
Universe: [index, point-in-time membership] — period: [x to x]
Factor definitions: [how value / momentum / quality / size / low-vol are computed, data source]

Per-factor evaluation:
  [Value]: IC [x], IC_IR [x], top-minus-bottom annual [x%], 5-group monotonic? [yes/no]
  [Momentum]: IC [x], IC_IR [x], top-minus-bottom annual [x%], 5-group monotonic? [yes/no]
Net-of-cost long-short: [x%] annualized, after turnover [x] × cost [x bps]
Multi-factor: weights [..] — factor correlation matrix [..] — combined IC_IR [x]
Portfolio: top-quintile [weights], turnover [x], expected tracking error [x]
Caveat: [which factors look crowded or decayed; minimum holding discipline]
```

### Failure Modes
- Data mining: test enough factors and some "work" by chance → demand an economic rationale before any test, and count the trials run
- Non-point-in-time data: restated fundamentals or today's constituents leak the future → use as-reported data and delisting-inclusive universes
- Gross-of-cost evaluation: high-turnover signals die after costs → report IC and long-short spreads net of realistic costs
- Crowding risk: everyone holds the same factors and unwinds are correlated (momentum-crash style) → monitor factor valuation spreads and size modestly

### Evidence Strength
Contested — factor premia were strong in the samples that discovered them, but post-publication decay, multiple-testing concerns, and crowding are documented in general terms, so today's net premia are smaller and less certain than the classic estimates; the strongest defensible use is as a risk-exposure and diversification lens, with any alpha claim sized conservatively.

### Source
Eugene Fama & Kenneth French, Fama-French 3-factor model (1992); factor investing literature.

## Portfolio Optimization
> source: portfolio-optimization.md
### Core Concept
Markowitz mean-variance optimization + Black-Litterman Bayesian equilibrium. Find the optimal weight allocation that maximizes expected return for a given risk level (or minimizes risk for a given return).

### Applicable Scenarios
✅ **Best for**
- Optimal weight allocation
- Risk-return tradeoff
- Asset allocation

⚠️ **When NOT to use**
- Expected returns are guesses — MVO amplifies input error (it loads hardest on whatever was over-estimated); with unreliable inputs the "optimal" weights are confident nonsense, and **Risk Parity** or simple vol targeting is the honest choice
- Few assets, modest goals — with 3-5 assets, equal weight or vol targeting matches MVO out of sample; the optimization machinery adds fragility, not return
- Short histories relative to asset count — covariance estimation error explodes when N approaches T; without shrinkage or a factor model the matrix is noise
- Fat-tailed, skewed assets — variance understates tail risk; mean-variance is blind to how drawdowns actually arrive

### Key Steps
1. Estimate expected returns and covariance matrix
2. Define constraints (no short-selling, max weight, sector limits)
3. Run mean-variance optimization (MVO)
4. For MVO sensitivity, apply Black-Litterman: combine market equilibrium with investor views
5. Validate: check concentration, turnover, and out-of-sample performance
6. Rebalance periodically

### Output Template

```
Assets: [list] — estimation: [window, frequency], covariance: [sample / shrinkage / factor]
Expected returns: [equilibrium-implied / forecast / historical] — source of view: [x]
Constraints: [no shorts, max weight x%, sector caps, turnover limit]

MVO output: weights [..] — expected return [x%], vol [x%]
Black-Litterman: views [asset: x% ± confidence] → posterior weights [..]
Sensitivity: perturb expected returns ±[1pp] → weight swings [..] (large swings = input problem, not optimization)
Validation: OOS Sharpe [x] vs equal-weight [x] — concentration [HHI] — turnover [x%]
Rebalance: [quarterly / drift bands of x%]
```

### Failure Modes
- Error maximization: MVO concentrates on assets with over-estimated returns and under-estimated risk → constrain weights, prefer Black-Litterman or resampled inputs, and always report weight sensitivity to input perturbation
- Corner solutions: unconstrained MVO emits extreme long-short weights → impose sensible constraints (max weight, no leverage) before optimizing
- Covariance instability: sample covariance is noisy when assets outnumber observations → use shrinkage estimators or a factor covariance model
- False precision: point inputs imply a single-point answer → run sensitivity bands; if the allocation ranking flips within plausible inputs, the honest output is "indifferent"
- Static weights in a drifting world: vols and correlations move → rebalance on drift bands, not set-and-forget

### Evidence Strength
Mixed — the optimization math is exact and the framework is foundational, but MVO's out-of-sample advantage over naive equal weights is notoriously weak because it amplifies input error; Black-Litterman and constraints mitigate rather than solve this, so treat the output as a structured starting point for judgment, not the answer.

### Source
Harry Markowitz, *Portfolio Selection* (1952); Black & Litterman (1992).

## Risk Parity
> source: risk-parity.md
### Core Concept
Allocate weights so each asset/strategy contributes equally to total portfolio risk, rather than equal capital. Results in more diversified risk exposure and better risk-adjusted returns.

### Applicable Scenarios
✅ **Best for**
- Risk budgeting
- Asset allocation
- Reducing concentration risk

⚠️ **When NOT to use**
- Unreliable covariance estimates (short histories, regime breaks) — the weights are only as good as the matrix; garbage covariances give confident-looking garbage
- Leveraged implementation without funding-cost awareness — risk parity often levers low-risk assets; the strategy's returns then hinge on borrow costs, not just allocations
- Very few assets (2-3) — the parity machinery degenerates; simple volatility targeting is equivalent and clearer

### Key Steps
1. Define asset classes/strategies
2. Calculate covariance matrix
3. Iteratively solve for risk parity weights (each asset's marginal risk contribution is equal)
4. Decompose total risk: verify equal risk contribution
5. Rebalance periodically as correlations change

### Output Template

```
Assets: [equities, duration bonds, commodities, credit]
Estimation window: [10y monthly] — covariance method: [sample/shrinkage]

Risk parity weights (solved): [equities 22% / bonds 50% / commodities 18% / credit 10%]
Risk contribution check: [25% / 25% / 25% / 25%] — total vol: [x%]
  (weights are NOT equal — capital tilts toward low-vol assets)

Leverage note: [amount, funding cost assumption, margin/liquidity stress]
Rebalance: [quarterly / on 20% contribution drift] — turnover estimate: [x%]
Stress check: [correlations → 1 shock: portfolio vol becomes y% — what's the plan?]
```

### Failure Modes
- Estimation-error blindness: covariance matrices from short windows flip weights at each re-estimation → use shrinkage/robust estimators and report weight sensitivity to the estimation window
- Leverage hidden in "low risk": the balanced-risk portfolio is levered; 2008-style deleveraging hits funding, not just assets → stress the funding channel explicitly before implementing
- Rebalance-by-calendar only: correlations drift within quarters — risk contributions already unequal → add contribution-drift bands alongside the calendar

### Evidence Strength
Mixed — the equal-risk-contribution math is exact, and the diversification motive is sound; empirical claims of superior risk-adjusted returns vs simple 60/40 depend heavily on sample period and leverage costs (strong in bond-bull decades, weaker elsewhere). Treat as a principled allocation framework, not a proven alpha source.

### Source
Edward Qian et al., Bridgewater's "All Weather" concept; risk parity literature.

## Momentum Strategy
> source: momentum-strategy.md
### Core Concept
Exploit the tendency of asset prices to continue trending. Buy past winners, sell past losers. Evaluate using multi-period returns, cross-sectional ranking, group returns, and rolling momentum.

### Applicable Scenarios
✅ **Best for**
- Trend following
- Market timing
- Rotation strategies

⚠️ **When NOT to use**
- Post-crash rebound regimes — momentum crashes are documented: past losers rip hardest in recoveries and the long-momentum book is on the wrong side; if you cannot size for that tail, step aside
- High-cost or illiquid universes — monthly rebalancing turnover burns a modest premium; test net of costs or the strategy is a cost machine
- Very short lookbacks — below roughly one month the documented effect reverses (short-term reversal); applying "momentum" there trades against the evidence
- Sideways, mean-reverting assets — trend following whipsaws in ranges; for uncertain directional calls, size exposure with **Probabilistic Reasoning** instead of extrapolating the trend

### Key Steps
1. Define lookback period (e.g. 12-1 month) and holding period
2. Calculate returns for each asset over the lookback
3. Rank assets cross-sectionally by past returns
4. Go long top decile, short bottom decile (or long-only top group)
5. Calculate group returns and test for statistical significance
6. Monitor rolling momentum; watch for momentum crashes

### Output Template

```
Universe: [assets] — lookback: [12-1m], skip: [1m], rebalance: [monthly]
Ranking: cross-sectional past return — long top [decile], short bottom [decile]

Group returns: quintile means [monotonic? yes/no] — long-short t-stat [x]
Net performance [period]: annualized [x%] — Sharpe [x] — Max DD [x%] — turnover [x]
Crash check: worst month [x%] — performance in down markets [x]
Current state: momentum percentile of held assets [..] — regime note: [rebound / chop / trend?]
Caveat: [what would make you exit — crash-filter trigger, threshold]
```

### Failure Modes
- Crash exposure: long-momentum implicitly shorts the best rebounders and crashes cluster right after bear markets → add a trend or volatility filter on the strategy itself, not just the assets
- Cost and turnover omission: small premia times monthly rebalancing → quote every result net of realistic costs
- Lookback data mining: the best in-sample lookback is overfit → test a neighborhood of lookbacks and report the sensitivity
- Skip-month omission: including the most recent month imports short-term reversal and distorts the signal → keep the standard skip unless your data says otherwise
- Cross-asset overgeneralization: momentum's strength differs by asset class and era → re-estimate per universe before sizing

### Evidence Strength
Mixed — momentum is one of the most replicated return patterns across asset classes and decades, so the effect itself is well evidenced; but the premium is modest, crash risk is real and concentrated in rebounds, and post-publication decay is documented in general terms — treat it as a risk premium paid for enduring crashes, not free money.

### Source
Jegadeesh & Titman (1993); momentum factor research.

## Statistical Arbitrage
> source: statistical-arbitrage.md
### Core Concept
Mean-reversion trading based on statistical relationships between assets. Pairs trading (2 assets) or basket trading (multiple assets). Uses cointegration tests to identify stable relationships.

### Applicable Scenarios
✅ **Best for**
- Market-neutral strategies
- Pairs trading
- Cointegration-based trading

⚠️ **When NOT to use**
- Pairs found by scanning, not economics — cointegration discovered by testing thousands of candidate pairs is mostly coincidence (multiple testing); demand a one-sentence economic reason the spread must revert
- Structural-change environments — mergers, regulation, or business-model shifts permanently break relationships; a passed test says nothing about tomorrow
- Thin spreads with heavy turnover — entries and exits are frequent; borrow costs, dividends, and slippage can consume the entire edge; net-of-cost test or skip
- Risk-averse capital seeking "market-neutral" safety — neutrality is statistical, not absolute; spreads blow up and both legs lose together, so size the worst case with **Probabilistic Reasoning**

### Key Steps
1. Identify candidate pairs/baskets with economic relationship
2. Test for cointegration (Engle-Granger or Johansen test)
3. Model the spread: z-score = (spread - mean) / std
4. Define entry/exit rules: enter when z > threshold, exit when z reverts
5. Backtest: check Sharpe ratio, maximum drawdown, turnover
6. Monitor: cointegration can break down; set stop-losses

### Output Template

```
Pair/basket: [A, B] — economic link: [one sentence on why the spread must mean-revert]
Cointegration: [Engle-Granger / Johansen, p-value, test period] — half-life: [x days]
Spread model: z = (spread − mean) / std — current z: [x]
Entry: [|z| > x] — exit: [z → 0] — stop: [|z| > x or structural event]
Backtest net of costs: Sharpe [x] — Max DD [x%] — trades [n] — avg holding [x days]
Borrow/funding: [available? cost bps] — dividends treatment: [x]
Breakdown plan: [stop-loss, max holding period, monitoring trigger]
Caveat: [what regime change would kill this pair]
```

### Failure Modes
- Data-mined pairs: scanning thousands of candidates finds fake cointegration → select the pair on economic grounds first, then test, and disclose the search
- Regime change: cointegration is an in-sample property and breaks without warning → live monitoring, hard stop-loss, exit on structural events
- Cost omission: small spreads, high turnover, borrow costs → only net-of-cost Sharpe counts
- Tail blindness: spreads can diverge far beyond historical std before reverting, or never → size for spread blowup, not for the historical distribution
- Factor overlap across the book: many "neutral" pairs share common exposures and the aggregate book carries concentrated factor bets → check factor exposures of the whole portfolio; pair-by-pair neutrality is not enough

### Evidence Strength
Mixed — the statistical machinery (cointegration testing, spread z-scores) is sound and the methodology is well established among practitioners, but documented profitability is era- and market-dependent, decays with crowding, and lives or dies on cost discipline; any specific pair's historical Sharpe should be treated as fragile evidence.

### Source
Statistical arbitrage literature; pairs trading methodology.

## Backtesting Framework
> source: backtesting-framework.md
### Core Concept
Systematic backtesting pipeline: Data → Signal → Execution → Evaluation. Key metrics: Sharpe Ratio, Sortino Ratio, Calmar Ratio, Maximum Drawdown, VaR, Win Rate, Distribution analysis.

### Applicable Scenarios
✅ **Best for**
- Strategy validation
- Parameter optimization
- Overfitting detection

⚠️ **When NOT to use**
- Fewer than ~30 historical trades — no statistical power; the Sharpe ratio is noise and any "edge" is indistinguishable from luck
- Survivorship-biased data — a universe built from today's constituents silently inflates every result; delisted failures must be in the sample or the backtest is fiction (audit the data with **Cognitive & Statistical Bias Checklist**)
- In-sample parameter sweeps presented as validation — optimizing on the full history is curve-fitting, not testing; if you cannot hold out data, say so instead of quoting the in-sample Sharpe
- One-off, non-repeatable decisions — backtesting validates rule-based strategies only; for single uncertain calls use **Probabilistic Reasoning** or **Decision Tree & Expected Value**

### Key Steps
1. **Data**: clean historical data (survivorship-bias-free, point-in-time)
2. **Signal**: define strategy rules; generate trading signals
3. **Execution**: simulate realistic execution (transaction costs, slippage, market impact)
4. **Evaluation**: calculate performance metrics (Sharpe, Sortino, Calmar, Max DD, VaR, Win Rate)
5. **Robustness**: out-of-sample testing, walk-forward analysis, parameter sensitivity
6. **Overfitting check**: if results look too good, they probably are

### Output Template

```
Strategy: [rules, universe, rebalance frequency] — decision price: [close / next open]
Data: [source, period, point-in-time? delistings included?]
Costs modeled: [commission bps] + [slippage bps] + [impact model?]

In-sample [period]: Sharpe [x] — Max DD [x%] — Win rate [x%] — trades [n]
Out-of-sample [period]: Sharpe [x] — Max DD [x%] — trades [n]
Walk-forward: parameters [stable / drifting across folds]

Robustness: perturb each parameter ±[20%] → Sharpe range [x to y]
Too-good check: [Sharpe > 2 on liquid instruments → hunt for the bug first]
Verdict: [deploy / paper trade / discard] — reason: [the evidence cited]
```

### Failure Modes
- Lookahead bias: the signal uses data not available at decision time (restated financials, same-bar fills) → time-stamp every input; execute on the bar after the signal
- Survivorship bias: the universe excludes dead assets → rebuild point-in-time membership including delistings before trusting any metric
- Cost omission: gross Sharpe evaporates after commissions, slippage, and impact, especially at high turnover → model costs before evaluating results
- Multiple-testing overfitting: the best of many tried configurations wins by chance → count the trials, penalize the search, hold out data it never touched
- Too-good-to-be-true acceptance: exceptional results read as skill → treat a spectacular backtest as a bug report first; a green backtest still needs **Pre-mortem & Counterfactual** and paper trading before capital

### Evidence Strength
Practitioner consensus — the pipeline itself (point-in-time data, realistic costs, out-of-sample and walk-forward validation) is the standard discipline of systematic trading, with wide agreement on the major biases; the caveat cuts the other way: the headline metrics of any single backtest are weak evidence, because overfitting and cost underestimation reliably shrink live performance.

### Source
Systematic trading methodology; Robert Pardo, *The Evaluation and Optimization of Trading Strategies*.

## ML Stock Selection
> source: ml-stock-selection.md
### Core Concept
Use machine learning models to predict returns or classify up/down for stock selection. Features from fundamental, technical, and alternative data. Handles nonlinear factor combinations.

### Applicable Scenarios
✅ **Best for**
- Factor nonlinear combination
- High-dimensional feature stock selection
- Alpha signal discovery

⚠️ **When NOT to use**
- Small or short datasets — markets offer few independent regimes; complex models memorize noise and in-sample accuracy means nothing; start from the interpretable baseline in **Factor Investing** before reaching for ML
- No retraining and monitoring infrastructure — relationships drift (concept decay); a deployed model degrades silently while its predictions stay confident
- Non-reproducible features — if features cannot be recomputed point-in-time (restated fundamentals, revised alt-data), every backtest is lookahead-biased no matter how careful the validation
- Explaining a single pick — ML ranks, it does not explain; for why-this-company questions use **DuPont Analysis** or **DCF**

### Key Steps
1. **Feature Engineering**: build features from fundamental (DuPont ratios, etc.), technical (momentum, volatility), and alternative data
2. **Label Definition**: define prediction target (forward return, up/down classification)
3. **Model Selection**: try multiple models (Linear, Tree-based, Neural Network)
4. **Training**: cross-validation, avoid look-ahead bias, use rolling windows
5. **Evaluation**: IC, rank IC, long-short portfolio performance, turnover
6. **Deployment**: ensemble models, monitor for concept drift

### Output Template

```
Task: predict [forward x-month return / up-down] on [universe] — label: [exact definition]
Features: [n] from [fundamental / technical / alt-data] — point-in-time verified: [yes/no]

Validation: purged, embargoed rolling CV — train [period], test [period], folds [k]
Models tried: [linear / GBDT / NN] — chosen: [x] — in-sample vs OOS gap: [metric]
OOS metrics: Rank IC [x], IC_IR [x], top-decile spread [x%], turnover [x]
Net of costs: [x%] annualized — capacity estimate: [x]
Drift monitor: rolling IC decay trigger [threshold] → retrain or retire
Caveat: [regimes the training window never saw]
```

### Failure Modes
- Lookahead bias: features built from restated data, or labels overlapping training windows → point-in-time features plus purged/embargoed cross-validation
- Search-count overfitting: many model and feature combinations, best OOS result picked → lock the model before the test window and penalize the number of trials
- Concept drift: regime change invalidates learned patterns → rolling retraining, live IC monitoring, and a kill-switch on decay
- Cost blindness: high-turnover signals die after transaction costs → evaluate long-short spreads net of costs and capacity
- Over-trusted feature importance: correlated features split importance and narratives shift across seeds → check stability across seeds and models before believing any story

### Evidence Strength
Mixed — large-sample research shows ML genuinely captures nonlinear structure in returns, but the exploitable edge is thin, decays, and the default failure mode is overfitting that survives standard validation; treat any out-of-sample result as fragile until it survives live deployment.

### Source
Machine learning in finance literature; Gu, Kelly & Xiu (2020).

## Category Guide
## Quantitative Investment

**When to use**: Need to make investment decisions based on data and models, build portfolios, evaluate strategy returns and risks


### Minimum Information Requirements per Methodology

- **Factor Investing**: Asset historical return data + factor exposure data + factor return data
- **Portfolio Optimization**: Asset expected returns + covariance matrix + constraints (short-selling restrictions, etc.)
- **Risk Parity**: Asset class/strategy historical return series + covariance matrix
- **Momentum Strategy**: Asset historical price series + lookback/holding period parameters
- **Statistical Arbitrage**: Pair/basket asset historical prices + cointegration test data
- **Backtesting Framework**: Strategy signal definition + historical market data + transaction cost assumptions
- **ML Stock Selection**: Feature engineering data (fundamental/technical/alternative data) + label definition (returns/up-down)

### Routing Trigger Signals

- "Factor stock selection / multi-factor model / alpha factor / factor exposure / attribution analysis" → Factor Investing (primary)
- "Optimal portfolio / asset allocation / weight optimization / efficient frontier / risk-return tradeoff" → Portfolio Optimization (primary)
- "Risk budget / risk contribution / risk equalization / all-weather / reducing concentration" → Risk Parity (primary)
- "Momentum / trend following / rotation / chase-rising-sell-falling / price trend" → Momentum Strategy (primary)
- "Pairs trading / statistical arbitrage / cointegration / mean reversion / market neutral" → Statistical Arbitrage (primary)
- "Strategy backtesting / historical validation / overfitting / Sharpe ratio / maximum drawdown" → Backtesting Framework (primary)
- "Machine learning stock selection / AI stock selection / feature engineering / prediction model / nonlinear factor" → ML Stock Selection (primary)

### Common Combinations

- **Systematic quantitative strategy**: Factor Investing (factor selection) → Portfolio Optimization (weight optimization) → Backtesting Framework (strategy validation)
- **Risk-oriented allocation**: Risk Parity (risk budget) → Momentum Strategy (tactical enhancement) → Backtesting Framework (effectiveness validation)
- **Alpha strategy development**: Statistical Arbitrage (signal generation) → Backtesting Framework (backtest validation) → ML Stock Selection (signal enhancement)
- **Fundamental quantitative**: Factor Investing (factor construction) → ML Stock Selection (nonlinear combination) → Portfolio Optimization (portfolio construction)
