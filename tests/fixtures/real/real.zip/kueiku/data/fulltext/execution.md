# Execution (compact aggregate)
> Aggregated from `references/execution/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh execution "<methodology>"`

## Outcome Roadmap
> source: outcome-roadmap.md
### Core Concept
Transform a feature-focused roadmap into an outcome-focused one using the format: Enable [segment] to [customer outcome] so that [business impact]. Shifts from "what we'll build" to "what we'll achieve."

### Applicable Scenarios
- Roadmap currently lists features/outputs instead of outcomes
- Need to align roadmap with business objectives
- Stakeholders question roadmap priorities

⚠️ **When NOT to use**
- Compliance and platform work where the deliverable is the point ("ship SOC2 evidence") — forcing outcomes produces padded language, not clarity
- Discovery-stage planning where you don't yet know which outcome is achievable — commit to a learning outcome, not a business outcome
- Pure communication theater: renaming features into outcome sentences while prioritization still happens by effort → the roadmap must re-rank or nothing changed

### Key Steps
1. Audit current roadmap items — are they outputs (features) or outcomes?
2. For each output, rewrite using: Enable [segment] to [customer outcome] so that [business impact]
3. Validate each item has a measurable business impact
4. Prioritize by business impact, not by feature effort
5. Review with stakeholders — does each item clearly connect to business value?

### Output Template

```
| Now / Next / Later | Outcome statement                                                        | Measure (business impact) | Current baseline → target | Leading indicator       |
| ------------------ | ------------------------------------------------------------------------ | ------------------------- | ------------------------- | ----------------------- |
| Now                | Enable [new teams] to [self-serve onboarding] so that [CAC drops]         | CAC                       | $420 → $350               | [activation rate]       |
| Next               | Enable [admins] to [audit access in one view] so that [enterprise deals unblock] | [deal cycle days]  | 45 → 30                   | [security review pass]  |
| Later              | Enable [mobile users] to [track orders] so that [support cost drops]      | [tickets/order]           | 0.4 → 0.2                 | —                       |

Dropped in rewrite: [feature X — no one could name its outcome] — explicit decision to defer/kill
Review rhythm: [quarterly outcome review — did shipped work move the measure?]
```

### Failure Modes
- Outcome cosplay: "ship dark mode" becomes "enable users to delight in personalization" — a feature in a costume → the business-impact clause must name a metric someone owns
- Unowned measures: outcome stated, no baseline, no target, no owner → every row carries baseline → target and an accountable name
- Later-land purgatory: vague outcomes parked in Later forever — fine, but say why (uncertain impact vs dependent on Now items)

### Evidence Strength
Practitioner consensus — consistent with outcome-driven product practice (OKR lineage); adopters report better prioritization conversations, but there is no controlled evidence outcome-framed roadmaps outperform output roadmaps on delivery efficiency — the claimed gains are in focus and stakeholder alignment.

### Source
Joshua Seiden & Jeff Patton; popularized in outcome-driven product management.

## Strategy Red Team
> source: strategy-red-team.md
### Core Concept
Stress-test a strategy by steelmanning it (strongest possible version), then attacking it from multiple angles, ranking attacks by impact × likelihood × cheapness of mitigation.

### Applicable Scenarios
- Before finalizing a major strategic decision
- When the team is too close to the plan to see its weaknesses
- Board/investor preparation

⚠️ **When NOT to use**
- The decision is small and reversible — run the experiment instead of the red team
- Without decision authority in the room — findings that can't change the plan are ceremony
- As retroactive justification: red-teaming a strategy already announced and resourced produces diluted attacks — hold it before commitment

### Key Steps
1. Steelman the strategy: articulate the strongest possible version
2. Attack from multiple angles: market, competitive, execution, financial, organizational
3. For each attack, estimate: Impact (if it hits) × Likelihood (probability) × Cheapness (cost to mitigate)
4. Rank attacks by the composite score
5. Address top-ranked attacks in the strategy; document accepted risks

### Output Template

```
Strategy under review: [one paragraph] — steelman: [strongest version, stated by a believer]

| # | Angle       | Attack (how this fails)                     | Impact 1-5 | Likelihood 1-5 | Mitigation cheapness 1-5 | Score | Action            |
| --- | --------- | ------------------------------------------- | ---------- | -------------- | ------------------------ | ----- | ----------------- |
| 1 | Competitive | [incumbent bundles our core feature free]   | 5          | 3              | 1 (can't match burn)     | 15    | [preempt via ...] |
| 2 | Execution   | [key-person dependency in data pipeline]    | 4          | 4              | 4 (document + hire)      | 12*   | [do first — cheap]|
| 3 | Market      | [...]                                       | ...        | ...            | ...                      | ...   | ...               |

Accepted risks (documented, with owner): [attack + why we absorb it]
Changes made to the strategy as a result: [list] — if the list is empty, the exercise was decorative
```

### Failure Modes
- Polite red team: insiders attack their own plan in front of its author — attacks arrive pre-weakened → assign attack ownership to people with no stake in the plan, or use the pre-mortem "failure already happened" framing
- Score soup: precise-looking composite scores from hand-waved inputs → show the ranges; a 15 vs 12 gap within estimation error should not decide priority (cheap mitigations may break ties)
- Attack backlog instead of decisions: every top attack spawns "further study" → each top-3 attack ends in a strategy change, a mitigation with owner, or a documented accepted risk

### Evidence Strength
Practitioner consensus — red-teaming and pre-mortems are widely adopted and the mechanism (prospective hindsight surfaces risks optimism hides) has experimental support in the judgment-and-decision-making literature; the specific impact × likelihood × cheapness scoring is a practical heuristic, not a validated instrument.

### Source
Adapted from military red teaming and Daniel Kahneman's pre-mortem technique.

## User Stories
> source: user-stories.md
### Core Concept
Agile requirements in the format: As a [role], I want [goal], so that [benefit]. Governed by the 3 C's (Card/Conversation/Confirmation) and INVEST criteria (Independent, Negotiable, Valuable, Estimable, Small, Testable).

### Applicable Scenarios
- Agile backlog management
- Cross-functional team communication about requirements
- Iterative development planning

⚠️ **When NOT to use**
- The benefit differs from the goal in no meaningful way ("so that I can log in") — the third clause is decoration; write a plain requirement
- Precise contractual specifications (integrations, compliance) — stories negotiate; contracts specify
- Situations matter more than roles — Job Stories carry context better; personas here would be invented

### Key Steps
1. Write the story: As a [role], I want [goal], so that [benefit]
2. Card: keep the written description brief — it's a placeholder for conversation
3. Conversation: discuss the story with the team to flesh out details
4. Confirmation: define acceptance criteria (testable conditions of satisfaction)
5. Validate against INVEST: Independent, Negotiable, Valuable, Estimable, Small, Testable

### Output Template

```
Story: As a [support agent], I want [to bulk-reassign tickets], so that [reassignments don't eat my morning]

Acceptance criteria (Confirmation):
  Given [50 open tickets filtered by tag], when [I select all + reassign], then [all move in one action and audit log records it]
  Given [ticket in status Closed], when [bulk reassign includes it], then [it is skipped and reported]
  Edge: [0 tickets selected] → [button disabled]

INVEST check: Independent [n/a deps?] Negotiable [open on how] Valuable [why] Estimable [team confirms] Small [fits a sprint?] Testable [criteria above]

Split if too big: [vertical slice 1: single reassign; slice 2: bulk] — never split by architecture layer
Conversation notes: [decisions from discussion, dated]
```

### Failure Modes
- Role inflation: "As a user" — a role with no perspective → name the specific role with the specific need, or switch to a job story
- Story as spec: acceptance criteria grow into a requirements document taped to a story format → keep the card thin; move detail to tests or the conversation notes
- INVEST as trivia: criteria recited but "Small" never enforced and "Independent" never examined → run the check at refinement, and split on INVEST failures before estimation

### Evidence Strength
Practitioner consensus — the de facto standard for backlog expression in agile teams; evidence for specific format benefits (stories vs task lists) is anecdotal, and the known failure mode is cargo-cult formatting without the conversation the 3 C's actually govern.

### Source
Mike Cohn, *User Stories Applied* (2004); Ron Jeffries' 3 C's (2001).

## Job Stories
> source: job-stories.md
### Core Concept
Contextualized requirements in the format: When [situation], I want [motivation], so I can [outcome]. Unlike User Stories (which center on persona), Job Stories center on the situation/context, avoiding persona bias and focusing on the causal chain.

### Applicable Scenarios
- Requirements where context matters more than who the user is
- Avoiding persona bias in feature design
- Cross-functional teams needing a shared requirement format

⚠️ **When NOT to use**
- The situation genuinely differs by role (admin vs member see different screens) — persona-bearing User Stories are more honest here
- Regulatory or contract-driven requirements with fixed inputs/outputs — write the spec; a job story adds nothing
- You have no evidence any such situation occurs — invented situations produce invented features; validate with JTBD interviews first

### Key Steps
1. Identify the situation/context: "When [specific situation triggers the need]"
2. Define the motivation: "I want [what the user wants to do in that situation]"
3. Define the expected outcome: "so I can [what outcome they achieve]"
4. Validate: does the job story capture context + motivation + outcome without referencing a specific persona?
5. Use as input for design and development, ensuring the situation drives the solution

### Output Template

```
When    [I'm commuting with one hand free and 10 minutes]
I want  [to catch up on only the threads where I was mentioned]
so I can [arrive informed without scrolling for an hour]

Situational forces (optional, sharpens design):
  Push:    [what makes the current state painful]
  Pull:    [what attracts about the new way]
  Anxiety: [what worries about switching]
  Habit:   [what competes with the new behavior]

Acceptance test: given [situation], when [action], then [outcome] — measurable?
```

### Failure Modes
- Situation so broad it fits everyone ("when I use the app") — no design tension survives → force a trigger with time, place, or state
- Motivation written as a solution ("I want a button that...") — the story then justifies its own conclusion → write what the user wants to accomplish, not how
- Outcome unverifiable: "so I can feel confident" — nothing to test → pick an observable or drop it

### Evidence Strength
Practitioner consensus — an application of the Jobs-to-be-Done tradition; teams report fewer persona debates and better context retention, but there is no controlled comparison of job stories vs user stories on requirement quality — the format's value is in forcing context specificity.

### Source
Alan Klement, *When Coffee and Kale Compete* (2016); inspired by Clayton Christensen's JTBD theory.

## Critical Path Method
> source: critical-path.md
### Core Concept
A plan's minimum duration equals its longest dependency chain, not its total work. Decompose into tasks with durations and dependencies, compute each task's float (slack), and the zero-float chain is the critical path: delay there moves the end date, delay elsewhere does not. Management effort follows the math — protect, monitor, and compress the path; flex everything else.

### Applicable Scenarios
✅ **Best for**
- Projects with a hard deadline and many dependent tasks
- Deciding which slip actually endangers the date (and which doesn't)
- Choosing where adding resources (crashing) or overlapping phases (fast-tracking) buys real time

⚠️ **When NOT to use**
- Discovery/agent work where tasks emerge step by step → Bite-Sized Plan (Engineering) — you cannot chain durations you cannot see yet
- Single-person task juggling without dependencies → Eisenhower Matrix (Decision Making)
- Portfolio-level what-to-do-first prioritization → RICE (Decision Making)
- No task-level duration estimates exist — estimate first (ranges, per Probabilistic Reasoning (Decision Making)); CPM on invented single numbers is false precision

### Key Steps
1. Work breakdown to leaf tasks small enough to estimate honestly
2. Estimate durations — ranges where uncertain (PERT: weighted optimistic/likely/pessimistic)
3. Draw the dependency graph (finish-to-start default; note overrides)
4. Forward pass → earliest start/finish; backward pass → latest start/finish
5. Float = latest − earliest start; the zero-float chain is the critical path; also record near-critical chains
6. Manage the path: daily attention on path tasks, buffers behind high-variance path segments, crash/fast-track only on the path (with cost per day saved)
7. Re-run on every duration or scope change — the path migrates

### Output Template

```
Task table: [id | duration (range) | depends on]
Dependency graph: [chain notation]
Critical path: [task chain], minimum duration [n]
Float table: [task | float | near-critical?]
Crash options: [task | cost per day saved | days purchasable]
Buffers: [where placed, size rationale]
Merge-bias note: [count of near-critical chains → aggregate delay risk]
Re-plan trigger: [any path-task slip > X]
```

### Failure Modes
- Single-number estimates: CPM's exactness launders guesswork → ranges + PERT weighting, and say the confidence
- Ignoring resource contention: classic CPM assumes infinite resources → check who actually does each path task; leveled schedules may create a second, resource-driven critical chain
- Path drift: scope or durations change but the old path is still managed → re-run the passes on every change; the path migrates silently
- Crashing off-path tasks: money spent where float absorbs it → buy days only on zero-float tasks
- Near-critical blindness: a chain one day short of critical multiplies merge risk across branches → track the top near-critical chains, not just the one path

### Evidence Strength
Strong practitioner consensus — CPM/PERT have run construction, aerospace, and software programs since 1957-58 and the network math is exact; the dominant error source is estimate quality, so output reliability tracks input discipline, not the method.

### Source
Kelley & Walker (1957, CPM, DuPont/Remington Rand); PERT, US Navy Polaris program (1958); Goldratt, *Critical Chain* (1997) for the buffer variant. Admission verdict: **Build** (v0.1.12) — execution held roadmap and requirements perspectives only; dependency-chain scheduling math was absent.

## Category Guide
## Execution

**When to use**: Outcome-oriented roadmapping, strategy red teaming, agile requirements


### Minimum Information Requirements per Methodology

- **Outcome Roadmap**: Requires existing roadmap items + segment/outcome thinking
- **Strategy Red Team**: Requires strategic thesis to challenge
- **User Stories**: Requires backlog + acceptance criteria definition capability
- **Job Stories**: Requires situation/motivation/outcome scenario awareness
- **Critical Path Method**: Requires task-level duration estimates + explicit dependencies (ranges acceptable, invented single numbers not)

### Routing Trigger Signals

- "Outcome-oriented roadmap" → Outcome Roadmap (primary)
- "Strategy red team / Steelman-then-attack" → Strategy Red Team (primary)
- "Agile requirements / User Story" → User Stories (primary)
- "Contextualized requirements / Job Story" → Job Stories (primary)
- "Project timeline / which delay moves the end date / where to add resources to hit the deadline / dependency chain" → Critical Path Method (primary) ⚡ If tasks emerge step by step in agent/discovery work → use Bite-Sized Plan (Engineering); if no dependencies, just task juggling → use Eisenhower Matrix (Decision Making)

### Common Combinations

- **Strategy to backlog**: Strategy Red Team (stress-test the thesis) → Outcome Roadmap (sequence outcomes per segment) → User Stories (break outcomes into INVEST items)
- **Requirements formatting**: Job Stories (situation-first draft) → User Stories (formalize where the situation genuinely differs by role)
- **Deadline recovery**: Critical Path Method (locate the real path + float) → Strategy Red Team (challenge the scope the date serves) → crash/fast-track only on the path
