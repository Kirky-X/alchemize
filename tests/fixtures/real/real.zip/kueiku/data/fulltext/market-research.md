# Market Research (compact aggregate)
> Aggregated from `references/market-research/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh market-research "<methodology>"`

## Market Sizing
> source: market-sizing.md
### Core Concept
Calculate TAM (Total Addressable Market), SAM (Serviceable Addressable Market), SOM (Serviceable Obtainable Market) using top-down and bottom-up approaches with triangulation for validation.

### Applicable Scenarios
✅ **Best for**
- Funding decks
- New market assessment
- Strategic planning

⚠️ **When NOT to use**
- Headline arithmetic — "$X B market × 1% share" is not sizing; a top-down number only counts once bottom-up triangulation gates it
- Deciding whether to build a feature — sizing is a strategy input, not product evidence; use **Kano Model** or **JTBD** research for that
- Markets where competitive share is the real question — incumbent strength matters more than market size; reach for **Porter's Five Forces**
- Demands for false precision — a single confident number invites over-trust; present ranges with named assumptions

### Key Steps
1. Define the market boundary (what product/service in what geography?)
2. Top-down: start with industry reports, macro data; estimate TAM
3. Bottom-up: start with unit economics (customers × ARPU); build up
4. Triangulate: compare top-down and bottom-up; reconcile differences
5. Narrow TAM → SAM (your segment) → SOM (realistic capture)
6. Document assumptions and data sources

### Output Template

```
Market definition: [product/service] for [customer] in [geography]
Top-down: industry total [$] × applicable slice [%] → TAM [$]
Bottom-up: [# target customers] × [ARPU $] × [achievable penetration %] → [$]
Triangulation: top-down vs bottom-up gap = [×n] — reconciled by [which assumption moves]
SAM: [segment/geography/channel filter] → [$]
SOM: [realistic capture, 3-5 yrs, evidence] → [$]
Key assumptions: [each with source]
Sensitivity: TAM range [$low–$high] when [variable] swings ±[n%]
```

### Failure Modes
- Top-down fantasy: industry totals multiplied into a number with no causal path to your customers → gate every figure against a bottom-up build; the two must reconcile within an order of magnitude
- Boundary creep: defining the market as "everyone with a phone" → fix the boundary first (who pays, for what, where); a market without a refusal criterion is not a market
- Unrecorded assumptions: the model can't be audited or falsified → log every assumption with its source and publish a sensitivity band, not a point estimate
- TAM as the goal: SAM/SOM skipped so the headline flatters the deck → show the full TAM→SAM→SOM funnel; the obtainable number is the only decision-grade one

### Evidence Strength
Practitioner consensus — triangulating bottom-up builds against top-down anchors is the standard taught method and the only one that yields defensible numbers, but absolute precision is unattainable: market boundaries and adoption rates are estimates, and top-down inputs come from analyst reports whose definitions rarely match yours. Report ranges with assumptions, never point estimates alone.

### Source
Standard market research methodology; widely used in startup fundraising.

## Market Segmentation
> source: market-segmentation.md
### Core Concept
Divide the market into 3-5 non-overlapping segments based on behavior + JTBD + needs. Each segment should be distinct, measurable, accessible, and actionable. Done early in strategy to clarify who you serve.

### Applicable Scenarios
✅ **Best for**
- Early strategy: defining who to serve
- Resource allocation across segments
- Positioning differentiation

⚠️ **When NOT to use**
- Segmenting an installed base you can already observe — that's profiling current users; **User Segmentation** or **RFM Model** on behavior data beats survey clusters
- Variables with no link to the buying decision — demographic clusters that buy identically are fiction; start from **JTBD** and needs, let variables follow
- One-off clustering presented as durable truth — markets shift; segments are hypotheses that need re-validation
- Picking where to compete — the map says who exists, not who to serve; pair with sizing and willingness-to-pay evidence before targeting

### Key Steps
1. List potential segmentation variables (behavior, demographics, JTBD, needs)
2. Cluster customers into 3-5 segments using the variables
3. Validate: are segments non-overlapping, measurable, accessible, and sizable?
4. For each segment, define: size, growth, willingness to pay, competitive intensity
5. Prioritize segments for targeting
6. Develop segment-specific value propositions

### Output Template

```
Segment: [name]
  Definition: [cluster variables + one-line description]
  Size: [# accounts or % of market]  Growth: [trend]
  Distinct job: [what they hire the product for]
  Willingness to pay: [range]
  Accessibility: [how you reach them]
  Competitive intensity: [who else serves them]
Fit: [why the current offer wins/loses here]
Priority: [rank + evidence]
```

### Failure Modes
- Demographic clustering of a behavioral problem: segments split by age or title that buy identically → cluster on needs and behavior first; keep demographics only where they demonstrably track the decision
- Brainstormed segments dressed as research: clusters invented in a workshop → ground every segment in observed data and name the evidence per attribute
- Unactionable segments: 8 clusters with no size or reach data → apply the distinct/measurable/accessible/actionable test; merge or drop what fails
- Frozen segmentation: last year's deck still drives targeting → set a re-validation trigger (market shift, declining response rates, new entrant)

### Evidence Strength
Practitioner consensus — STP is foundational marketing doctrine and segmentation reliably improves targeting efficiency, but the validity of any given segmentation depends entirely on whether the clustering variables track the actual buying decision, and segments decay as markets shift; treat outputs as hypotheses to validate, not facts.

### Source
Philip Kotler, *Marketing Management*; standard STP framework foundation.

## User Segmentation
> source: user-segmentation.md
### Core Concept
Cluster existing users by behavior/JTBD/needs from feedback data. Unlike market segmentation (which targets potential customers), user segmentation analyzes current users to find usage pattern differences within the same customer base.

### Applicable Scenarios
✅ **Best for**
- Analyzing usage pattern differences within existing users
- Personalization strategies
- Feature prioritization per user group

⚠️ **When NOT to use**
- Targeting prospects who aren't users yet — there is no behavior to cluster; that's **Market Segmentation** territory
- A revenue-only cut — revenue bands are **RFM Model** / **Cohort Analysis** work; behavioral clusters answer "why", RFM answers "how much"
- Data-poor bases — clustering on sparse logs produces fiction; require enough behavior per user to be meaningful
- One-time analysis presented as segments — the base churns and migrates; without a refresh loop it's a snapshot

### Key Steps
1. Collect user data: behavior logs, survey responses, support tickets
2. Identify clustering variables (usage frequency, feature adoption, JTBD)
3. Cluster users into 3-5 groups
4. For each group, profile: behavior patterns, needs, satisfaction levels
5. Design targeted strategies per segment
6. Monitor segment migration over time

### Output Template

```
Segment: [name]
  Size: [# users, % of base]
  Defining behavior: [usage pattern, feature-adoption signature]
  Dominant job: [what they hire the product for]
  Health: [satisfaction score, churn risk]
  Strategy: [targeted action]
  Success metric: [how you'll know it worked]
Migration watch: [which segments flow in/out]
```

### Failure Modes
- Demographic labels on behavioral clusters: "power users are 25-34" explains nothing → cluster on behavior and **JTBD**; demographics only where they demonstrably track usage
- Statistical clusters without faces: an n=3 grouping nobody can act on → every cluster needs a human-readable profile and a testable strategy before it counts
- Static snapshots: segments defined at launch never revisited while the base migrates → re-run on a cadence and track migration, not just membership
- Single-source clustering: log-only clusters miss motivation; survey-only clusters miss behavior → triangulate behavioral data with interview evidence per segment

### Evidence Strength
Practitioner consensus — behavioral segmentation of an installed base is standard product analytics practice and measurably improves targeting and retention work; the caveats are that cluster stability depends on data volume and periodic re-runs, and formal cluster-validity checks are frequently skipped in practice, so treat segment boundaries as provisional.

### Source
Product analytics methodology; behavioral segmentation frameworks.

## User Personas
> source: user-personas.md
### Core Concept
Create 3 representative user personas, each containing: JTBD (what job they hire the product for), Top 3 Pains, Top 3 Gains, and Unexpected Insights from research. Used to align team understanding of target users.

### Applicable Scenarios
✅ **Best for**
- Team alignment on target users
- Design decisions
- Feature prioritization

⚠️ **When NOT to use**
- Built from imagination or a single stakeholder's opinion — fictional personas launder assumptions as research
- Marketing segments posing as personas: "Marketing Mary" demographics with no job, pains, or behavioral basis → segments describe who buys; personas should describe who uses and why
- Small user bases where you can just talk to actual users — a persona of your 40 customers is worse than their names

### Key Steps
1. Conduct 8-12 user interviews (or analyze survey data)
2. Cluster interview findings by behavior patterns and needs
3. Create 3 personas, each with: Name, Photo, Demographics, JTBD, Top 3 Pains, Top 3 Gains, Unexpected Insight
4. Validate personas with additional data
5. Use personas in design reviews and prioritization discussions

### Output Template

```
Persona: [Name] — [role, context] — research base: [n interviews, dates]

JTBD: When [situation], they need [job], so they can [outcome]
Top 3 Pains: 1. [with evidence quote] 2. [...] 3. [...]
Top 3 Gains: 1. [...] 2. [...] 3. [...]
Unexpected insight: [what surprised the team — the reason this persona earns its page]
Behavioral anchors: [tools used today, workaround in place, spending/sunk time]

Persona in use: design review cites [which persona + which pain]; feature [X] rejected because no persona's job matches
Expiry: re-validate when [new segment / major behavior shift / 12 months]
```

### Failure Modes
- Demographic filler: personas describing age and coffee habits but no job or pain → every line must trace to interview evidence; cut anything that doesn't
- Persona worship: designing for "Sarah" instead of for the evidence Sarah represents → personas are communication devices for clustered data; when they conflict with new data, data wins
- Never retired: personas from 3 years ago still steering decisions → date the research base and set a re-validation trigger; stale personas are confident lies

### Evidence Strength
Practitioner consensus — research-backed personas (grounded in real interviews and behavioral clustering) are widely valued for team alignment; the method has documented weaknesses too (confirmation bias in clustering, over-literal design for archetypes), and evidence that personas improve design outcomes comes mainly from practitioner reports rather than controlled studies.

### Source
Alan Cooper, *The Inmates Are Running the Asylum* (1999); persona methodology.

## STP Analysis
> source: stp-analysis.md
### Core Concept
3-step marketing strategy framework: Segmentation (divide market into segments) → Targeting (select which segments to serve) → Positioning (define how to be perceived in target segments).

### Applicable Scenarios
✅ **Best for**
- Market entry strategy
- Product positioning
- Marketing strategy development

⚠️ **When NOT to use**
- Single-segment products born from one community — there's nothing to divide; go straight to positioning work
- Segment variables chosen because data exists, not because they predict buying behavior — demographics that don't correlate with need are noise
- As strategy when the real problem is distribution or product-market fit — STP organizes demand you've already proven

### Key Steps
1. **Segmentation**: Divide the market using demographic, behavioral, or needs-based variables
2. **Targeting**: Evaluate each segment (size, growth, competition, fit); select target segments
3. **Positioning**: Define your positioning in target segments (see Positioning Strategy)
4. Develop marketing mix (4Ps) aligned to STP decisions
5. Validate with market data

### Output Template

```
Market: [definition]

Segmentation basis: [needs-based preferred — variable + why it predicts buying]
  | Segment     | Size | Growth | Competition | Fit with our assets | Verdict |
  | [SMB admins]| $[x] | [g%]   | [n players] | [high/med/low]      | target  |
  | [segment 2] | ...  | ...    | ...         | ...                 | skip — [reason] |

Target(s): [1-2 max — more targets means no positioning]
Positioning statement: For [target] who [need], [product] is the [category] that [key benefit], unlike [main alternative].
Downstream: 4Ps aligned [product/price/place/promotion one line each]
Validation: [segment-size source; message test result]
```

### Failure Modes
- Segmentation by census: dividing by age/income brackets that don't move purchase behavior → prefer needs/behavioral segmentation; a segment exists only if it responds differently
- Target-everything: three "primary" segments, three watered-down positionings → targeting is a decision; if nothing was rejected, revisit step 2
- Positioning disconnected from proof: claims the product can't substantiate → each positioning claim needs the evidence trail (reviews, win/loss, data)

### Evidence Strength
Practitioner consensus — the backbone of marketing strategy teaching since Kotler; conceptually sound and universally used, but segment evaluation inputs (size, growth) are frequently estimates, and there's little controlled evidence on framework use translating to outcomes — quality is determined by the market data feeding it.

### Source
Philip Kotler, *Marketing Management*; foundational marketing framework.

## Perceptual Mapping
> source: perceptual-mapping.md
### Core Concept
2D coordinate chart showing how consumers perceive brands/products on two key dimensions. Reveals competitive positioning, whitespace opportunities, and potential repositioning needs.

### Applicable Scenarios
✅ **Best for**
- Brand positioning analysis
- Competitive perception comparison
- Positioning adjustment decisions

⚠️ **When NOT to use**
- Dimensions nobody validated — a 2D map hides whichever axis actually drives choice; confirm axis importance with **Kano** or driver analysis before plotting
- Reading preference into perception — the map shows how brands are seen, not what buyers want; the "empty corner" may be empty because nobody wants to live there
- B2B markets with a handful of accounts — averaging 50+ respondent ratings presumes a large homogeneous pool; analyze key accounts directly instead
- Deciding repositioning from the map alone — it says where you are, not whether you can get there; pair with a capability and cost assessment

### Key Steps
1. Select 2 key dimensions that matter to consumers (e.g. price vs quality, traditional vs modern)
2. Survey 50+ target segment users: rate each brand on both dimensions (1-10)
3. Plot average ratings on 2D chart
4. Analyze: where do competitors cluster? Where is whitespace?
5. Assess: is your current position where you want to be?
6. If repositioning needed, plan messaging/product changes to shift perception

### Output Template

```
Dimensions: X = [low ↔ high price]  Y = [traditional ↔ modern] (validated as decision drivers: [evidence])
Respondents: [n] from [segment], mapped on [date]
Positions (avg rating 1-10): [Brand A]: ([x,y])  [Brand B]: ([x,y])  [Us]: ([x,y])
Clusters: [brands competing on the same territory]
Whitespace: [empty position — and why: unmet demand or no demand]
Gap: current ([x,y]) → target ([x,y]); shift levers: [product / messaging changes]
```

### Failure Modes
- Arbitrary axes: dimensions chosen for chart neatness rather than decision influence → validate axes against stated-importance or driver data; an unimportant dimension makes an unimportant map
- Empty-quadrant fallacy: treating any gap as opportunity → whitespace is only opportunity if someone wants to occupy it; test willingness to pay before calling it
- Perception ≠ preference ≠ feasibility: a desirable position you cannot deliver erodes trust → confirm deliverability before investing in repositioning
- Snapshot staleness: perception moves with every campaign and competitor launch → date the map and set a re-measurement cadence; never re-run strategy on an old chart

### Evidence Strength
Practitioner consensus — perceptual mapping is standard marketing practice with strong face validity for visualizing relative brand positions; its weakness is that the output is only as valid as the dimension choice and rating data behind it, and it captures perception at a point in time rather than causally explaining choice.

### Source
Standard marketing research methodology; multivariate analysis technique.

## Technology Adoption Lifecycle
> source: technology-adoption-lifecycle.md
### Core Concept
5-stage model of technology adoption: Innovators (2.5%) → Early Adopters (13.5%) → Early Majority (34%) → Late Majority (34%) → Laggards (16%). The "chasm" between Early Adopters and Early Majority is where most technology products fail.

### Applicable Scenarios
✅ **Best for**
- Technology product marketing
- Crossing the chasm strategy
- Target customer segment selection

⚠️ **When NOT to use**
- Products whose buyers aren't technology-attitude-driven — the bell-curve psychology was derived from technology adoption, not all purchasing
- Applying the percentages as forecasts — they're a stylized description of diffusion, not your funnel's numbers
- Category-erasing products (smartphones) that collapsed stages — don't force chasm logic onto products riding an existing behavior

### Key Steps
1. Assess current customer composition across 5 adopter categories
2. Identify which stage your product is in
3. If at the chasm (between Early Adopters and Early Majority): develop a whole product solution for a specific beachhead segment
4. Adjust marketing messaging per adopter type
5. Plan strategies to cross the chasm

### Output Template

```
Customer composition: innovators [n (%)] / early adopters [n (%)] / early majority [n (%)] / later [n (%)]

Stage call: [early adopters] — evidence: [references-driven sales, tolerance for gaps, vision purchases]

Chasm check: 
  Early-adopter sales: [growing/plateauing]
  Early-majority objections heard: ["who else like us uses it?", "where's the support/integrations?"] — these are the chasm's voice
  Beachhead candidate: [one segment, narrowly defined] — whole-product gaps to close for them: [support, integrations, references]

Message shift: vision talk (adopters) → [segment-specific whole-product proof] (majority)
Chasm plan: [narrow the target → complete the whole product → win references → expand to adjacent segments]
```

### Failure Modes
- Chasm invoked for every slowdown: plateau may be product, pricing, or channel — not adoption psychology → verify with buyer evidence (reference requests, whole-product complaints) before prescribing chasm strategy
- Beachhead skipped: "cross the chasm" used to justify broadening marketing — the opposite of the prescription → the strategy is concentration: one segment, complete product, dominant reference
- Percentages treated as data: reporting "we've captured 13.5%" — the curve describes adopter types, not a market-share forecast → diagnose which type your current customers behave like

### Evidence Strength
Mixed — diffusion theory (Rogers) is well established sociologically; Moore's chasm prescriptions are influential practitioner lore with memorable case support but limited systematic validation, and the adopter percentages are heuristics from older diffusion studies rather than parameters of modern markets.

### Source
Everett Rogers, *Diffusion of Innovations* (1962); Geoffrey Moore, *Crossing the Chasm* (1991).

## Survey Design
> source: survey-design.md
### Core Concept
A survey is an instrument: wording, order, and sample shape the answers as much as respondents' opinions do. Design it before fielding — decision → hypotheses → constructs → questions → scales → pilot → field → clean — and prefer behavior questions over stated intent, because what people say they would do and what they did diverge systematically.

### Applicable Scenarios
✅ **Best for**
- Quantifying known hypotheses across many users (validate interview findings at scale)
- Satisfaction/usage baselines and tracking
- Segmentation inputs (feeds User Segmentation and User Personas)
- Pricing research with an established instrument (Van Westendorp PSM)
- Established instruments for specific constructs: **SERVQUAL** (service quality — expectation vs perception gaps across tangibility/reliability/responsiveness/assurance/empathy, Parasuraman-Zeithaml-Berry 1985) and **conjoint / MaxDiff** (willingness-to-pay decomposed across feature attributes, when WTP varies by bundle rather than by overall price)

⚠️ **When NOT to use**
- Discovering unknown needs — questions only confirm what you thought to ask; interview first → The Mom Test (Product Discovery), then survey to size what interviews surfaced
- Predicting behavior from stated intent ("would you pay for X?") — inflated several-fold; ask about last actual behavior
- Very small samples (n < ~30 per segment) — an interview study answers more per hour
- Fuzzy constructs — pretest or the numbers will be precise and meaningless

### Key Steps
1. Write the decision the survey informs and the hypotheses it tests (else the data has no consumer)
2. Operationalize each construct into concrete questions
3. Wording rules: one question at a time (no double-barreled), behavior over prediction ("last time" not "would you"), no loaded/leading phrasing, mutually exclusive exhaustive options
4. Order: easy engaging questions first, sensitive ones later, demographics last; randomize option order where viable
5. Choose scales deliberately (5/7-point Likert; NPS only where a benchmark exists)
6. Pilot with ~10-20 respondents; fix every comprehension break before fielding
7. Field to a defined sampling frame; monitor straight-lining and speeders
8. Analyze against the hypotheses; report response rate and sample composition with the findings

### Output Template

```
Decision informed: [what changes based on results]
Hypotheses: [H1..Hn with the question that tests each]
Question list: [text | type (behavior/attitude/screen) | construct | notes]
Scales: [per construct]
Sample frame + target n: [who, how reached, expected response rate]
Pilot findings: [comprehension breaks fixed]
Analysis plan: [cross-tabs per hypothesis, nonresponse caveats]
```

### Failure Modes
- Stated-intent questions: "would you use/pay for X" returns inflated enthusiasm → ask about the last real occurrence; treat intent answers as weak evidence, labeled as such
- Double-barreled and leading questions: "How much do you enjoy our fast, reliable app?" measures nothing identifiable → one construct per question, neutral wording
- Convenience sample read as market truth → weight, restrict claims, or label the bias in the output
- Survey-first discovery: fielding before interviews bakes your blind spots into the data → interviews generate the hypotheses, surveys quantify them
- No pilot: comprehension breaks discovered after 1,000 responses → pilot is not optional
- Nonresponse ignored: the 12% who answered differ from the 88% who didn't → report response rate and who is missing

### Evidence Strength
Practitioner consensus — wording, order, and mode effects are among the most replicated findings in survey methodology (Schuman & Presser's experiments); NPS's causal claims are contested; stated-intent inflation is well replicated across domains.

### Source
Howard Schuman & Stanley Presser, *Questions and Answers in Attitude Surveys* (1981); Floyd Fowler, *Survey Research Methods*; Fred Reichheld, "The One Number You Need to Grow" (2003, NPS). Admission verdict: **Build** (v0.1.12) — the category's methodologies consume research data but none designed the instrument that produces it.

## Category Guide
## Market Research

**When to use**: Market sizing, segmentation, user groups, personas


### Minimum Information Requirements per Methodology

- **Market Sizing**: Requires industry volume data + per-customer ARPU data
- **Market Segmentation**: Requires customer behavior/JTBD/needs data
- **User Segmentation**: Requires product analysis + surveys + ticket data
- **User Personas**: Requires interview/survey data clustering
- **STP Analysis**: Requires segmentation dimension data + per-segment scale/competition/fit assessment
- **Perceptual Mapping**: Requires 50+ target segment users' perception ratings for multiple brands
- **Technology Adoption Lifecycle**: Requires customer composition + acquisition channel + deal cycle data
- **Survey Design**: Requires a named decision + testable hypotheses + reachable sampling frame (pilot before fielding)

### Routing Trigger Signals

- "Market sizing" → Market Sizing (primary)
- "Market segmentation / 3-5 non-overlapping" → Market Segmentation (primary)
- "User segmentation / usage behavior clustering" → User Segmentation (primary)
- "User personas / 3 personas / team user awareness alignment" → User Personas (primary) ⚡ If need to uncover users' "jobs" → use JTBD (Product & Growth); if need empathetic understanding of user feelings → use Empathy Map (User Research)
- "Market entry / product positioning / marketing strategy" → STP Analysis (primary)
- "Brand positioning / competitive perception comparison / positioning adjustment" → Perceptual Mapping (primary)
- "Technology product marketing / crossing the chasm / target customer segment selection" → Technology Adoption Lifecycle (primary)
- "Design a questionnaire / run a survey / quantify across many users / validate interview findings at scale" → Survey Design (primary) ⚡ If discovering unknown needs → use The Mom Test (Product Discovery); if clustering the results into segments → use User Segmentation

### Common Combinations

- **Market entry strategy**: Market Sizing → Market Segmentation → STP Analysis → Perceptual Mapping
- **New product launch**: STP Analysis → Technology Adoption Lifecycle → Pricing Strategy
- **Brand positioning optimization**: Perceptual Mapping → STP Analysis (repositioning)

### Methodology Mutual Exclusion and Ordering Constraints

| Constraint pair | Rule | Reason |
| --- | --- | --- |
| Market Segmentation → User Personas | **Segmentation first, then Personas** | Define market segments first, then build personas per target segment; avoids personas without segmentation basis |
| User Personas vs JTBD | **Choose by goal**: describe typical user's complete profile→Personas; uncover users' "jobs"→JTBD | Input data may overlap but output purposes differ |
| User Segmentation vs RFM Model | **Choose by data foundation**: need behavior/JTBD/needs clustering→User Segmentation; need 3-dimension transaction data tiering→RFM Model | User Segmentation is broader; RFM focuses on transaction data |
| Survey Design vs The Mom Test | **Choose by knowledge state**: known hypotheses to quantify→Survey Design; unknown needs to discover→The Mom Test (Product Discovery) | Questions can only confirm what you thought to ask; discovery needs interviews, quantification needs instruments |
