# Structured Thinking (compact aggregate)
> Aggregated from `references/structured-thinking/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh structured-thinking "<methodology>"`

## MECE + Pyramid Principle
> source: mece-pyramid.md
### Core Concept
MECE (Mutually Exclusive, Collectively Exhaustive) for structuring analysis; Pyramid Principle for structuring communication — lead with the conclusion, then support with arguments and data.

### Applicable Scenarios
✅ **Best for**
- Consulting reports
- Complex problem decomposition
- Executive reporting

⚠️ **When NOT to use**
- Genuinely overlapping systems — forcing MECE on interdependent causes creates false separation; use systems thinking when boundaries don't exist
- Chronological/narrative communication (incident timelines, user stories) — conclusion-first works for decisions, not for stories that build understanding
- Exploratory analysis before the structure is known — MECE is for organizing findings; premature structure pre-decides what you'll find

### Key Steps
1. Start with the answer/conclusion (Pyramid top)
2. Support with 3-5 key arguments (Pyramid middle)
3. Support each argument with data/evidence (Pyramid base)
4. Validate MECE: are the arguments mutually exclusive? Collectively exhaustive?
5. Iterate: if not MECE, restructure until clean

### Output Template

```
Conclusion (the answer, first sentence): [we should do X because of Y]

Key arguments (MECE check on this layer):
  1. [Market: demand is shifting — data: ...]
  2. [Capability: we can execute — data: ...]
  3. [Economics: returns clear the bar — data: ...]
  MECE check: any overlap between arguments? [no — state why] any missing dimension that could overturn the conclusion? [no — state why]

Support layer: each argument carries [evidence + source], not assertions
Counterweight (the strongest counterargument, answered): [...]
One-sentence test: can a listener repeat the conclusion + 3 arguments after one pass? [test it]
```

### Failure Modes
- Fake MECE: "people / process / technology" buckets where the same root cause sits in all three → test overlap with a real case: if one fact lands in two buckets, the cut is wrong; re-cut by the question you're answering
- Pyramid built top-down from a preferred answer: conclusion first becomes conclusion only, evidence reverse-engineered → write the evidence layer and check it still supports the top before communicating; if it doesn't, the top changes
- Over-branched pyramids: 7 arguments, 5 sub-arguments each — nobody retains it → 3-5 arguments max per layer; the discipline is cutting, not enumerating

### Evidence Strength
Practitioner consensus — the communication benefits of conclusion-first structure are consistently supported by practitioner experience and by cognitive-load reasoning (audiences retain hierarchies better than lists); MECE as an analysis-standard is more contested (real-world causation is often non-exclusive), and its rigidity is a known failure mode.

### Source
Barbara Minto, *The Minto Pyramid Principle* (1987); McKinsey consulting methodology.

## Six Thinking Hats
> source: six-thinking-hats.md
### Core Concept
6 thinking modes that teams switch between simultaneously: White (facts/data), Red (emotions/intuition), Black (caution/risks), Yellow (optimism/benefits), Green (creativity/alternatives), Blue (process/facilitation). Forces the team to look at a problem from the same angle at the same time.

### Applicable Scenarios
✅ **Best for**
- Team review and evaluation
- Comprehensive solution assessment
- Breaking discussion deadlocks

⚠️ **When NOT to use**
- Solo work or 1-2 people — parallel thinking pays off when enough perspectives collide; for tiny groups the rotation is ceremony — structure the analysis with **MECE + Pyramid Principle** instead
- Decisions needing weighted trade-offs — hats sequence perspectives but never score them; for ranking, use **Decision Matrix**
- Time-critical situations — six rounds of full-team attention is expensive; in fast-moving response use **OODA Loop**
- A genuinely simple call — running the full hat cycle on an obvious decision buries it in process

### Key Steps
1. **Blue Hat** (facilitator): define the problem, set the agenda
2. **White Hat**: gather and present facts and data
3. **Red Hat**: share emotions and intuitions (no justification needed)
4. **Yellow Hat**: identify benefits and best-case scenarios
5. **Black Hat**: identify risks, cautions, potential problems
6. **Green Hat**: generate creative alternatives and new ideas
7. **Blue Hat** (facilitator): summarize, decide next steps

### Output Template

```
Focus: [the question under the hats]
Blue (process): [agenda, hat sequence, timebox per round]
White: [known facts and data; gaps named]
Red: [gut reactions, one sentence each, no justification]
Yellow: [benefits, value, why it could work]
Black: [risks, weaknesses, what could fail]
Green: [alternatives; ways to fix the black-hat findings]
Blue (summary): [decision / next step / what gets re-examined and when]
```

### Failure Modes
- Hats as theater: people label their usual stance ("my black hat says...") without shifting attention → enforce one hat per round with a visible mode switch: facilitator names the hat, everyone contributes under it, cross-hat remarks ruled out
- Red hat skipped or argued: feelings are judged the moment they are voiced → the red round gets no justification and no rebuttal; the facilitator protects it
- Black hat first: criticism arrives before ideas mature and kills the green round prematurely → yellow precedes black when assessing anything new; if risks dominated round one, rerun green before deciding
- Blue hat absent: no agenda and no summary, so hats become freeform discussion → the facilitator opens by stating the focus and closes with a decision or a next step

### Evidence Strength
Practitioner consensus — six-hat sessions are widely adopted in facilitation and corporate training and are credited with reducing adversarial discussion; causal evidence on decision quality is thin: the claim that separating thinking modes improves group cognition is plausible and consistent with perspective-taking research, but controlled studies of the method itself are scarce, and much of the supporting literature is de Bono's own.

### Source
Edward de Bono, *Six Thinking Hats* (1985).

## Socratic Questioning
> source: socratic-questioning.md
### Core Concept
Systematic questioning to clarify assumptions, test logic, expose contradictions, and arrive at deeper understanding. 6 types of Socratic questions target different aspects of thinking.

### Applicable Scenarios
✅ **Best for**
- Ill-defined problem clarification
- Strategies relying on unverified assumptions
- Requirement and specification review

### Key Steps
1. **Clarification**: "What do you mean by X?" "Can you give an example?"
2. **Probing assumptions**: "What are you assuming?" "Is this always true?"
3. **Probing evidence**: "What evidence supports this?" "How do you know?"
4. **Questioning viewpoints**: "What's an alternative perspective?" "Who benefits?"
5. **Probing implications**: "If that's true, what follows?" "What are the consequences?"
6. **Questioning the question**: "Why is this question important?" "Is this the right question?"

### Orientation Check

When the user deflects questions, answers a different question, or seeks agreement rather than insight, questioning is no longer serving inquiry — diagnose the capture before persisting:

| Capture pattern | Tell | Intervention |
| --- | --- | --- |
| Conclusion preservation | Evidence for counts; evidence against gets explained away | Decouple conclusion from identity: a wrong conclusion costs nothing personal — re-examine it as if advising someone else |
| Authority preservation | "I was already thinking that"; others' input registers only as confirmation | Frame probes as a joint stress-test, not a challenge to expertise |
| Threat reduction | Rushing to resolve; complexity reads as danger | Reduce pressure before analysis: name the safety, slow the pace |
| Completion seeking | Answer speed inversely proportional to problem complexity | Insert a deliberate hold: "One more angle before we settle this." |
| Argument drift | Ever-more-elaborate analysis that keeps landing on the same conclusion | Stop arguing content; move to external checks — a testable prediction, written down, revisited later |

**Exit condition**: under threat reduction, suspend Socratic questioning entirely — lower the exploration pressure first; questioning someone under threat deepens the threat.

**Red line**: this check exists to restore the user's truth-seeking orientation — it is never a persuasion technique.

### When NOT to use

- The user is under pressure or threatened — questioning deepens the threat; lower the pressure first (Orientation Check, threat reduction row)
- The question is factual ("does X support Y?") — Socratic questioning uncovers assumptions, it does not retrieve facts; answer it
- A one-way channel with no user present (batch review, audit log) — nobody can answer the probes
- The user asked for an answer, not an examination — if the analysis is already done and the decision is theirs to make, deliver it; questioning is opt-in, never a default stance
- Persisting past saturation — once assumptions are on the table, stop; endless probing is interrogation, not inquiry

### Output Template

```
Assumption under test: [what the plan takes for granted]
Probe type: clarification | assumption | evidence | viewpoint | implication | the-question-itself
What the evidence actually shows: [verbatim, or "none offered"]
Revised statement: [the sharper version that survives the probing]
Open question: [what the questioning did not resolve]
```

### Failure Modes

- **Probe chains read as cross-examination** — five questions in a row without engaging the answers; answer each probe before the next
- **Explanations instead of evidence** — "the users obviously wanted…" passes unchallenged; ask what observation would have shown otherwise
- **Rhetorical Socratic** — questions whose only acceptable answer is agreement; the Orientation Check red line exists for this
- **Infinite regress** — "but why do you say that?" until the conversation dies; each probe must be answerable in one step from something the user actually said

### Cognitive-Bias Quick Check (Recipe cross-reference)

Before treating probe answers as findings, run three "Ask:" checks on the answers themselves:

- **Anchoring** — Ask: was the first number offered the anchor every later estimate quietly moved from?
- **Sunk cost** — Ask: is any option defended mainly by what has already been spent, not by what it returns next?
- **Confirmation bias** — Ask: what observation would have overturned this conclusion — and did anyone actually look for it?

For the full detector table (lifecycle coverage with trigger signal + check action per bias), route to **Cognitive & Statistical Bias Checklist** (data-analysis, `debias-checklist.md`). This entry holds the pointer, not a duplicate table.

**Admission verdict** (v0.1.6): standalone cognitive-bias entries reviewed — Recipe verdict, because data-analysis already owns the checklist methodology and a second table here would create twin sources of truth.

### Evidence Strength

**Practitioner consensus on method, contested on transfer.** Socratic questioning is a standard fixture in critical-thinking education and the assumption-probing sequence is well documented. Evidence that Socratic dialogue improves decision quality in applied settings is mixed, and trained facilitation matters more than the question types themselves — treat the six types as a checklist for a facilitator, not a self-operating procedure.

### Source
Socrates (470-399 BC); formalized in critical thinking education.
Provenance: orientation-capture patterns absorbed from [thinking-partner](https://github.com/mattnowdev/thinking-partner) (MIT license), absorbed 2026-09.
Cognitive-Bias Quick Check added with **Recipe** verdict, 2026-10-01 — data-analysis owns the full checklist (`debias-checklist.md`); this entry holds a three-question pointer, not a second table.

## Cynefin Framework
> source: cynefin.md
### Core Concept
Classify problems into 4 domains: Clear (known knowns — best practice), Complicated (known unknowns — expert analysis), Complex (unknown unknowns — probe-sense-respond), Chaotic (unknowable — act first to stabilize). Each domain requires a different response strategy.

### Applicable Scenarios
✅ **Best for**
- Problem nature identification
- Pre-check before methodology selection
- Complex/uncertain situations

⚠️ **When NOT to use**
- The probe-or-analyze choice is already obvious — Cynefin is a triage aid, not a required label; classifying a settled call adds ceremony
- As difficulty language ("this problem is very complex") — the domains describe cause-effect visibility, not effort or importance; misuse degrades the categories
- Post-hoc narratives about past events — classifying history is easy and cheapens the sense-making; the framework exists to pick the next move
- A factual dispute between stakeholders — no domain classification settles a disagreement about facts; settle the facts first

### Key Steps
1. Describe the problem situation
2. Assess: can cause-effect be determined? (Clear: yes, everyone agrees; Complicated: yes, with expert analysis; Complex: only in retrospect; Chaotic: no)
3. Classify the domain
4. Apply the appropriate response:
   - **Clear**: Sense → Categorize → Respond (apply best practice)
   - **Complicated**: Sense → Analyze → Respond (apply expert analysis)
   - **Complex**: Probe → Sense → Respond (experiment, then respond)
   - **Chaotic**: Act → Sense → Respond (stabilize first, then analyze)
5. If the domain is unclear, use Framework Selection to decide

### Output Template

```
Situation: [what is happening, 2-3 sentences]
Cause-effect test: [determinable by anyone? / by experts? / only in retrospect? / not at all]
→ Domain: [Clear / Complicated / Complex / Chaotic]
Response route: [Sense-Categorize-Respond / Sense-Analyze-Respond / Probe-Sense-Respond / Act-Sense-Respond]
Concrete next move:
  - Clear → [the existing best practice applied]
  - Complicated → [which expertise, engaged with what question]
  - Complex → [safe-to-fail probe: action + observation + amplify/stop rule]
  - Chaotic → [the stabilizing act taken first]
Re-check trigger: [signal that the domain has shifted]
```

### Failure Modes
- Domain misdiagnosis: a Complex situation treated as Complicated — experts analyze forever and never probe → when expert analysis stalls or disagrees, switch to probe-sense-respond; the categories are about cause-effect visibility, not difficulty
- "Complex" as an excuse: the label becomes a reason to avoid analysis where cause-effect IS determinable → run the test honestly: can experts agree on a method, even if not on the answer?
- Chaotic overreach: ordinary turbulence treated as Chaos and diagnosis skipped → act-first is for genuine crisis; most situations allow a moment to classify
- One classification forever: domains drift as context shifts (a Clear practice decays into Complex) → re-classify when the current response stops working; drift is the normal case

### Evidence Strength
Practitioner consensus — an established sense-making framework in knowledge management and agile practice, valuable mainly for forcing the probe-vs-analyze choice before a method is picked. The domains are conceptual categories rather than measured ones: empirical validation of the four-domain taxonomy and its response prescriptions is limited, and the framework's authors position it as a sense-making device, not a predictive model.

### Source
Dave Snowden (1999); IBM Center for Systems and Cognitive Understanding.

## Second-Order Thinking
> source: second-order-thinking.md
### Core Concept
Ask "and then what?" to analyze the 2nd, 3rd, and further-order consequences of decisions. First-order thinking sees immediate effects; second-order thinking sees chain reactions, unintended consequences, and systemic effects.

### Applicable Scenarios
✅ **Best for**
- Policy decisions
- Pricing changes
- Ecosystem effect analysis

⚠️ **When NOT to use**
- One-shot, short-horizon, weakly coupled systems — "and then what?" terminates immediately; first-order analysis is sufficient
- Raw uncertainty already swamps the first-order effect — chaining speculations multiplies noise; firm up the base estimate with **Probabilistic Reasoning** first
- Time-critical response — mapping chain reactions is analysis; in live incidents, act first (**OODA Loop**)
- The decision is reversible and cheap to iterate — tracing full chains costs more than the experiment does; try it and observe

### Key Steps
1. State the proposed decision
2. First-order effect: what happens immediately?
3. Second-order effect: what happens as a result of the first-order effect?
4. Third-order effect: what happens as a result of the second-order effect?
5. Map the chain of effects; identify potential unintended consequences
6. Decide: do the long-term consequences outweigh the short-term benefits?

### Output Template

```
Decision: [proposed change]
1st order: [immediate effect — highest confidence]
2nd order: [reaction to the effect: competitor / customer / system response]
3rd order: [consequence of that reaction]
Unintended branch: [the chain you did not design for]
Confidence per level: [H / M / L — decaying with each order]
Verdict: the long-term chain [supports / undermines] the short-term benefit because [mechanism]
Decision: [proceed / modify / reject]
Stop rule: [order beyond which further effects cannot change the choice]
```

### Failure Modes
- Infinite regress: "and then what?" forever and the analysis never lands → stop at the level that changes the decision; write the stop rule before tracing
- Chain as narrative: one vivid doom-chain recounted as the future → generate at least one positive and one negative chain per decision; second-order effects are not uniformly adverse
- Precision theater: order-4 effects stated with the confidence of order-1 → mark confidence decaying per order; distant orders are hypotheses, not forecasts
- Paralysis by chain: every action has bad knock-on effects, so nothing is chosen → chains weigh into the decision, they don't veto it; compare chains across options, not against inaction imagined as consequence-free

### Evidence Strength
Practitioner consensus, thin direct evidence — the underlying mechanism (actions trigger reactions that reshape long-run outcomes: cobweb dynamics, policy feedback, strategic response) is well established in economics and systems research, but "second-order thinking" as a named procedure has no outcome studies; its value is as a discipline against first-order-only reasoning, and chains beyond order 2-3 are mostly structured conjecture.

### Source
Howard Marks, *Mastering the Market Cycle*; mental model popularized by Shane Parrish (Farnam Street).

## Framework Selection
> source: framework-selection.md
### Core Concept
Meta-methodology for choosing the right framework — and the gate that keeps frameworks from becoming goals. 5 principles + a weighted fitness scorecard with an explicit NONE default: a framework is used only when it clears the bar; otherwise answer directly without one.

### Applicable Scenarios
✅ **Best for**
- Meta-decision when choosing frameworks
- Avoiding framework misuse
- Team framework alignment

⚠️ **When NOT to use**
- The choice is obvious and uncontroversial — scoring adds ceremony, not insight
- The user explicitly named the framework they want; honor it and note risks instead of re-scoring
- Only one realistic candidate exists — apply the 5 principles as a one-sentence check instead of a full scorecard

### Key Steps
1. State the core question clearly
2. List candidate frameworks
3. For each, apply the 5 principles:
   - Can it directly answer the core question?
   - Do we have enough information to use it?
   - Will its output be actionable?
   - Is the effort proportional to the decision's importance?
   - Can it be combined with other frameworks?
4. Score every surviving candidate on the fitness scorecard below
5. Use the top framework only if it clears the bar; otherwise return NONE and answer directly

### Fitness Scorecard — the gate

Score each candidate 1–5 per criterion, then compute the weighted total:

| Criterion | Weight | 1 looks like | 5 looks like |
| --- | --- | --- | --- |
| Task alignment | 30% | Answers an adjacent question | Directly answers the core question |
| Input readiness | 20% | Core data missing | All required inputs at hand or cheap to get |
| Execution competence | 20% | Needs expertise or data nobody here has | Agent and user can execute it faithfully |
| Time cost | 15% | Effort outstrips the decision's stakes | Proportional effort |
| Audience fit | 15% | Output unusable for its audience | Output immediately usable by them |

**The bar**: task alignment ≥ 4 AND weighted total ≥ 3.5. If the top candidate's weighted total falls below 3.5, the answer is NONE — answer the user's question directly and state why no framework was used. Failing the bar never means "run it anyway with caveats"; a marginal framework produces confident-looking but unfounded output.

**Tie-break**: when the top two candidates sit within 0.25 points, prefer the one that needs fewer inputs and less execution time; if still tied, prefer NONE (or the user's explicit pick) over an arbitrary winner.

**Routing output format**: a prioritized decision, not a single pick — state the selected framework, the backup, and explicitly which candidates to skip and why (near-synonyms, missing inputs, no complementary role).

### Abandonment Signals — stop and re-route mid-execution

- Forcing inputs into slots just to keep the framework alive
- The framework steers attention away from factors you know matter
- No incremental insight after honest effort (~15 minutes for a quick scan)
- You picked it by habit ("this kind of task always gets SWOT") — discard the habitual pick and re-score openly

On any signal: stop, explain what was completed and why the framework fails, re-select once per task (the replacement must clear the scorecard); if the replacement fails too, return NONE and answer from the evidence gathered so far.

### Output Template

```
Core question: [one sentence]

Candidates (1-5 per criterion; weights: alignment 30% / readiness 20% / competence 20% / cost 15% / audience 15%):
  [Framework A]  alignment 5  readiness 4  competence 4  cost 4  audience 4  → weighted 4.30 ✅ clears bar
  [Framework B]  alignment 3  readiness 4  competence 3  cost 3  audience 4  → weighted 3.35 ❌ below bar

Decision: use [Framework A] (primary), [backup if any]; skip [B, C] — [near-synonym of A / missing inputs / no complementary role]
If NONE: answer directly. Why no framework: [top candidate + its failing criterion]
```

### Failure Modes
- Scoring theater: inventing justifying scores for an already-made choice → write the evidence next to each score before totalling
- Bar-lowering under momentum: rounding a 3.4 up to 3.5 → the gate only works if NONE is a real, cost-free option
- Gate-skipping for familiar frameworks: habit picks skip scoring entirely → habitual picks get scored like any other candidate

### Evidence Strength
Mechanism-level, not empirical: no controlled studies show that this specific weighted bar improves decision quality. Its value is decision hygiene — it makes "no framework" a legitimate, explicit outcome instead of a failure state. The weights are defaults, not calibrated constants; adjust them per task and disclose the adjustment.

### Source
Kueiku skill methodology; meta-framework design.

## Connecting Dots
> source: connecting-dots.md
### Core Concept
Cross-domain knowledge connection sparks innovation. By deliberately combining insights from different fields, novel solutions emerge that single-domain thinking cannot produce.

### Applicable Scenarios
✅ **Best for**
- Innovation stimulation
- Cross-disciplinary thinking
- Personal growth planning

⚠️ **When NOT to use**
- The problem is well-structured and the domain has a standard method — forced cross-domain analogy adds noise; use **First Principles** or the domain's own tools
- You have no dots: no reading, no adjacent-domain exposure, no collected mechanisms — the method recombines material, it cannot conjure it; gather first
- Execution-critical moments on a known-good path — novelty is a cost here, not a feature
- As a substitute for depth — a metaphor borrowed from another field is not evidence; validate the borrowed mechanism in this domain before acting on it

### Key Steps
1. Identify the problem or opportunity
2. Gather dots: collect insights, experiences, and knowledge from diverse domains
3. Look for patterns: what connections exist between seemingly unrelated dots?
4. Force connections: "How would [domain X] approach this problem?"
5. Evaluate the novel connections for feasibility and value
6. Develop the most promising connections into actionable ideas

### Output Template

```
Problem: [the question worth connecting dots for]
Dots inventory:
  - [domain A]: [insight / mechanism that worked there]
  - [domain B]: [insight / mechanism]
Forced connections: "How would [domain X] approach this?" → [candidate idea]
Pattern check: [what the candidates share / why the transfer might hold]
Feasibility + value screen: [idea → viable? valuable? / reason discarded]
Developed idea: [the one connection worth prototyping + its first cheap test]
```

### Failure Modes
- Metaphor mistaken for mechanism: "we'll run like Spotify squads" transfers the vocabulary, not the operating conditions → name the causal mechanism being borrowed and check whether this domain satisfies its preconditions
- Dot scarcity dressed as insight: recombining two shallow exposures yields shallow output → depth in at least one domain is the entry fee; go gather more dots instead
- Novelty bias: the surprising connection wins attention over the useful one → screen candidates on feasibility and value, never on surprise
- Connection without validation: the idea is announced, never tested → convert the best candidate into a cheap experiment with a falsifiable expectation

### Evidence Strength
Practitioner consensus, weakly evidenced — combinatorial creativity and analogical transfer are documented in cognitive science and many recorded breakthroughs are cross-domain recombinations, but "deliberately cross-pollinate to innovate" is a describing pattern, not a validated procedure: no studies show forced-connection exercises outperform deep single-domain work at equal time investment, and most borrowed analogies fail their preconditions check.

### Source
Steve Jobs Stanford commencement speech (2005): "You can't connect the dots looking forward; you can only connect them looking backwards."

## Reframe and Elevate
> source: reframe-and-elevate.md
### Core Concept
When stuck on a problem, reframe it (change the question) or elevate it (move to a higher abstraction level). Often, being stuck means you're solving the wrong problem or at the wrong level.

### Applicable Scenarios
✅ **Best for**
- Problem stuck situations
- Innovation breakthroughs
- Strategic repositioning
- Dilemma decisions

⚠️ **When NOT to use**
- The problem statement is fine and the real blocker is execution — reframing becomes productive procrastination; attack the blocker instead
- Live incidents and time-boxed operations — "what if the constraint didn't exist?" is a planning-room move; in crisis, work the constraint (**OODA Loop**)
- The current frame was deliberately negotiated with stakeholders — re-opening the question undoes an agreement without adding information; escalate through the agreed process
- As a serial escape — one more reframe always feels possible; cap candidates at 2-3 and then choose, or nothing lands

### Key Steps
1. State the current problem frame clearly
2. Ask: "Am I solving the right problem?"
3. Reframe: restate the problem from a different perspective
   - "How would a competitor see this?"
   - "What if the constraint didn't exist?"
   - "What's the opposite of my current assumption?"
4. Elevate: move to a higher abstraction level
   - "What's the broader system this problem is part of?"
   - "What goal does this problem serve?"
5. Select the most productive new frame; proceed with the new framing

### Output Template

```
Current frame: [the question as currently stated] — stuck because [why]
Reframe candidates:
  - Other actor's view: "How would [competitor / customer / regulator] state this?" → [restated question]
  - Constraint removal: "What if [constraint] didn't exist?" → [restated question]
  - Assumption inversion: "What if [core assumption] were false?" → [restated question]
Elevation: this problem serves [higher goal]; at that level the question becomes [restated question]
Selected frame: [one candidate] — because [it unblocks / it changes the decision]
First move under the new frame: [concrete next action]
```

### Failure Modes
- Reframe as escape: stuck on hard execution, so the problem gets redefined into an easier one → require the new frame to explain why the old frame failed, not just to feel fresher
- Infinite ascent: every frame serves a higher goal and the elevation never lands → stop at the level where action is still possible; go no higher than the level that changes what you can do
- Frame shop without selection: five candidate frames generated, none chosen → pick one explicitly, state what it changes, and commit for a defined period
- Aphorism as authority: quotes justify the move but don't validate the new frame → a reframe earns its keep only if answering the new question changes the action, not the mood

### Evidence Strength
Practitioner consensus — reframing and problem elevation are staples of coaching, design thinking, and strategy practice, and cognitive research on problem representation supports the core claim that how a problem is posed constrains the solution space. There is no validated procedure for when to reframe or which frame to pick; the evidence is strongest for the diagnosis (being stuck often means the wrong frame) and weakest for the method (finding the better frame reliably).

### Source
Albert Einstein: "If I had an hour to solve a problem, I'd spend 55 minutes thinking about the problem and 5 minutes thinking about solutions."

## Systems Thinking
> source: systems-thinking.md
### Core Concept
Understand complex systems through feedback loops (reinforcing and balancing), causal loop diagrams, and leverage point analysis. Reveals why solutions that work short-term often worsen problems long-term.

### Applicable Scenarios
✅ **Best for**
- Recurring problems
- Solutions that work short-term but worsen long-term
- Complex system analysis

### Key Steps
1. Define the system boundary and key variables
2. Map causal relationships between variables (causal loop diagram)
3. Identify feedback loops: reinforcing (amplifying) and balancing (stabilizing)
4. Match the loop structure to a system archetype (table below); if none fits, say so — don't force one
5. Find leverage points on Meadows' hierarchy (below): intuition digs at parameters; durable change lives higher
6. Mark each candidate's **wrong-direction risk**: intuitive push vs. correct push (Meadows' warning — people find the right knob and turn it the wrong way; on reinforcing-loop gain, intuition amplifies, leverage damps)
7. Test interventions mentally for second-order effects; design at the chosen leverage point and monitor for unintended consequences

### System Archetypes

| Archetype | Signature | Breakthrough direction |
| --- | --- | --- |
| Limits to Growth | Growth hits a delayed constraint | Relieve the constraint; don't push growth harder |
| Shifting the Burden | Quick fix erodes the fundamental capability | Fund the fundamental fix; tolerate the symptom |
| Fixes That Fail | The fix feeds a loop that worsens the problem | Slow down; name the unintended loop |
| Drifting Goals | The standard erodes to close the gap | Anchor the goal to an external absolute |
| Escalation | Two parties act on a relative measure | Drop the comparative measure; de-escalate unilaterally |
| Growth & Underinvestment | Capacity trails demand; standards track past performance | Invest ahead of demand |
| Success to the Successful | Allocation bets on last cycle's winner | Break the winner-takes-all allocation |
| Tragedy of the Commons | Individual gain from a shared resource | Make the collective loss visible and immediate |

### Leverage Hierarchy (Meadows)

Weakest → strongest: 12 parameters · 11 buffers · 10 stock-flow structure · 9 delays · 8 balancing-loop strength · 7 reinforcing-loop gain · 6 information flows · 5 rules/incentives · 4 self-organization · 3 goals · 2 paradigms · 1 transcending paradigms.

### When NOT to use

- The problem is not a system — a single broken component with a known fix needs a repair, not a loop diagram
- Data is too thin to map causal relationships — a loop drawn on one anecdote is a picture of an assumption, and the archetype match will be confabulated
- Time pressure demands a decision this month — mapping loops and locating leverage is slow by design; say so instead of shipping a shallow diagram
- The system boundary cannot be agreed on — every party drawing a different boundary produces two diagrams and a new argument
- Single-loop mechanics with known parameters — tuning the parameter is faster and safer than restructuring the loop

### Output Template

```
Boundary: [what is inside / explicitly outside]
Variables: [2–6, with the one that actually drives behavior marked]
Reinforcing loop: [R: A↑ → B↑ → A↑] | Balancing loop: [B: A↑ → B↑ → A↓]
Archetype: [name from the table, or "no archetype fits — structure is novel"]
Leverage point: [Meadows level, weakest → strongest]
Wrong-direction risk: [what intuition does here, and what the correct push is]
Second-order watch: [what gets worse downstream, and the monitoring signal]
```

### Failure Modes

- **Forced archetype match** — the table has eight patterns; resembling two of them does not make a system one of them; "no archetype fits" is a valid and often correct output
- **Diagram without data** — arrows drawn from plausibility read as findings; mark inferred links as inferred
- **Leverage claimed at the parameter level** — "increase X by 10%" presented as a structural fix; on reinforcing loops intuition pushing harder is the documented failure mode, not the exception
- **Boundary drawn to get the answer you want** — excluding an inconvenient variable makes the loop look manageable; state what was left out and why

### Evidence Strength

**Strong for structure, weaker for prediction.** Meadows' leverage hierarchy and the archetype catalog come from decades of systems practice and are widely replicated; Senge's archetype work rests on a case-study base. Predictive power is genuinely contested: correctly mapping a loop structure does not reliably predict an intervention's outcome — which is why the wrong-direction check and second-order watch above are mandatory rather than optional.

### Source
Donella Meadows, *Thinking in Systems* (2008); Peter Senge, *The Fifth Discipline*.
Provenance: archetype catalog, leverage hierarchy, and wrong-direction check absorbed from [systems-thinking-skills](https://github.com/BayramAnnakov/systems-thinking-skills) (MIT license), absorbed 2026-09.

## Category Guide
## Structured Thinking

**When to use**: Organizing complex information, improving analytical rigor, clear expression, clarifying assumptions


### Minimum Information Requirements per Methodology

- **MECE + Pyramid Principle**: Requires clear complex problem to express/decompose (conclusion first + MECE)
- **Six Thinking Hats**: Requires clear topic/problem statement
- **Socratic Questioning**: Requires a specific claim or hypothesis as starting point
- **Cynefin**: Requires problem description (for judging problem domain)
- **Second-Order Thinking**: Requires clear decision/action plan
- **Framework Selection**: Requires clear problem statement + candidate framework list
- **Connecting Dots**: Requires cross-domain knowledge base + clear question
- **Reframe and Elevate**: Requires current problem frame + stuck point
- **Systems Thinking**: Requires clear problem description + system boundaries + key variable list

### Routing Trigger Signals

- "Structured expression / analysis framework" → MECE + Pyramid Principle (primary)
- "Multi-perspective comprehensive evaluation / team discussion" → Six Thinking Hats (primary)
- "Clarify vague assumptions / question premises" → Socratic Questioning (primary)
- "User defends a conclusion / seeks validation / analysis always confirms the same conclusion" → Socratic Questioning (Orientation Check)
- "Complex problem domain identification / response strategy selection" → Cynefin Framework (primary)
- "Decision chain effects / second-order consequence analysis" → Second-Order Thinking (primary)
- "Which framework to choose / framework misuse / meta-decision" → Framework Selection (primary)
- "Innovation stimulation / cross-disciplinary thinking / connecting dots" → Connecting Dots (primary)
- "Problem stuck / reframe problem / elevated thinking" → Reframe and Elevate (primary)
- "Recurring problems / feedback loops / nonlinear dynamics" → Systems Thinking (primary)
- "Quick fix keeps failing / dependence on workarounds / growth stalls despite effort" → Systems Thinking (archetype matching)

### Common Combinations

- **Framework selection and reconstruction**: Framework Selection (choose framework) → if none work → Reframe and Elevate (reframe problem)
- **Innovation breakthrough**: Reframe and Elevate (reframe perspective) → Connecting Dots (cross-domain connection) → Six Thinking Hats (Green Hat ideation)
- **Complex problem diagnosis**: Systems Thinking (feedback loops + leverage points) → Second-Order Thinking (chain effects) → Cynefin (problem domain identification)
- **Growth flywheel analysis**: Systems Thinking (reinforcing loop identification) → Growth Loops (flywheel design) → AARRR (funnel validation)
