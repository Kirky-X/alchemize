# Leadership (compact aggregate)
> Aggregated from `references/leadership/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh leadership "<methodology>"`

## Reality Distortion Field
> source: reality-distortion-field.md
### Core Concept
Through conviction and expression, make the team believe the impossible is possible. Not about lying — it's about setting audacious goals and creating unwavering belief that they can be achieved. Must have exit conditions to prevent toxicity.

### Applicable Scenarios
✅ **Best for**
- Pushing teams past self-imposed limits
- Selling vision (investors, customers, team)
- Rally speeches and mobilization

⚠️ **Use with caution**
- Must have exit conditions (when to acknowledge reality)
- Not sustainable as a long-term management style
- Requires genuine belief from the leader

⚠️ **When NOT to use**
- Safety-critical, regulatory, or factual claims — the method manufactures conviction, not evidence; a belief amplified forty times is still wrong when the underlying claim is false
- Situations where buy-in must be genuine and earned — pressure applied instead of shared reasoning produces compliance in the room and quiet resistance after it
- A team that has already been burned by an over-promised target — the credibility cost of the next miss exceeds the motivational gain; rebuild a delivery record first
- Problems whose cause is structural rather than motivational — missing tooling, unclear ownership, or misaligned incentives → **Change Management** or **Team Topologies**

### Key Steps
1. Set an audacious but not delusional goal
2. Articulate a compelling vision of the future
3. Demonstrate unwavering personal conviction
4. Create urgency and momentum
5. Define exit conditions: when to pivot or acknowledge failure
6. Follow through with action — credibility requires delivery

### Output Template

```
Audacious goal: [one outcome + deadline + what "done" means]
Belief gap: [where the team is now | what they would have to believe]
Reality check: [what must be true for the goal to be reachable | earliest evidence of it]
Vision narrative: [future state, concrete enough to be checkable]
Exit conditions: [metric or date | if it is not met, the pivot or the acknowledgment]
Delivery commitments: [first 30 / 60 / 90-day deliverable | owner | date]
Belief check: [the observable behavior that shows the team believes it, not says it]
```

### Failure Modes
- Conviction without delivery: the goal stays "believed" while nothing moves → date and publish the first 30-day deliverable; belief with no delivery converts into cynicism faster than no belief
- Goal drift into delusion: the target slides each time a milestone is missed → fix the deadline and the exit condition before the first miss; a target that moves can never fail, so it can never be won
- Exit conditions that never trigger: the leader is committed, so no evidence ever counts as failure → name a party outside the commitment to adjudicate the exit condition
- Belief substituted for capability: conviction replaces the skills, budget, or dependency the goal needs → check feasibility (people, money, dependencies) separately from belief; the two fail independently
- Toxic residue: fear-driven performance outlasts the goal → pair with **Change Management**; a rally leaves an organization to live in afterwards

### Evidence Strength
Practitioner consensus — this is biography-derived lore, not a tested method. The term comes from Apple employees describing Steve Jobs, the supporting account is retrospective journalism and anecdote, and there is no controlled evidence that transferring conviction produces better outcomes than ordinary motivation or better planning. Its real value is as a description of a recognizable leadership behavior and as a diagnostic for teams that have stopped attempting hard things; the well-documented failure modes (delusion, moved goalposts, morale damage after a miss) are exactly why the exit conditions are not optional decoration.

### Source
Term coined by Apple employees describing Steve Jobs; analyzed in Brent Schlender's *Becoming Steve Jobs*.

## A-Player Density
> source: a-player-density.md
### Core Concept
A-players hire A-players; B-players hire C-players. Talent density determines team ceiling. Once B/C players enter, the team's capability declines irreversibly unless addressed. Maintain high density through rigorous hiring, performance management, and sometimes termination.

### Applicable Scenarios
✅ **Best for**
- Hiring decisions
- Team building
- Performance management

⚠️ **When NOT to use**
- The constraint is team structure or boundaries, not individual quality → **Team Topologies** — no hiring decision fixes a dependency bottleneck or an overloaded scope
- The team is too small to have a hiring or exit lever — with five people, "raise the bar" changes nothing until someone leaves; use the behavior standard as a development plan instead of a ranking
- Competence is defined by credentials or domain standards (clinical, legal, safety-critical engineering) — "A-player" is undefined without a competency rubric, so the audit becomes taste dressed as rigor
- The gap is a missing skill or missing tooling, not missing capability → diagnose the capability gap first; a rating without a development or resourcing answer is a verdict, not a fix

### Key Steps
1. Define A-player behavior standards (not just title/credentials)
2. Audit current team: who are A/B/C players by behavior?
3. For B players: can they be developed to A? Set timeline.
4. For C players: honest conversation about fit; transition out if needed
5. Raise hiring bar: only hire people you'd be excited to work with
6. Monitor density continuously; address declines early

### Output Template

```
A-player behavior standard: [3-5 observable behaviors + where the evidence comes from]
Team audit: [name | A/B/C by behavior | written evidence | trajectory (improving/stagnant/declining)]
Development cases: [B player | missing A behavior | plan + owner + deadline]
Exit decisions: [C player | honest-conversation date | transition plan | knowledge-transfer risk]
Hiring bar: [required behaviors vs. required credentials | what the bar now rejects]
Density: current [%A / %B / %C] → target [%A / %B / %C] by [date]
```

### Failure Modes
- Labeling by vibe: A/B/C assigned from title, seniority, or instinct → publish the behavior standard first and require written evidence per rating; a rating without evidence is a guess with a letter attached
- A-player worship: everyone must be an A, so strong B-players get no legitimate place → grade the role, not the person, and give B-players a named path to A
- A bar with no roles behind it: raising the standard while the hiring pipeline is frozen → pair the bar with an actual hiring plan; a bar nobody can clear is a rejection letter, not a strategy
- Termination without a documented standard: the C-list becomes legally and morally indefensible → document standards and evidence first, run the honest conversation, and prepare the transition and handover
- Density as a one-time score: measured at a reorg, then never again → track it on a fixed cadence; density decays quietly through ordinary attrition

### Evidence Strength
Practitioner consensus — the tiering originates in Netflix's culture documentation and is widely adopted as hiring and performance language, and its core claim (clear standards plus selective hiring raise the ceiling of a team) is plausible and consistent with mainstream talent practice, but it is a business artifact rather than a validated instrument: no controlled evidence supports the specific tier thresholds, the "A-player" definition is usually left unstated until after ratings are made, and the sharpest documented failure (a bar so high it starves hiring or freezes internal mobility) comes from practitioner critique rather than from measurement.

### Source
Netflix culture deck (*Freedom & Responsibility*); Geoff Smart & Randy Street, *Who*.

## Change Management
> source: change-management.md
### Core Concept
Systematically drive organizational change using Kotter's 8-step process + ADKAR model. Kotter focuses on organizational momentum; ADKAR focuses on individual transition. Use both for comprehensive change.

### Applicable Scenarios
✅ **Best for**
- Organizational transformation
- Cultural change
- Large-scale behavior change

⚠️ **When NOT to use**
- The change is one person's or one team's skill gap — an eight-step organizational process applied to a single behavior wastes months → coach it directly
- A live crisis or incident — the sequence assumes time for coalition-building; contain the damage first, then change
- The target state itself is contested — without agreement on the vision, the communication steps produce theater; settle the strategy question before running the sequence
- The real blocker is team structure or handoff friction → **Team Topologies** — restructure the boundaries first, or instead of, running the sequence

### Key Steps (Kotter 8-Step)
1. Create urgency — why change now?
2. Build a guiding coalition — assemble influential change champions
3. Form a strategic vision — clear, compelling future state
4. Enlist a volunteer army — communicate broadly, get buy-in
5. Enable action by removing barriers — remove obstacles
6. Generate short-term wins — celebrate early victories
7. Sustain acceleration — keep momentum, don't declare victory too early
8. Institute change — anchor in culture

### Key Steps (ADKAR per individual)
1. **A**wareness — of the need for change
2. **D**esire — to participate and support
3. **K**nowledge — on how to change
4. **A**bility — to implement new skills/behaviors
5. **R**einforcement — to sustain the change

### Output Template

```
Change objective: [what must be true after, by when, and for whom]
Urgency case: [why now — the cost of the status quo]
Guiding coalition: [name | role | influence | what they must do]
Vision statement: [one sentence describing the future state]
Stakeholder ADKAR: [name | current state per A/D/K/A/R | blocker | owner + date]
Barriers to action: [structural blocker | owner | removal action]
Short-term wins (first 90 days): [deliverable | metric | date]
Reinforcement: [mechanism | cadence | owner | what happens if the old behavior returns]
Change review: [checkpoint dates | evidence expected at each checkpoint]
```

### Failure Modes
- Announcement mistaken for adoption: the org hears the new direction and behaves as before → measure behavior at the checkpoints, not announcement reach
- Coalition of the converted: the guiding coalition is made of people who already agreed, so skeptics never engage it → recruit skeptics into the coalition; its job is dissent, not cheerleading
- Symbolic short-term wins: early wins are picked for visibility, not for practicing the new behavior → tie each win to the behavior that must change
- Reinforcement never lands: old incentives, OKRs, and metrics still reward the old way → change the incentive structure before declaring victory
- Kotter and ADKAR desynchronized: the org narrative advances while individual transitions stall → track the per-person ADKAR column, not the org-level slide

### Evidence Strength
Practitioner consensus — Kotter's sequence and ADKAR are among the most widely used change frameworks in large organizations, and the ADKAR diagnostic has survey-based support for the claim that individual transition states, not communication volume, predict adoption. The causal evidence is thin: success is mostly self-reported practitioner assessment, the frameworks are rarely compared against simpler well-executed interventions, and the documented failure mode of most failed programs is not the absence of a framework but the absence of follow-through on the last two steps.

### Source
John Kotter, *Leading Change* (1996); Jeff Hiatt, ADKAR model (Prosci).

## Team Topologies
> source: team-topologies.md
### Core Concept
Organizational architecture constrains system architecture (Conway's Law), so design team boundaries deliberately instead of inheriting them. Four team types — stream-aligned, platform, enabling, complicated-subsystem — and three interaction modes — collaboration, X-as-a-Service, facilitating — make the structure explicit; cognitive load is the binding constraint that limits what any team can own.

### Applicable Scenarios
✅ **Best for**
- Structuring or restructuring delivery organizations around domain boundaries
- Deciding platform-vs-product team splits and what "platform" actually owes its users
- Diagnosing dependency hell: too many teams waiting on too many other teams
- Aligning team boundaries with software boundaries (pairs with Domain-Driven Design (Engineering))

⚠️ **When NOT to use**
- One team is the whole org — applying four team types to five people is taxonomy cosplay; grow first
- The real problem is individual capability or hiring → A-Player Density
- Reorganizing as a reflex response to friction, without a flow diagnosis → diagnose with flow metrics first
- Strategy is the actual problem; structure cannot fix direction → Strategy Red Team (Execution) first

### Key Steps
1. Map current state: every team's type, scope, self-assessed cognitive load, and actual interaction modes
2. Define intended domain boundaries (with bounded contexts where software is involved)
3. Assign each team a type; flag scope that overloads any team (load is the constraint, not headcount)
4. Choose the interaction mode per team pair; convert chaotic collaboration into X-as-a-Service where the service is stable
5. Set team lifespan expectations: stream-aligned teams are long-lived; their scope changes, the team persists
6. Evolve on a cadence: re-assess when scale, ownership, or load shifts; measure flow (dependency count, wait time, cross-team tickets)

### Output Template

```
Current team map: [team | type | scope | load (low/medium/high) | actual interactions]
Target topology: [team | type | scope | interactions (mode per pair)]
Cognitive load findings: [overloaded teams + what moves off]
Transition steps: [sequence, what changes per step, who is affected]
Flow metrics baseline + target: [cross-team dependencies, wait time, rework signals]
Re-assessment trigger: [scale/ownership threshold]
```

### Failure Modes
- Relabeling: renaming teams with four new type words while interactions stay unchanged → the interaction modes are the mechanism, not the type labels
- Ignored cognitive load: the "platform" team absorbs every request and becomes a ticket queue → enforce scope by load, convert to X-as-a-Service with a real product surface
- Boundary churn: re-org after every friction — teams never gain the trust and rhythm long lifespans create → change scope within stable teams before changing teams
- Structure without Conway awareness: communication patterns mirror the org chart whether designed or not → place the boundaries where you want the system boundaries
- premature topologies (single-team orgs): ceremony replaces work → defer until multiple teams genuinely exist

### Evidence Strength
Practitioner consensus with a growing case-study base (Skelton & Pais, industry adoption since 2019); causal evidence is thin — treat it as a design vocabulary with sensible defaults and explicit trade-offs, not a tested theory of organizational performance.

### Source
Matthew Skelton & Manuel Pais, *Team Topologies* (2019); Melvin Conway, "How Do Committees Invent?" (1968). Admission verdict: **Build** (v0.1.12) — leadership held hiring, motivation, and change entries but no org-structure design method; engineering held system-boundary design but not team-boundary design.

## Category Guide
## Leadership

**When to use**: Need to make judgments on team motivation, talent density, organizational capability


### Minimum Information Requirements per Methodology

- **Reality Distortion Field**: Clear goal + team's current belief state + exit conditions
- **A-Player Density**: A-player behavior standard definition + existing team evaluation data + hiring/termination mechanisms
- **Change Management**: Clear change objective + organizational readiness assessment + stakeholder list
- **Team Topologies**: Requires current team inventory + ownership scope + honest cognitive-load self-report

### Routing Trigger Signals

- "Team self-limiting / feels impossible" → Reality Distortion Field (primary)
- "Selling vision / fundraising pitch / rally speech" → Reality Distortion Field (primary)
- "Hiring standards / team quality decline / talent density" → A-Player Density (primary)
- "Performance management / termination mechanism / team building" → A-Player Density (primary)
- "Organizational change / cultural transformation / change execution" → Change Management (primary)
- "Org structure / team boundaries / platform team scope / too many cross-team dependencies" → Team Topologies (primary) ⚡ If the binding constraint is individual capability → use A-Player Density; if designing the software side of the boundary → use Domain-Driven Design (Engineering)

### Common Combinations

- **Team breakthrough**: A-Player Density (ensure talent density) → Reality Distortion Field (drive breakthrough) → Change Management (solidify results)
- **Organizational expansion**: A-Player Density (hiring standards) → McKinsey 7S (organizational alignment)
- **Organizational change**: Stakeholder Mapping (stakeholder analysis) → Change Management (Kotter 8-step execution) → OKR (change goal tracking)
