# Engineering (compact aggregate)
> Aggregated from `references/engineering/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh engineering "<methodology>"`

## TDD Red-Green-Refactor
> source: tdd-red-green-refactor.md
### Core Concept
Test-Driven Development cycle: Red (write a failing test) → Green (write minimal code to pass) → Refactor (clean up while keeping tests green). Ensures every line of code has a test and the codebase stays clean.

### Applicable Scenarios
✅ **Best for**
- Frequent regression bugs
- Refactoring without safety nets
- Building confidence in code changes

⚠️ **When NOT to use**
- Exploratory spikes and throwaway prototypes — the tests would fossilize code you intend to rewrite; write tests when the spike graduates
- UI layout and visual work — pixel-level assertions are brittle; use visual regression or human review instead
- Legacy code with no test infrastructure — build the smallest testing seam first; strict TDD from an untestable start fails on contact

### Key Steps
1. **Red**: Write a test that describes the next behavior you want. Run it — it should fail.
2. **Green**: Write the minimum code to make the test pass. No more.
3. **Refactor**: Clean up the code. Remove duplication. Improve naming. All while keeping tests green.
4. Repeat the cycle for the next behavior.
5. Run the full test suite after each cycle to catch regressions.

### Output Template

```
Behavior: [calc_discount applies 5% over 50 items]

RED  — test_order.py::test_discount_over_fifty   → FAILED (no discount logic) ✓ expected failure
GREEN — Order.calc_discount: minimum implementation → test PASSES (1/1)
REFactor — extract DISCOUNT_THRESHOLD constant, drop duplication → all tests still green

Cycle log: [n cycles this session, each red→green verified — never green-first]
Suite: full run after cycle [n] — 42 passed
Deferred behaviors: [list, each will get its own red test]
```

### Failure Modes
- Green-first: writing the implementation then a test that passes immediately — the test never proved it can fail → assert the red step every cycle; a test that never failed proves nothing
- Test-after drift: "tests coming later" — later never comes under deadline → the cycle log makes skipped reds visible; count them honestly
- Mocking the subject: over-mocked tests that verify the mock, not behavior → test observable outputs of real units; if everything must be mocked to test one thing, the design is the smell

### Evidence Strength
Mixed — controlled and quasi-experiments on TDD show consistently higher test coverage and often better external quality, with mixed or neutral results on development speed (and noticeable setup cost for teams new to it); the discipline's clearest support is for regression safety during refactoring, its stated strength here.

### Source
Kent Beck, *Test-Driven Development: By Example* (2002).

## Bite-Sized Plan
> source: bite-sized-plan.md
### Core Concept
Every step should be 2-5 minutes, with no placeholders, exact file paths, and a Self-Review 3-check. Plans so small that both agents and humans can execute them without ambiguity.

### Applicable Scenarios
✅ **Best for**
- Agent-executable plans
- Complex task decomposition
- Reducing implementation errors

⚠️ **When NOT to use**
- Exploratory work where the next step depends on what you learn — decomposition beyond the known horizon invents fiction; plan the spike, not the whole journey
- One-line changes — writing the plan costs more than doing the work
- Steps that are inherently long (training runs, installs) — 2-5 minutes is about verifiable units of change, not wall-clock; wrap long operations with their own verification step

### Key Steps
1. Break the task into steps of 2-5 minutes each
2. Each step must have: exact file path, exact code change, no placeholders
3. Self-Review 3-checks: Does it compile? Does it pass existing tests? Does it match the intent?
4. If a step needs more than 5 minutes, break it further
5. Execute steps sequentially; verify after each step

### Output Template

```
Goal: [one sentence]

Step 1 — [verb + target]
  File: src/services/order.py (function calc_total, lines 42-58)
  Change: [exact change described, no "..." placeholders]
  Verify: pytest tests/test_order.py::test_calc_total passes

Step 2 — [next verifiable unit]
  File: ...
  Change: ...
  Verify: [command] exits 0

Self-Review 3-check after each step: ① compiles ② existing tests green ③ still matches intent
Abort rule: any step that cannot be verified → stop, don't improvise past the plan
```

### Failure Modes
- Placeholder rot: steps like "refactor the handler as needed" — the executor invents the details → every step names files and the exact change; if you can't write it, you haven't finished decomposing
- Verification skipped under momentum: three steps executed before the first check → a failed step 1 poisons steps 2-3; verify after every step, no exceptions
- Over-decomposition: 40 micro-steps for a 30-minute task — plan maintenance exceeds execution → right-size at the verifiable-unit level; merge steps that share one verification

### Evidence Strength
Practitioner consensus — aligned with widely observed agent-failure modes (ambiguity compounds across steps; unverifiable steps get hand-waved); no controlled studies quantify error reduction, and the 2-5 minute constant is a practical convention rather than a calibrated optimum.

### Source
Agent workflow optimization methodology; bite-sized execution patterns.

## Code Review Checklist
> source: code-review-checklist.md
### Core Concept
4-dimension checklist-driven review: Security / Architecture / Performance / Maintainability. Structured review process that catches issues systematically rather than relying on reviewer intuition.

### Applicable Scenarios
✅ **Best for**
- Pre-merge quality gate
- Refactoring impact assessment
- Team code quality standards

⚠️ **When NOT to use**
- Automated checks already cover an item (linters, SAST) — the checklist re-runs what the pipeline proves; reserve human attention for what tools can't see
- Trivial PRs (docs, comment fixes) — full 4-dimension review on a typo PR trains reviewers to skim
- As a substitute for design review — a checklist reads diffs; it cannot judge whether the design should exist

### Key Steps
1. **Security**: hardcoded secrets? SQL injection? XSS? Auth/authz bypass? Input validation?
2. **Architecture**: correct layer? Dependency direction? Interface contract? Error handling?
3. **Performance**: N+1 queries? Unnecessary allocations? Missing indexes? Blocking calls?
4. **Maintainability**: clear naming? Appropriate abstraction? Test coverage? Documentation?
5. Score each dimension; block merge on critical issues

### Output Template

```
PR: [title] — size [n LOC] — risk [low/med/high]

| Dimension      | Findings                                    | Severity    |
| -------------- | ------------------------------------------- | ----------- |
| Security       | [new endpoint missing authz check L88]      | blocking    |
| Architecture   | [helper placed in wrong layer]              | fix now     |
| Performance    | [N+1 in list endpoint — pre-existing]       | note        |
| Maintainability| [test covers happy path only]               | fix now     |

Verdict: [block / approve-with-nits / approve]
Scope check: did the review cover what tools can't (intent, boundary cases, contract drift)? [answer]
```

### Failure Modes
- Checklist fatigue: 30 items ticked "ok" in 90 seconds — box-ticking reads nothing → for large PRs, assign dimensions across reviewers; for small PRs, only the touched dimensions
- Nit avalanche: style comments bury the one blocking finding → findings must carry severity; blocking findings lead the review, style goes to automation
- Review as gatekeeper vs teacher: everything returned as "wrong" → classify findings: must-fix vs should-fix vs taste; taste items default to the author

### Evidence Strength
Practitioner consensus — code review itself has decent practitioner evidence for defect detection (and for knowledge transfer), while checklists demonstrably help reviewers cover systematically (aviation-derived principle); but over-long checklists degrade attention, and no specific 4-dimension weighting is validated — keep the list short and let machines carry what they can.

### Source
Code review best practices; Google engineering practices.

## Refactoring Patterns
> source: refactoring-patterns.md
### Core Concept
Code smells → refactoring techniques mapping + small-step improvement under test protection. Systematic approach to improving code quality without breaking functionality.

### Applicable Scenarios
✅ **Best for**
- Legacy code improvement
- Large function/class decomposition
- Code quality maintenance

⚠️ **When NOT to use**
- Code with no tests and no seams — writing characterization tests is step zero; refactoring without them is gambling with production
- The module is scheduled for deletion or rewrite — polish invested in dead code is waste
- Rewrites disguised as refactoring: if behavior is changing, that's redesign — scope and review it differently

### Key Steps
1. Identify code smells (long method, god class, feature envy, data clumps, etc.)
2. Map each smell to the appropriate refactoring technique
3. Ensure test coverage exists before refactoring
4. Apply refactoring in small steps; run tests after each step
5. Verify: behavior unchanged? Complexity reduced? Readability improved?

### Output Template

```
Target: [module/function] — smell inventory:
  | Smell                | Where            | Technique                 |
  | Long method          | process() L40-220| Extract Function          |
  | Data clumps          | (user, email, …) | Introduce Parameter Object|
  | Duplicated condition | 4 sites          | Extract + polymorphism    |

Safety: tests present [y — n cases, incl. characterization tests for untested paths]
Step plan: extract helper (tests green) → move query logic (green) → rename (green) — commit per green step
Done check: behavior identical (tests untouched and passing) / complexity [metric: length, nesting depth, coupling] down / reviewable in [n] small commits
Explicitly deferred: [smells needing design decisions — not smuggled into this pass]
```

### Failure Modes
- Refactoring without a behavior net: "tests after" — every intermediate step is unverifiable → characterization tests first; if the code is untestable, start there
- Smell-hunting as aesthetics: renaming and reshaping by personal taste, calling it cleanup → every refactor must name the smell and the measurable outcome; taste-only changes stay out
- Big-bang "refactor" branches: weeks long, merge conflicts, behavior drift → small steps, each green, each committed; a refactor branch older than days is a rewrite in disguise

### Evidence Strength
Practitioner consensus — the smell/technique catalog is the standard reference in the field, and small-steps-under-tests is core discipline across method schools; empirical claims that refactoring improves maintainability are supported in studies but modest, and the catalog itself is descriptive craft knowledge, not a validated taxonomy.

### Source
Martin Fowler, *Refactoring* (1999, 2nd ed. 2018).

## Git Workflow Strategies
> source: git-workflow-strategies.md
### Core Concept
Strategy selection matrix: Trunk-Based Development (fast, CI-dependent), GitHub Flow (simple, PR-based), Git Flow (release branches, complex), GitLab Flow (environment branches). Choose based on team size, release cadence, and CI maturity.

### Applicable Scenarios
✅ **Best for**
- Team branching strategy selection
- Multi-environment release processes
- CI/CD maturity alignment

⚠️ **When NOT to use**
- The real question is how builds get promoted and verified — gates, environment promotion, rollback → **CI/CD Pipeline Design** owns that; branching is one input to it, not the decision
- A team of one or two, or a project with no shared release train — every multi-branch model adds merge and coordination work nobody has time for → trunk-based with short-lived feature branches is the only realistic choice
- Review quality and coding standards are the open problem → **Code Review Checklist** addresses that directly; a new branching model will not improve what reviewers miss
- A monorepo where different teams release independently → the strategy is decided per repo scope by the release tooling, and a single team-wide convention is the wrong unit of decision

### Key Steps
1. Assess: team size, release cadence, CI/CD maturity
2. Choose strategy:
   - **Trunk-Based**: small teams, fast CI, continuous deployment
   - **GitHub Flow**: simple PR-based, good for SaaS
   - **Git Flow**: release branches, good for versioned software
   - **GitLab Flow**: environment branches (dev/staging/prod)
3. Define branch naming conventions
4. Set up branch protection rules
5. Document the workflow for the team

### Output Template

```
Team: [n devs, n reviewers, shared repo?]   Release cadence: [continuous | weekly | monthly | on-demand]
CI maturity: [required suite duration, flaky rate, required checks configured?]

Strategy: [Trunk-Based | GitHub Flow | Git Flow | GitLab Flow]
  Why: [team size + cadence + CI maturity → this model]
  Rejected alternative: [name] — because: [one line]

Branch naming: [type/short-description — e.g. feat/checkout-retry]
Lifecycle: branch from [base] → merged into [base] → deleted [when]
Protected branches: [main, release/*]
Required checks: [lint, unit, build] — must complete in under [n] minutes
Environment branches (if any): [dev → staging → prod], promoted by [role]
Release flow: [tag format] → [artifact produced] → [published where]
Hotfix path: [branch from] → [merge back to] → [how it is verified]
Enforcement: [platform rules: naming, protection, required checks — not a wiki]
```

### Failure Modes
- Process heavier than the team: the chosen model demands merge coordination, release managers, or branch ceremonies nobody has time for → pick the model whose rituals the team can actually sustain; small teams should not run Git Flow
- Git Flow on a continuously deployed product → long-lived release branches accumulate conflicts, and every hotfix must be cherry-picked back into trunk → use trunk-based or GitHub Flow unless you genuinely ship versioned, supportable artifacts
- Branch protection combined with a slow CI, so reviewers wait and start merging around the pipeline → keep required checks under a few minutes and treat check duration as a blocking metric
- The strategy documented but not enforced — no naming rules, no protection, no required checks — so it decays within weeks → configure naming, protection, and required checks mechanically in the hosting platform; a convention nobody can violate is a wish
- No emergency hotfix path, so the hotfix branch is improvised during an outage → write the hotfix procedure down in advance, together with **Incident Response & Postmortem**

### Evidence Strength
Mixed — the four models are the standard vocabulary and their trade-offs are well described in practitioner literature, but comparative evidence that any one of them produces better delivery speed or defect rates is limited and mostly observational; in practice most teams labeled as using a given model run a modified version, so the label predicts less than the documentation implies.

### Source
Git workflow comparison; Atlassian Git tutorials; GitHub Flow documentation.

## Dependency Management
> source: dependency-management.md
### Core Concept
Introduction assessment + version strategy + security monitoring + health audit. Systematic approach to managing third-party dependencies throughout their lifecycle.

### Applicable Scenarios
✅ **Best for**
- Dependency selection decisions
- Vulnerability response
- Dependency health audits

⚠️ **When NOT to use**
- A known-vulnerable dependency with a published fix — this framework decides policy; an emergency upgrade doesn't wait for an audit cycle
- Vendored/internal-only code — external-dependency hygiene (registry trust, license checks) applies differently
- Standard-library available — the best dependency assessment for a small utility is often "don't add it"

### Key Steps
1. **Evaluate before adding**: necessity, maintenance status, license, security track record
2. **Version strategy**: pin to major.minor; use lock files; automate updates
3. **Security monitoring**: integrate dependency vulnerability scanning in CI
4. **Health audit**: quarterly review of dependency health (outdated, unmaintained, vulnerable)
5. **Removal plan**: for each dependency, know how to replace it if needed

### Output Template

```
Add/drop decision record:
  Candidate: [lib v2.3] — need: [what it does that we can't cheaply build]
  Health: last release [date], open issues [n/age], maintainers [n], downloads trend [↗]
  License: [MIT/Apache — compatible? y] — transitive deps: [n, any red flags]
  Security: [known CVEs: none/advisories]
  Exit plan: [how we'd replace it — wrapper layer? y/n]

Policy in force: pin [major.minor], lockfile committed, updates via [renovate/dependabot] with [test gate]
Quarterly audit: [n outdated / n unmaintained >12mo / n with CVEs] → actions: [upgrade / wrap / plan exit]
```

### Failure Modes
- Addition-by-convenience without exit thinking: six months later the un-wrapped library owns your data layer → wrap heavyweight dependencies behind your own interface where swap risk is real
- Pin-and-forget: versions frozen "for stability", security updates never land → automated updates with test gates; pinning is for reproducibility, not for freezing
- Audit as spreadsheet: the quarterly review finds issues and records them without actions → every red health flag gets an owner and a date, or the audit is inventory, not management

### Evidence Strength
Practitioner consensus — the practices (lockfiles, automated updates, CI scanning, license checks) are industry-standard and align with OWASP guidance; quantitative claims about optimal cadences are thinner, and the deep dependency-graph problem (transitive risk) remains only partially addressable by any policy.

### Source
Dependency management best practices; OWASP dependency check guidelines.

## Typed Service Contracts
> source: typed-service-contracts.md
### Core Concept
Design service boundaries using: Spec & Handler pattern + Design by Contract (pre/post conditions) + Result Monad (no exceptions) + Parse don't validate (type-safe data). Creates compile-time guarantees at service boundaries.

### Applicable Scenarios
✅ **Best for**
- Service boundary contract design
- Boundary error defense
- API design between services

⚠️ **When NOT to use**
- Rapid prototyping where shapes change daily — type ceremony slows the exploration it should serve; introduce contracts when shapes stabilize
- Scripts and glue code inside one trust boundary — internal helpers with known-good inputs don't need boundary parsing
- As a substitute for runtime contract tests — types prove shape, not behavior; cross-service compatibility still needs tests

### Key Steps
1. Define the service interface as a typed Spec (input/output types)
2. Add pre-conditions (what must be true before calling) and post-conditions (what is guaranteed after)
3. Use Result types instead of exceptions for error handling
4. Parse input data into typed structures at the boundary (Parse don't validate)
5. Implement the Handler that satisfies the Spec

### Output Template

```
Spec: CreateOrder
  Input  (parsed once at boundary): { user_id: UserId (validated), items: NonEmptyVec<LineItem>, coupon?: CouponCode }
  Output (Result): Ok(OrderConfirmed) | Err(OutOfStock(sku)) | Err(PaymentDeclined(reason)) | Err(InvalidCoupon(code))

Pre-conditions: [caller authenticated; idempotency key provided]
Post-conditions: [order persisted exactly once; event OrderPlaced published]

Parse don't validate:
  raw JSON → parse into typed structs at the edge (fail fast with field-level errors)
  inside the handler: no re-checking, types guarantee shape — business checks return typed Err only

Handler satisfies Spec — compiler enforces: all Err variants handled by caller; no silent exceptions
Contract test: [spec examples covering each Err variant, run against both sides of the boundary]
```

### Failure Modes
- Boolean blindness: validate() returning bool then re-parsing downstream — the check and the use live in different worlds → parse into types that make invalid states unrepresentable; validation without construction is theater
- Exception leaks across the boundary: "typed contract" that still throws deep inside — every throw is an untyped error path → map all internal errors to the Result at the edge
- Contract rot: Spec updated, handler drifts, callers crash at runtime → Spec and Handler in one compiled unit, plus contract tests in CI; a stale contract is worse than none

### Evidence Strength
Practitioner consensus — the underlying ideas (Design by Contract, algebraic error types, parse-don't-validate) are well argued and widely adopted in type-rich ecosystems; evidence of defect reduction comes mostly from practitioner experience and language-level studies, not controlled trials, and payoff shrinks for small or rapidly churning boundaries.

### Source
Functional programming patterns; Design by Contract (Bertrand Meyer); Parse don't validate (Alexis King).

## Agent DX / CLI Scale
> source: agent-dx-cli-scale.md
### Core Concept
7-axis 0-3 scoring system for CLI/SDK agent friendliness: Machine-Readable output, Raw Payload access, Schema availability, Context richness, Hardening (error handling), Safety (idempotency), Knowledge (documentation). Higher scores mean better AI agent integration.

### Applicable Scenarios
✅ **Best for**
- CLI/SDK agent friendliness assessment
- API design for AI integration
- Developer experience improvement

⚠️ **When NOT to use**
- A CLI that humans are the only consumers of — the rubric rewards machine-readability, so a well-designed human tool scores low and the team optimizes against a nonexistent agent → **Agent DX / CLI Scale** only pays off once a named agent or script actually calls the surface
- Network interface contract work — this scores the output shape of a command, not the service contract behind it → **API Design** / **Typed Service Contracts**
- Ranking two toolchains by the 0-21 total — the sum treats seven axes as interchangeable, but a zero on Safety (unsafe writes) outweighs a three on Schema → score per axis against the agent's actual failure, never rank on the total
- Internal tooling with a handful of invocations — there is no repeated agent interaction to amortize the hardening work

### Key Steps
1. For each of the 7 axes, score the CLI/SDK 0-3:
   - **Machine-Readable**: Does it output JSON/structured data? (0=human only, 3=full JSON)
   - **Raw Payload**: Can agents access raw data? (0=formatted only, 3=raw+formatted)
   - **Schema**: Is output schema documented? (0=none, 3=JSON Schema + examples)
   - **Context**: Does output include enough context for agents? (0=minimal, 3=self-describing)
   - **Hardening**: Error handling quality (0=crash, 3=structured errors with recovery hints)
   - **Safety**: Idempotency and side-effect management (0=unsafe, 3=fully idempotent)
   - **Knowledge**: Documentation quality for agents (0=none, 3=agent-optimized docs)
2. Calculate total score (0-21)
3. Identify lowest-scoring axes for improvement
4. Prioritize improvements by agent impact

### Output Template

```
Tool: [name / version]      Consumer: [which agent or script calls it]

Axis scores (0-3):
  Machine-Readable: [0-3 — JSON on stdout, human text on stderr]
  Raw Payload:      [0-3 — raw access via --format=json / --output=file]
  Schema:           [0-3 — JSON Schema published at [url], with examples]
  Context:          [0-3 — self-describing: ids, units, timestamps, pagination]
  Hardening:        [0-3 — structured errors, distinct exit codes, recovery hints]
  Safety:           [0-3 — idempotency key on write commands / N-A for read-only]
  Knowledge:        [0-3 — usage doc written for agents, copy-paste examples]
Total: [n/21]   Weakest axis: [axis]   Evidence: [failed agent run that exposed it]

Priority fix: [axis] → [concrete change] → [agent behavior improves: fewer retries / no ad-hoc parsing]
```

### Failure Modes
- Self-assessment inflation: the team scores its own CLI after building it, and every axis reads 2 or 3 → have an agent, or a reviewer outside the team, score it from the published docs and the raw output only
- Machine path built for no consumer: a JSON mode nobody invokes gets added to raise the score → ship the machine path only after naming the agent that will call it and the command it will run
- Safety scored on read-only commands → a read-only CLI is docked for lacking idempotency, which is not a real defect → score Safety only where the command has side effects, and mark the rest N-A
- Fixing the lowest-scoring axis because it is lowest → effort goes to a missing schema while the axis that actually broke the agent run is ignored → pick the axis from the recorded failed run, not from the scoreboard

### Evidence Strength
Practitioner consensus — the underlying interface practice (machine-readable output, raw payload access, idempotency on writes) is long-established and widely endorsed, but this particular rubric is a recent popularization with little independent validation; the 0-3 scale and the implicit comparability of its axes are conventions, not measured properties, so a total score should be read as a conversation starter rather than a measurement.

### Source
Agent-first design methodology; CLI/SDK agent experience framework.

## Agent Autonomy & Runtime Design
> source: agent-autonomy-design.md
### Core Concept
The workflow-vs-agent decision: a **workflow** orchestrates LLM steps through predetermined code paths (predictable, cheap, testable); an **agent** lets the LLM direct its own tool-use loop (flexible, costly, harder to verify). Choose the **least autonomous design that works** — autonomy is a cost you pay in reliability and verifiability, not a feature. Between the two sit composable patterns of increasing autonomy: prompt chaining → routing → parallelization → orchestrator-workers → evaluator-optimizer. Autonomy is granted per action, not per agent: read-only actions run free, irreversible actions get a human checkpoint.

### Applicable Scenarios
✅ **Best for**
- Deciding whether a task needs an agent at all, or a fixed pipeline suffices
- Choosing the orchestration pattern and where human checkpoints sit
- Setting the autonomy dial per action (read / mutate / irreversible)
- Structuring tool surfaces and injection defenses before the first deploy

⚠️ **When NOT to use**
- Choosing between agent frameworks (langgraph / crewai / autogen vs roll-your-own) → **diting** owns framework selection (recorded no-route in this repo's trigger queries); this entry decides *whether and how autonomous*, which precedes framework choice
- Reviewing the code of an already-built agent → **diting** (Engine A, code quality)
- Authoring ZCode multi-subagent workflow scripts → **dynamic-workflows** skill
- Scoring a single tool's output shape (CLI readability) → **Agent DX / CLI Scale**
- Threat modeling the surrounding system → **Security by Design**; this entry covers runtime injection defense for the agent loop itself
- One LLM call with no tools and no branching → there is no runtime to design

### Key Steps
1. Decompose the task: can it be expressed as fixed steps with known inputs? If yes, build the workflow and stop — the agent question is answered
2. If the path genuinely cannot be predetermined (open-ended inputs, unknown step count), select the composable pattern of least autonomy that covers it: chaining → routing → parallelization → orchestrator-workers → evaluator-optimizer
3. Set the autonomy dial per action: **read-only** (run free), **mutable-but-reversible** (run with logging), **irreversible** (send, pay, delete, publish — human checkpoint before execution)
4. Define the tool surface: each tool is one clear action with typed parameters and a documented failure mode; no kitchen-sink tools
5. Ground every observation: tool output, web content, and file contents are **untrusted data**, never instructions (prompt-injection defense; OWASP LLM Top 10) — quote, delimit, and never let retrieved text issue commands
6. Set stop conditions and budgets: max iterations, max tool calls, max spend, and a "return partial result with what blocked you" exit — an agent without an exit is a loop with a personality
7. Instrument for evals from day one: log every trajectory; route failures into the golden set (**LLM Output Evals**)

### Output Template

```
Task: [one sentence] → Verdict: [workflow | agent + pattern] — because [the path is / is not predetermined]
Autonomy table:
  [action] — [read-only | reversible | irreversible] — checkpoint: [none | log | human-approve]
Tools: [name — one action — typed params — failure mode]
Injection defense: [retrieved content delimiting rule | confirmation gate on tool output]
Limits: max iterations [n], max tool calls [n], budget [cost], stop condition [predicate]
Eval plan: [golden set source, gate criterion → LLM Output Evals]
Deferred to diting: [framework choice | built-code review]
```

### Failure Modes
- Agent for everything: the default answer to "could this be an agent?" is almost always "no, it's a pipeline" → run step 1 honestly; the workflow you didn't build is test coverage you didn't lose
- Autonomy creep: a read-only tool grows a write side, and the old dial silently grants it → re-run the autonomy table on every tool change; the dial attaches to actions, not agents
- Missing human checkpoint on irreversible actions: the agent emails the customer / merges the branch / charges the card → anything irreversible or outbound gets a gate, no exceptions for "it usually gets it right"
- Injection through observations: web content or command output containing instructions that the loop obeys → delimit retrieved text as data; instructions arrive only from the operator
- No exit: max iterations unset, the agent wanders or cycles → budgets and stop conditions are part of the design, not runtime hopes
- Kitchen-sink tools: one tool that does five things defeats the autonomy dial (which action is being approved?) → split until each tool is one auditable action
- Framework-first design: picking langgraph before deciding the task needs an agent → the decision precedes the framework; record both in the design record
- Evals bolted on later: no trajectory logging until the first incident → instrument at build time; every failure should feed the eval set

### Evidence Strength
**Mixed, strengthening.** The workflow-vs-agent decision and the composable patterns are practitioner consensus from high-scale agent builders (Anthropic 2024) and align with the ReAct loop literature (Yao et al., ICLR 2023); the injection-threat taxonomy is codified (OWASP Top 10 for LLM Applications). The field moves fast: specific defense techniques and pattern names evolve, while the underlying decision discipline — least autonomy that works, per-action checkpoints, untrusted observations — is stable. Grade the decision framework strong, specific defenses evolving.

### Source
Anthropic, "Building Effective Agents" (2024); Yao et al., "ReAct: Synergizing Reasoning and Acting in Language Models" (ICLR 2023); OWASP Top 10 for LLM Applications (2025). Admission verdict: **Build** (v0.1.16) — ranked second by the independent necessity audit: `agent-dx-cli-scale.md` scores tool output surfaces ("this scores the output shape of a command, not the service contract behind it"), not runtime design; diting owns review of built agents and framework selection (recorded no-route); dynamic-workflows owns ZCode workflow scripts. The design-time "whether and how autonomous" question was unowned.

## Clean Architecture
> source: clean-architecture.md
### Core Concept
Dependency inversion layering + Port & Adapter pattern + domain layer with zero external dependencies. The core business logic depends on nothing; everything else depends on the core.

### Applicable Scenarios
✅ **Best for**
- New project architecture design
- Framework/database replacement
- Long-term maintainability

⚠️ **When NOT to use**
- CRUD apps with logic too thin to justify a domain layer — the indirection cost exceeds the replaceability benefit
- Small teams/short-lived services — the structure tax is paid every day; the swap benefit may never arrive
- When the "domain" is actually a thin skin over someone else's API — there are no business rules to protect

### Key Steps
1. Identify the domain entities and business rules (core)
2. Define ports (interfaces) for external interactions
3. Implement adapters that connect external systems to ports
4. Enforce dependency rule: dependencies point inward (toward domain)
5. The domain layer must not import any framework, database, or UI code

### Output Template

```
layers/
  domain/        # entities, business rules — zero external imports (enforce in CI: import-linter)
    order.py     # Order, PriceCalculator
  ports/         # interfaces the domain needs, owned by the domain side
    order_repo.py      # OrderRepo (abstract)
    payment_gateway.py # PaymentGateway (abstract)
  adapters/      # implementations of ports, pointing inward
    postgres_order_repo.py
    stripe_gateway.py
  app/           # composition root + framework glue

Dependency check: domain imports nothing from adapters/app/frameworks — violation fails build
Business rule example (lives in domain): [an order with >50 items gets 5% discount] — testable with zero mocks of frameworks
```

### Failure Modes
- Anemic domain, fat use-cases: the "domain" holds data classes while all logic sits in application services — inversion without benefit → push actual business rules into the core or admit the app doesn't need this architecture
- Ports sprawl: an interface per repository per future swap that never happens → add ports where change is plausible (payments), skip them for stable infrastructure
- Mock cascade in tests: every test mocks six adapters to reach one rule → tests for domain rules should construct domain objects directly; if they can't, logic has leaked outward

### Evidence Strength
Practitioner consensus — dependency inversion itself is a well-established design principle with strong practitioner adoption; comparative evidence that layered architectures outperform simpler ones on delivery speed is actually mixed (some studies associate extra indirection with slower early delivery), so the payoff claim rests on lifecycle length and change patterns, not on universal superiority.

### Source
Robert C. Martin, *Clean Architecture* (2017).

## Domain-Driven Design
> source: domain-driven-design.md
### Core Concept
Model complex business systems using: Bounded Contexts (clear boundaries), Aggregate Roots (consistency boundaries), Ubiquitous Language (shared terminology), and Event Storming (collaborative discovery).

### Applicable Scenarios
✅ **Best for**
- Complex business system modeling
- Microservice boundary definition
- Aligning technical and business domains

⚠️ **When NOT to use**
- Simple domain, simple rules — DDD patterns on a CRUD app bury logic in ceremony
- The business experts can't be engaged (no access to domain owners) — the language work is the method; without it you're doing guesswork with extra patterns
- Teams new to the domain AND to DDD simultaneously — learning two unknowns at once fails for both

### Key Steps
1. **Event Storming**: gather domain experts; map domain events on a timeline
2. Identify Bounded Contexts: group related events and entities
3. Define Aggregate Roots: entities that ensure consistency within a context
4. Establish Ubiquitous Language: same terms in code, docs, and conversation
5. Define Context Maps: how bounded contexts interact

### Output Template

```
Domain: [e-commerce fulfillment]

Bounded contexts: [Ordering] [Inventory] [Shipping]
  Ordering: aggregate root [Order] — invariants: [total = Σ lines; cannot ship while unpaid]
    Ubiquitous terms: [Order, LineItem, PaymentConfirmed — one meaning, code+talk]
  Inventory: aggregate [StockItem] — invariant: [never negative]
Context map: Ordering →(OrderPlaced event)→ Inventory; Shipping ←(PaymentConfirmed)← Ordering

Event log (from storming): [OrderPlaced → PaymentConfirmed → StockReserved → Shipped]
Integration style per boundary: [events / shared kernel (avoid) / ACL]
Term-drift watchlist: ["customer" means X in Ordering, Y in Shipping → rename to distinct terms]
```

### Failure Modes
- DDD as class diagram: applying entities/repositories while skipping language and boundaries — the parts that carry the value → if no domain expert was in the room, it isn't DDD yet
- Wrong aggregate lines: aggregates too large (one root for the whole order+customer+inventory world) cause lock storms and transactional pain → draw aggregates around invariants, not around nouns
- Shared kernel creep: contexts drift back into one database/one model "temporarily" → integration only through published events or explicit contracts; model drift is the smell to surface, not hide

### Evidence Strength
Practitioner consensus with case-based support — strategic patterns (bounded contexts, ubiquitous language) are widely credited in complex-domain success stories, but controlled evidence is scarce and failures from over-application are common; best supported as a complexity-matching tool, weakest when applied to simple domains.

### Source
Eric Evans, *Domain-Driven Design* (2003).

## Microservices Patterns
> source: microservices-patterns.md
### Core Concept
Distributed system patterns: Saga (distributed transactions), CQRS (command-query separation), Event Sourcing (state as event log), plus service governance and resilience patterns.

### Applicable Scenarios
✅ **Best for**
- Monolith decomposition
- Distributed data consistency
- Service governance

⚠️ **When NOT to use**
- One team, one deployable, modest traffic → splitting adds network failure modes, distributed data, and coordination cost with no scaling payoff; keep the monolith until a measured constraint forces the split
- Boundaries are not understood yet → **Domain-Driven Design** (bounded contexts, event storming) has to come first, because patterns applied to arbitrary seams encode the wrong decomposition
- The problem is structure inside a single service — layers, coupling, big functions → **Clean Architecture** or **Refactoring Patterns** address that without adding a network hop
- The real constraint is throughput at one stage → **Theory of Constraints** locates the binding stage first, because distributing a flow does not raise its total throughput

### Key Steps
1. Identify service boundaries (use DDD bounded contexts)
2. Choose data consistency pattern: Saga (choreography or orchestration) for distributed transactions
3. Apply CQRS: separate read and write models where query patterns differ from write patterns
4. Consider Event Sourcing: store state changes as events for full audit trail
5. Implement resilience patterns: circuit breaker, retry, bulkhead, fallback
6. Set up service governance: service discovery, API gateway, health checks

### Output Template

```
Decomposition:
  Service: [name] — bounded context: [context] — owner team: [team] — data owned: [store/tables]
  Depends on: [service] via [sync call | event]
  Why this is a separate service: [scale | ownership | release independence]

Consistency pattern: [Saga (orchestration) | Saga (choreography) | CQRS | Event Sourcing | none]
  Why: [the specific failure it prevents]
  Steps: [S1 → S2 → S3]   compensation per step: [undo S1]   timeout per step: [x s]
  Event contract: [name, version, schema owner, compatibility rule]
  Projection: [read model, rebuild procedure, tolerated lag]

Resilience per remote hop:
  timeout [x s] | retry [max n, backoff] | circuit breaker [opens after n failures] | bulkhead [pool size] | fallback [behavior]
  Retry safety: [idempotent | not idempotent — how duplicates are handled]

Governance:
  discovery: [mechanism]   gateway: [routing, auth, rate limit]   health: [liveness / readiness endpoints]
  Contract enforcement: [schema validation | consumer-driven tests] — CI gate
  Cross-cutting: [tracing, correlation ids, audit log] — owned by [platform]
```

### Failure Modes
- Pattern shopping: Saga, CQRS, and Event Sourcing adopted together for a simple CRUD domain → each pattern adds operational surface (saga state, projection rebuilds, event versioning) with no payback; adopt one pattern against a named pain or none
- No owning team per service → nobody owns a service's on-call, lifecycle, or schema, so it decays → assign an owning team at decomposition time; an unowned service is a liability
- Event Sourcing without versioning discipline → every producer change breaks consumers → version events, keep readers backward-compatible, and rehearse projection rebuilds before you need them
- Distributed transactions reimplemented as ad-hoc compensations scattered through application code → partial failures leave unrecoverable states → use an orchestrated Saga where each step's compensation is written next to the step itself
- Remote calls treated as local calls inside a request path → latency multiplies and failures cascade → give every hop a timeout, a retry budget, a circuit breaker, and a bulkhead; a remote call without a failure budget is an outage waiting for traffic

### Evidence Strength
Mixed — the individual patterns are precisely specified in practitioner literature and their failure modes are well documented, but comparative evidence that microservice adoption improves delivery speed, reliability, or cost is mixed and frequently points the other way for small systems; the organizational premises behind the pattern set remain contested, and the claimed benefits are usually realized only where service ownership, platform capability, and operational maturity already exist.

### Source
Chris Richardson, *Microservices Patterns* (2018).

## API Design
> source: api-design.md
### Core Concept
RESTful/GraphQL/gRPC protocol selection + version management + idempotency + error response design. Create APIs that are consistent, predictable, and easy to consume.

### Applicable Scenarios
✅ **Best for**
- Interface design
- API standardization
- Version compatibility

⚠️ **When NOT to use**
- The protocol choice is already made by infrastructure reality — gRPC inside a mesh, REST at the edge, GraphQL only because a client cannot express its query another way → the protocol-selection step becomes theater and the useful part is versioning, idempotency, and error shape
- Service boundary questions ("should this be its own service?") → **Domain-Driven Design** / **Microservices Patterns** settle boundaries first; the API inherits them and cannot fix a wrong seam
- Service-to-service contracts where the producer and consumer are both internal and versioned together → a public-style REST contract adds ceremony without a consumer boundary; **Typed Service Contracts** fits internal edges better
- CLI and tool surfaces meant for agents rather than network clients → **Agent DX / CLI Scale** scores the interface an agent actually touches

### Key Steps
1. Choose protocol: RESTful (broad compatibility), GraphQL (flexible queries), gRPC (high performance)
2. Design resource naming (nouns, not verbs for REST)
3. Implement versioning: URL path (/v1/) or header-based
4. Design consistent error responses: status code + error code + message + details
5. Ensure idempotency for write operations (idempotency keys)
6. Document with OpenAPI/Protobuf; provide SDKs

### Output Template

```
API: [name]     Consumers: [service A, partner B, mobile app]     Owner: [team]

Protocol: [REST | GraphQL | gRPC] — why: [client capability, latency budget, ecosystem]

Resources (all under /v1):
  GET    /v1/[resource]        → [200 body shape]
  POST   /v1/[resource]        → [201 body shape]   idempotency: key [header], TTL [24h]
  PATCH  /v1/[resource]/{id}   → [200 body shape]   idempotency: [natural | key]

Versioning: [path /v1 | header] — breaking → [v2], additive → [v1]
Deprecation: [Sunset header date] — old version stays until [date], then removed

Error envelope (same shape on every endpoint):
  { "code": "[MACHINE_CODE]", "message": "[human text]", "details": [...], "trace_id": "[id]" }
  HTTP status: [400] [401] [404] [409] [422] [429] [500] — each mapped to a code

Auth: [scheme + scope model]   Rate limit: [rule]   Pagination: [cursor field]
Contract test suite: [name] — CI gate fails when the schema changes incompatibly
Spec location: [openapi/proto path or url]
```

### Failure Modes
- Versioning decided per client whim, so every consumer negotiates its own scheme → fix one deprecation policy (sunset date plus migration window) and enforce the schema with contract tests, so an incompatible change breaks the build instead of production
- Idempotency keys added to POST only, leaving PATCH and DELETE unsafe to retry → a key helps only if the server persists the outcome and replays the same response; give every state-changing endpoint a key or document which are naturally idempotent
- Error envelopes designed per endpoint, so each client writes its own parser → define one error body and validate it in CI against every endpoint, rejecting anything that drifts
- New version shipped but the old one never retired, so both stay live and both need maintenance → put a removal date in the version itself and check live traffic per version before deleting it
- Spec written by hand and drifting from the implementation, so it is trusted by nobody → generate the spec from the implementation or run its examples as tests; a spec no test consumes is prose

### Evidence Strength
Mixed — REST conventions, resource naming, and error-envelope consistency are among the most widely adopted and best documented interface practices, and versioning and idempotency key mechanisms have solid engineering rationale; the comparative evidence that a particular protocol or versioning scheme yields better outcomes for a given context is weak and largely observational, so protocol choice should follow client constraints rather than a generalized claim.

### Source
REST: Roy Fieldting (2000); API design best practices from industry standards.

## Database Schema Design
> source: database-schema-design.md
### Core Concept
Data modeling + index strategy + safe migration + normalization/denormalization tradeoffs. Design schemas that are correct, performant, and evolvable.

### Applicable Scenarios
✅ **Best for**
- New project data model
- Schema restructuring
- Query optimization

⚠️ **When NOT to use**
- The slowdown is in query code or application logic rather than in the schema → **Performance Optimization** (measure, locate, optimize, verify) finds the real hotspot; reshuffling tables under an unprofiled system moves the cost without removing it
- Ownership and boundaries of the data — which service owns these tables and how they stay in sync → **Microservices Patterns** (Saga, CQRS) decides that, and the schema follows the boundary
- Business entity identity and rules → **Domain-Driven Design** owns the model; an ERD drawn before the domain is settled encodes the wrong nouns and needs redoing
- Greenfield with no real query patterns yet — indexes chosen on guesses add write cost and migration time → instrument first and let **Observability** supply the actual access paths

### Key Steps
1. Identify entities and relationships (ERD)
2. Normalize to 3NF by default; denormalize only for proven performance needs
3. Design indexes based on query patterns (not in advance)
4. Plan migrations: always backward-compatible, use expand-and-contract pattern
5. Add constraints: NOT NULL, UNIQUE, FOREIGN KEY where appropriate
6. Test with realistic data volumes; optimize slow queries

### Output Template

```
Model: [domain area]   Engine: [postgres / mysql]   Volume: [rows today → 12 months]

Entities:
  [entity]  pk [id]  fields [name type null?, ...]  relations [1-N → other.entity]
  [entity]  pk [id]  fields [name type null?, ...]  relations [N-1 → other.entity]
Constraints: NOT NULL [list]   UNIQUE [list]   FK [child.parent_id → parent.id]   CHECK [rule]
Soft delete / history / tenancy: [how rows expire, which columns carry scope]

Normalization: [3NF] — deliberate exceptions: [table, reason]
Indexes (from observed query patterns only):
  [table].[col] — supports [query shape] — plan at prod volume: [index scan | seq scan]
Access paths to protect: [query → expected latency]

Migration (expand-and-contract):
  1 expand  : add [column] nullable; backfill in batches of [n]
  2 migrate : switch [reads/writes] to [new shape]; dual-write window [x days]
  3 contract: drop [old column] after [date]
Rollback per phase: [how to revert at step 1 / step 2]
```

### Failure Modes
- Normalize first and denormalize later without a measured trigger, leaving two copies of the truth → denormalize only against a measured read path, and write down how the copy stays consistent
- One blocking DDL on a large table, taking a lock or a long transaction → use expand-and-contract: add nullable, backfill in batches, switch reads, then drop the old column after a dated dual-write window
- Indexes created for queries that do not exist, costing write throughput and slowing every later migration → derive indexes from observed access paths and check the plan on production-sized data before creating them
- Foreign keys dropped for convenience and never reinstated, allowing orphaned rows nobody notices → keep the constraint; if it must go, replace it with an application check plus a periodic orphan audit
- Schema applied by hand in one environment, so production drifts from the repository → migrations live in the repo and are applied by the pipeline, with the schema version checked at deploy time

### Evidence Strength
Practitioner consensus — normalization, index selection driven by query patterns, and expand-and-contract migration are long-standing, widely taught database practice with strong operational backing; the evidence for any specific normalization target or universal indexing rule is weak and workload-dependent, and modern analytical and distributed stores deliberately violate both, so the default 3NF posture is a starting position rather than a law.

### Source
Database design best practices; Martin Fowler's evolution database patterns.

## TRIZ Contradiction Separation
> source: triz-contradictions.md
### Core Concept
When two required system properties pull in opposite directions, the engineering answer is usually not a midpoint compromise but **separation**: let each state hold in a different time, place, condition, or level of the system. A trade-off you have stopped fighting is still a contradiction — this card resumes the fight with method.

### Applicable Scenarios
✅ **Best for**
- Architecture/API parameters with opposite demands: fresh vs cached, stable vs evolving, thorough vs fast
- You are about to accept a trade-off "because you can't have both"
- Every option in the list shares the same structural weakness — the conflict is in the requirements, not the options

⚠️ **When NOT to use**
- A standard pattern already resolves it (cache-aside, CQRS, feature flags, versioning) — use the pattern; it IS a separation
- One option is simply better — pick it; don't manufacture a contradiction
- A cheap measurement settles which side matters — measure, don't separate
- Real physical law (CAP under partition, bandwidth vs latency) — optimize the compromise honestly or move the goal up a level; never fake a dissolution
- People or organization conflicts — separation targets system parameters

### Key Steps
1. **Name it in template form**: "We need [PARAMETER] to be [STATE_1] for [BENEFIT_1] BUT [STATE_2] for [BENEFIT_2]." If the template won't fit, stop — this card doesn't apply.
2. **State the Ideal Final Result (IFR)**: both benefits, no new machinery, no permanent midpoint sacrifice — reframes the goal from "balance the two" to "make the cost not exist".
3. **Try the four separations in order**, keeping the first that delivers both benefits with no hidden compromise:
   - **Time** — state A at one moment, state B at another
   - **Space** — state A in this component/layer, state B in that one
   - **Condition** — state A under this load/context/risk, state B otherwise
   - **Scale** — state A at the interface/aggregate level, state B at the implementation/element level
4. **If separation alone fails, apply a light transform**: segmentation, prior action, inversion, intermediary, copying, dynamization (config/flags), or up a dimension (metadata, versioning, events) — preferring moves that reuse resources the system already has (existing data, traffic, schedulers, side effects).
5. **Test every candidate for relocation**: did the cost leave the system, or just move (to the user, to later, to tech debt)? Moved = disguised compromise — flag where it went.
6. **Lock the resolution**: state the design change, where each state lives, how each benefit survives — or record the residual trade-off explicitly. Refuse TRIZ theater: running the motions and shipping the midpoint anyway is worse than an honest compromise.

### Output Template

```
Contradiction: [cached data] must be [STALE] for [cheap fast reads]
                         BUT [FRESH] for [correct decisions]
IFR: reads fast and cheap AND decisions see current data
Separation: time ✓ — serve cached on read, refresh on write events/TTL
  (pattern check: this IS cache-aside — adopt the standard pattern)
Test: staleness cost relocated to a bounded TTL window — accepted explicitly
Resolution: [cache-aside + 30s TTL on mutable fields, none on immutable]
Residual trade-off: [≤30s staleness, documented for consumers]

Contradiction: [public API] must be [FROZEN] for [client stability]
                         BUT [FREE TO CHANGE] for [product iteration]
IFR: clients never break AND the implementation evolves daily
Separation: scale ✓ — stable versioned contract at the boundary, freedom inside
Resolution: [API versioning + deprecation policy; internals unconstrained]
Residual trade-off: [none — canonical separation]
```

### Failure Modes
- TRIZ theater: generating separations as decoration, then shipping the midpoint compromise anyway
- Relocation posing as dissolution: "just cache it" still pays the staleness cost — name who eats it before calling it solved
- Vague contradiction, fake resolution: fuzzy states or element → fuzzy separations; the template gate exists for this
- Pattern re-invention: burning an afternoon on a bespoke cache/versioning scheme the standard pattern already does better

### Evidence Strength
Strong for the separation principles — time/space/condition/scale separations demonstrably underlie the most successful system patterns (caching, CQRS, versioning, feature flags), which is why the pattern-first guard matters. The full 40-principle matrix is legacy lookup machinery; judgment over separations is the durable part.

### Source
Genrich Altshuller, TRIZ (Theory of Inventive Problem Solving) — separation principles and ideal final result.
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) `thinking-triz` and [systems-thinking-skills](https://github.com/BayramAnnakov/systems-thinking-skills) `triz-dissolve` (both MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns contradiction separation for design trade-offs; no existing entry structured the trade-off-versus-contradiction move.

## CI/CD Pipeline Design
> source: cicd-pipeline-design.md
### Core Concept
7-stage pipeline: Trigger → Build → Test → Security → Quality → Deploy → Post-Deploy. Each stage has gates that must pass before proceeding. Includes rollback strategies.

### Applicable Scenarios
✅ **Best for**
- Pipeline setup
- Release strategy design
- Quality gates

⚠️ **When NOT to use**
- The pipeline exists but the real constraint is one slow or flaky stage — adding stages to a flow that already queues adds wait time without raising throughput → **Theory of Constraints** locates the binding stage first
- A project that ships a handful of times a year with a small team — a seven-stage gated pipeline costs more waiting than it saves; a release checklist with one smoke test is the honest shape
- Choosing the branch and release model that the pipeline will promote through → **Git Workflow Strategies** owns branching; this entry owns what runs and what gates it
- Defining which security checks to run and what threat they cover → **Security by Design** owns threat modeling; this entry only decides where the gate sits and what blocks the merge

### Key Steps
1. **Trigger**: define what starts the pipeline (push, PR, schedule)
2. **Build**: compile, package, containerize
3. **Test**: unit → integration → e2e (fast to slow)
4. **Security**: SAST, dependency scanning, secret detection
5. **Quality**: coverage gates, lint, static analysis
6. **Deploy**: blue-green / canary / rolling; environment promotion
7. **Post-Deploy**: smoke tests, monitoring, rollback triggers

**Flaky-test triage (Test stage)** — a red gate nobody trusts is worse than no gate:
1. **Quarantine immediately**: move the test out of the blocking path (keep it visible on a dashboard) — a flaky test in the gate trains people to re-run and ignore red
2. **Classify before fixing**: time-dependent (sleeps, clocks) / ordering-dependent (shared state, parallelism) / async race (missing wait) / resource-leaky (ports, files, DB state) — the class picks the fix
3. **Fix or delete, no third option**: flaky tests do not live in quarantine forever — a test not worth fixing is not worth keeping; delete it and note what it was guarding
4. **Re-admit only green×N**: a repaired test re-enters the gate after passing consistently across N runs

### Output Template

```
Pipeline: [service]   Trigger: [push | PR | schedule]   Cadence: [per commit | nightly]
Target: [deploy to prod]   Promotion path: [dev → staging → prod]

Stages (run in parallel where independent):
  Build    : [command], cache key [x], artifact [type/id]        gate: [exit 0]
  Test     : unit [x s] → integration [x s] → e2e [x s]          gate: [all green]
  Security : SAST [tool], deps [tool], secrets [tool]            gate: [0 critical]
  Quality  : coverage [x%] (ratchet from [baseline]), lint [ruleset]   gate: [threshold]
  Deploy   : [blue-green | canary | rolling], canary traffic [x%] for [x min]
  Post     : smoke [check], soak [x min], auto-rollback trigger [metric > threshold]

Rollback: artifact [id] → [previous id]; RTO [x min]; decision owner [role]; drill date [date]
Budget: pipeline p50 [x min], slowest stage [x s] — required checks must finish under [n] min
Flaky triage: quarantined [n] — [test → class → fix-or-delete deadline]; re-admit criterion: [green × N runs]
```

### Failure Modes
- Gates so slow that people route around them, pushing straight to production → keep the blocking path fast enough to wait for, move slow checks to a nightly job, and treat required-check duration as a metric you own
- The seven stages treated as a fixed serial chain → Security and Quality do not depend on each other, so running them in sequence adds pure wait → draw the actual dependency graph and parallelize independent stages
- Thresholds copied from a baseline instead of an intent, so a 20% coverage gate protects nothing → set the gate at a level the team can defend, then ratchet it; a gate nobody believes in is a speed bump, not a safety net
- Rollback written down but never exercised, so the first real rollback is the first execution → run a rollback drill on a schedule against a real artifact, not a doc
- The pipeline is green while the deploy is wrong, because nothing verifies production behavior → define the smoke check and the automated rollback trigger before the first release and wire both to **Observability** metrics

### Evidence Strength
Practitioner consensus — staged pipelines, gated promotion, blue-green and canary deployment, and rehearsed rollback are long-established industrial practice with broad adoption; evidence that any particular pipeline shape or gate count outperforms another is thin, and pipeline effectiveness is dominated by test-suite speed and team discipline rather than by the stage topology this entry prescribes.

### Source
Jez Humble & David Farley, *Continuous Delivery* (2010); modern CI/CD practices.

## Security by Design
> source: security-by-design.md
### Core Concept
STRIDE threat modeling + secure coding patterns + CI continuous verification. Security is built in from the start, not bolted on later.

### Applicable Scenarios
✅ **Best for**
- Security architecture design
- Compliance requirements
- Security hardening

⚠️ **When NOT to use**
- As the only security activity — threat models complement, not replace, penetration testing and incident response readiness
- One-shot compliance theater: a threat model written for the audit and never updated as the system changes → security by design is a cadence, not a document
- Rebuilding everything for imagined attackers before knowing your assets — start from what's valuable and reachable, not from paranoia

### Key Steps
1. **Threat Model**: use STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)
2. **Secure Coding**: apply language-specific secure coding patterns
3. **CI Verification**: integrate SAST, dependency scanning, secret detection into CI
4. **Defense in Depth**: multiple layers of security controls
5. **Regular Audits**: periodic security reviews and penetration testing

### Output Template

```
System: [scope + trust boundaries + assets ranked by value]

STRIDE per boundary: [user → API]
  Spoofing:            [threat → mitigation: authN mechanism]
  Tampering:           [threat → mitigation: signatures/input validation]
  Repudiation:         [threat → mitigation: audit logging]
  Information Disclosure: [threat → mitigation: encryption/ACLs]
  Denial of Service:   [threat → mitigation: rate limits]
  Elevation of Privilege: [threat → mitigation: authz least-privilege]

CI gates: SAST [tool] / dependency scan [tool] / secret detection [tool] — blocking severity: [level]
Review cadence: threat model revisited on [every new trust boundary / quarterly]
Known accepted risks (documented, signed off): [list + expiry date]
```

### Failure Modes
- STRIDE-by-rote: each cell filled with "N/A" or a generic control — the model proves nothing → every mitigation names the specific mechanism and where it's enforced in code
- Scanner = security: green CI mistaken for safety — SAST misses design flaws and logic abuse → scanners cover known patterns; the threat model covers what's unique to your system
- Accepted risks without expiry: "we'll fix it later" entries living for years → every accepted risk carries a sign-off and a re-review date

### Evidence Strength
Practitioner consensus — building security in earlier is well supported by the cost asymmetry of fixing defects late, and STRIDE/OWASP practice is industry standard; quantitative evidence on specific process elements (how much threat modeling reduces incidents) is limited, and effectiveness depends heavily on actually maintaining the artifacts.

### Source
Microsoft STRIDE model; OWASP secure coding guidelines.

## Observability
> source: observability.md
### Core Concept
Three pillars working together: Logs (discrete events), Metrics (aggregated measurements), Traces (request flow across services). SLO-driven alerting ensures you're alerted on user-impacting issues, not noise.

### Applicable Scenarios
✅ **Best for**
- Production incident investigation
- Distributed system tracing
- Capacity planning

⚠️ **When NOT to use**
- A single service with trivial traffic — structured logs plus one uptime check may be the honest ceiling; a tracing stack is overhead
- Debugging you can do locally with a debugger — production observability is for production behavior
- Collecting everything "just in case" — unbounded telemetry costs money and buries signal; instrument questions you actually need answered

### Key Steps
1. **Define SLOs**: what level of service do users expect? (e.g. 99.9% success rate, p99 < 200ms)
2. **Instrument**: add structured logging, metrics collection, distributed tracing
3. **Alert on SLOs**: alert when error budgets are being consumed, not on raw metrics
4. **Correlate**: link logs, metrics, and traces for fast incident investigation
5. **Review**: regular observability reviews to improve coverage

### Output Template

```
Service: [checkout-api]

SLOs: availability 99.9% (30d) | p99 latency < 300ms | — error budget: [x% remaining]
Alerts (SLO burn only): fast-burn [2%/1h → page], slow-burn [5%/24h → ticket]
  Explicitly NOT alerting: [CPU > 80% — no direct user impact proven]

Instrumentation:
  Metrics: [RED — rate/errors/duration per endpoint; saturation for queues]
  Logs: structured JSON, [trace_id on every line], sampled [x]
  Traces: [ propagated across services, tail-sampled for errors]

Incident drill: given [p99 spike alert], can an on-call reach the failing dependency in <5 min via trace → logs? [test it quarterly]
```

### Failure Modes
- Alert spam → numbness: raw-threshold alerts (CPU, memory) page on non-problems → alert only on SLO burn; if a page has no user impact, it's a dashboard, not an alert
- Pillars in silos: logs in one tool, metrics in another, traces nowhere — correlation by human memory → enforce trace IDs across all three; uncorrelated telemetry is three times the cost for a third of the value
- Dashboard sprawl: 40 dashboards nobody opens outside incidents → prune to the SLO view plus per-service RED; coverage reviews decide what earns its place

### Evidence Strength
Practitioner consensus — SRE practice with strong industrial adoption; the SLO/error-budget mechanism is operationally well proven at scale, while "three pillars" itself is contested in practice (tracing-centric approaches increasingly subsume logs/metrics). The alert-fatigue failure mode is extensively documented.

### Source
Google SRE methodology; Charity Majors et al., *Observability Engineering*.

## Performance Optimization
> source: performance-optimization.md
### Core Concept
Measure → Locate → Optimize → Verify cycle. Bottleneck layering (CPU / Memory / I/O / Network). Anti-pattern warnings: don't optimize without measuring, don't guess bottlenecks.

### Applicable Scenarios
✅ **Best for**
- Performance troubleshooting
- Baseline establishment
- Resource cost optimization

⚠️ **When NOT to use**
- No measurable user or cost pain — optimizing without a symptom produces code churn and bugs, and usually optimizes cold paths
- One-shot scripts and prototype code — clarity outruns speed until the prototype proves its shape
- Premature micro-optimization during initial development — algorithm choice matters, cache-line tuning doesn't yet

### Key Steps
1. **Measure**: establish performance baseline with realistic load
2. **Locate**: profile to find the actual bottleneck (don't guess)
3. **Optimize**: address the bottleneck (layer: CPU → Memory → I/O → Network)
4. **Verify**: re-measure to confirm improvement; check for regressions
5. **Repeat**: find the next bottleneck; iterate

### Output Template

```
Symptom (user-visible): [p95 page load 2.8s, target <1s]
Baseline: [load profile: n rps, data volume, environment] — reproducible via [benchmark command]

Profile evidence: [flame chart / EXPLAIN / profiling output — the actual measurement]
Bottleneck located: [N+1 queries in order listing — 41 queries/request] — layer: I/O

Optimization applied: [batch fetch + join] — expected effect: [queries 41→2]
Verify: [p95 2.8s → 0.9s] — regression check: [full test suite + correctness spot-check on edge cases]
Guardrail added: [query-count assertion in integration test]
Next bottleneck: [or: target met, stop]
```

### Failure Modes
- Optimization by folklore: rewriting the hot function that profiling never flagged → no optimization starts without profile evidence; intuition proposes, profiler disposes
- Unverified wins: change merged on "should be faster", later found slower at real load → same benchmark, before and after, plus a regression check on correctness
- Benchmark theater: measuring a microbenchmark that doesn't represent production shape (data volume, concurrency) → baselines must match realistic load, or state clearly that they don't

### Evidence Strength
Strong for the cycle itself — measure-first optimization is foundational performance engineering practice, and the cost of guessing wrong is empirically well known (most intuitive hotspots aren't hot); specific heuristics (C10k-style rules, cache tuning folklore) age quickly, so lean on measurement over doctrine.

### Source
Performance engineering best practices; Brendan Gregg's systems performance methodology.

## Back-of-Envelope Estimation
> source: napkin-math-estimation.md
### Core Concept
Estimate performance and cost from first principles before building: Fermi-decompose the question until each factor maps to a known hardware constant, then multiply. Work in `c × 10^e` — the target is the exponent `e` (right order of magnitude); the coefficient matters far less. Keep units through every step; they are a free checksum. This is the design-time twin of Performance Optimization, which measures the running system instead.

### Applicable Scenarios
✅ **Best for**
- Capacity / QPS / storage / cost feasibility before committing to an architecture
- Sanity-checking a design proposal or infrastructure quote in minutes

⚠️ **When NOT to use**
- A running system exists — measure it (Performance Optimization)
- The answer must be precise (billing, contracts) — estimation bounds the problem, measurement decides it

### Key Steps
1. **Fermi-decompose**: break the question into factors you can guess at (log line size, requests/sec, $/GB) until each maps to a constant below.
2. **Pin the exponent first**: compute in `c × 10^e`; refine `c` only when the decision is close.
3. **Multiply with constants**, units attached; >6 assumptions means over-decomposed — collapse and re-estimate.
4. **State the verdict as magnitude + margin**: "about 10^3, could be 3× off" — not false precision.

### Reference Constants
Rounded for memorization — magnitudes, not precision; throughput/latency pairs are intentionally smoothed for arithmetic. Rows reference commodity cloud hosts (upstream suite re-measured 2026-03-08 on a GCP `c4-standard-48-lssd`-class node). **Numbers go stale — re-measure any row a critical decision hinges on.**

| Operation | Latency | Throughput |
| --- | --- | --- |
| Sequential memory access (64 B) | 0.5 ns | ~20 GiB/s per core, ~200 GiB/s threaded |
| Random memory access (64 B) | 20 ns | ~3 GiB/s |
| Hash, non-crypto (64 B) | 10 ns | ~5 GiB/s |
| System call | ~300 ns | — |
| Sequential SSD read (8 KiB) | 1 µs | ~8 GiB/s |
| Sequential SSD write, no fsync (8 KiB) | 2 µs | ~3 GiB/s |
| Context switch | ~10 µs | — |
| Random SSD read (8 KiB) | ~100 µs | ~70 MiB/s |
| Sequential SSD write, fsync (8 KiB) | ~300 µs | ~30 MiB/s |
| Redis / Memcached-class query | ~500 µs | — |
| Network, same zone | ~100 µs | ~10 GiB/s |
| Network, cross-AZ same region | ~250 µs | ~2 GiB/s |
| Network, cross-region | 25–180 ms RTT | ~25 MiB/s |
| Blob storage GET (single stream) | ~80 ms | ~100 MiB/s |
| Random HDD read (8 KiB) | ~10 ms | <1 MiB/s |

| Cost item (cloud ballpark) | ~$ / month |
| --- | --- |
| vCPU core | $15 |
| RAM | $2 / GB |
| Blob / object storage | $0.02 / GB |
| Logs & traces (ingest-class) | $0.5 / GB |
| Internet egress | $0.1 / GB |

### Output Template

```
Q: can one 8-vCPU server handle 5,000 RPS of 8 KiB cached responses?
  egress: 5,000 × 8 KiB ≈ 39 MiB/s ≈ 0.04 GiB/s → 3 orders below ~10 GiB/s NIC
  CPU: 4 syscalls (1.2 µs) + serialize 8 KiB (~8 µs) + app logic (~20 µs) ≈ 30 µs/req
       → 5,000 × 30 µs = 0.15 core
  verdict: yes, ~2 orders of headroom (margin 3×); real limits = connections, tail latency
           → measure those live before loading (Performance Optimization)

Q: cost of 2,000 log lines/s × 1 KiB for 30 days?
  ~1.9 MiB/s → ~165 GiB/day → ~5 TiB/mo × $0.5/GB ≈ $2,500/mo
  levers: compress text 2–4× → ~$600–1,200; sample 10% → ~$60–120
  verdict: TiB-scale ingestion is a real cost lever — set sampling policy before shipping
```

### Failure Modes
- Faux precision: "1,347 RPS" from 9 stacked assumptions → keep ≤6 factors, report magnitude + margin
- Dropped units: ns × MiB landing on a nonsense exponent — units that don't cancel mean a factor is missing
- Stale constants: re-measure rows a critical decision depends on
- Estimating what you can measure: once a system exists, a 5-minute benchmark beats an hour of napkin math

### Evidence Strength
Strong for the technique — Fermi decomposition and order-of-magnitude reasoning are standard capacity-planning practice, and being 2–3× off is harmless because the exponent drives the decision. The constant table is hardware- and date-bound folklore: a prior to verify, not a law.

### Source
Fermi estimation technique; Sirupsen's napkin-math project (numbers table re-measured 2026-03-08, GCP c4-standard-48-lssd).
Provenance: framework ideas absorbed from [napkin-math](https://github.com/sirupsen/napkin-math) (MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns design-time order-of-magnitude estimation; Performance Optimization measures a running system, and no existing entry covered sizing before build.

## Theory of Constraints
> source: theory-of-constraints.md (original title: Theory of Constraints (Five Focusing Steps))
### Core Concept
A flow system's end-to-end throughput is set by exactly one binding constraint; improving anything else moves nothing. The Five Focusing Steps fix the order of operations: Identify → Exploit (free) → Subordinate (discipline) → Elevate (spend, only if still short) → Recheck (the constraint moves). The constraint is usually not a machine or a person but a **policy** — a forgotten rule, metric, or assumption. This is the system-level sibling of Performance Optimization: profiling finds code hotspots inside a stage, TOC finds which stage binds the whole flow and in what order to act.

### Applicable Scenarios
✅ **Best for**
- Work piles up before one stage while downstream idles (review queue, deploy pipeline, support backlog, hiring funnel)
- Adding capacity or headcount anywhere fails to raise end-to-end output
- Deciding where limited improvement budget goes, in what order

⚠️ **When NOT to use**
- Load evenly spread, no stage dominates — there is no single constraint to exploit
- Correctness fault, not flow rate — debug it
- Bottleneck hops between stages every run — concurrency/contention design problem
- Constraint known and fix cheap — just apply it
- Demand-constrained or exploratory systems — the limit is the market or unknown knowledge; forcing a permanent bottleneck there is cargo-cult TOC

### Key Steps
1. **Define the flow and the goal**: name the unit of work and the end-to-end throughput metric — never local utilization.
2. **Identify with evidence**: follow the pile (WIP accumulates immediately upstream of the constraint) and compare stage rates; supporting signals: near-saturated utilization, longest queue, lowest stage rate, more input stops raising output. Then classify **resource** (genuinely capacity-limited) vs **policy** (a rule/metric/assumption creates the cap). Default suspicion: policy — ask "what rule created this pile?"
3. **Exploit at zero spend**: constraint never idle, never work on defects, cut its setup and wait time.
4. **Subordinate**: pace upstream release to the constraint's consumption rate, cap WIP; fast stages must accept idle. Most resisted step — resistance signals the diagnosis is right.
5. **Elevate only if still short**: buy capacity, shard, parallelize. For a policy constraint, "elevate" = change the rule — usually free, usually dominates buying capacity.
6. **Recheck**: after any fix, remeasure all stages — the constraint has moved. Kill rules written to protect the old constraint; inertia is where the next one hides.

### Output Template

```
Goal: [tickets resolved/week ≥ 200]
Flow: intake → triage → investigation → fix → verify  (rates: [...])
Constraint: [investigation] — POLICY (queue 3.2 days; stage rate 140/wk caps system)
  rule behind it: [only seniors may investigate]
Exploit: [pre-triage checklists → clean input; +15%]
Subordinate: [cap intake WIP at constraint rate; tier-2 accepts idle]
Elevate: [change the approval rule before hiring — free vs $X/mo]
Watch: [re-measure all stage rates; constraint likely moves to verify]
```

### Failure Modes
- Elevate-first: buying capacity before exploiting and subordinating — the most common, most expensive error
- Mirage optimization: an hour saved at a non-constraint raises nothing but inventory
- Resource-by-default diagnosis: calling it a staffing problem when one rule change lifts the cap free
- Activity metrics: rewarding busy stages and utilization instead of system throughput

### Evidence Strength
Strong — the five-step structure recurs independently across operations, software delivery, and systems-thinking practice, and the resource-vs-policy split matches everyday experience. The specific constraint is only as good as its queue/rate evidence: no pile, no TOC.

### Source
Eliyahu M. Goldratt & Jeff Cox, *The Goal* (1984) — Theory of Constraints and the Five Focusing Steps.
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) `thinking-theory-of-constraints`, [systems-thinking-skills](https://github.com/BayramAnnakov/systems-thinking-skills) `constraint-finder`, and [knowledge-skills](https://github.com/deciqAI/knowledge-skills) `theory-of-constraints` (all MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns system-level bottleneck ordering across stages; Performance Optimization finds code hotspots inside a stage, not which stage binds the flow.

## Incident Response & Postmortem
> source: incident-response-postmortem.md
### Core Concept
Detection → Response → Mitigation → Resolution + blameless postmortem + Action Item closure. Structured incident management that learns from failures without blaming individuals.

### Applicable Scenarios
✅ **Best for**
- Production incident emergency response
- On-Call process building
- Experience capture and learning

⚠️ **When NOT to use**
- No production impact yet — a failing build, a staging-only bug, a customer-reported annoyance with no outage → this is ordinary work, and running the incident process on it dilutes the signal and trains people to dismiss the process
- A slowdown with no user-visible impact yet → **Performance Optimization** (measure, locate, optimize, verify) is the right cycle; an incident process around a known, contained problem adds overhead
- A security incident with disclosure, legal, and forensic obligations → this entry covers learning, not breach handling; run the security response process alongside it
- Deciding what to alert on and who to page → **Observability** owns SLOs and burn-rate alerting, which is what determines whether anyone is woken up at all

### Key Steps
1. **Detect**: alert fires; on-call is paged
2. **Respond**: acknowledge; assemble incident team; start incident channel
3. **Mitigate**: take action to reduce user impact (rollback, failover, etc.)
4. **Resolve**: fix the root cause; verify recovery
5. **Postmortem**: within 48h, write blameless postmortem (timeline, impact, root cause, action items)
6. **Action Items**: assign owners and deadlines; track to completion

### Output Template

```
Incident: [id]   Severity: [SEV1-4]   Started: [time]   Detected by: [alert | customer | human]
Resolved: [time]   User impact window: [x min]   Commander: [role]

Timeline (written during the incident, not reconstructed later):
  [hh:mm] [alert fired: ...]  [hh:mm] [mitigation applied: ...]  [hh:mm] [recovery verified: ...]
Impact: [users affected / requests failed / SLO budget consumed]

Root cause: [one technical cause, one layer below the symptom]
Trigger: [what changed]

Action items (owner + date + verification, all three required):
  1. [action] — owner [name] — due [date] — verified by [check]
  2. [action] — owner [name] — due [date] — verified by [check]
Blameless scope: [system and behavior only — no individual named as cause]
Closure: next review [date]; overdue items escalated to [role]
```

### Failure Modes
- Action-item theater: the postmortem ends with a list of good intentions nobody owns → every action needs one owner, a date, and a verification check; unowned items are deleted, not assigned to a team, and the tracker is the only closure mechanism
- Blame assigned, so the next incident is reported late or not at all → scope blameless to actions and systems, and treat leadership's public commitment to that scope as a precondition, not a courtesy
- The postmortem is written weeks later, so the timeline is reconstructed from memory and the root cause is a plausible story → capture the timeline in the incident channel while it happens; a delayed postmortem is a hypothesis, not a record
- Mitigation and root cause are argued in the same conversation while users stay broken → split the work explicitly: fix forward and restore first, then analyze after service is back
- Action items tracked in a spreadsheet nobody opens → review open items at the start of every postmortem and escalate overdue ones to the leadership that owns them, or the same causes recur

### Evidence Strength
Strong — blameless postmortems, structured incident roles, and postmortem-driven action items are among the most consistently documented and widely adopted reliability practices, drawn from long-running SRE and incident-management programs; the supporting evidence is experiential and organizational rather than controlled, and the claim that postmortems prevent recurrence holds only when action-item closure is rigorous, which many organizations fail to sustain.

### Source
Google SRE methodology; PagerDuty incident response best practices.

## Category Guide
## Engineering

**When to use**: Test-driven development, bite-sized executable plans, service contract design, Agent friendliness assessment, code review, architecture design, CI/CD, observability, domain-driven design, performance optimization, security design, API design, database design, incident response, Git workflow, dependency management, microservices, refactoring, back-of-envelope estimation, throughput constraints, design contradiction resolution

### Programming Methodologies


### Architecture Methodologies

| Methodology | One-line description | Best scenario | Reference |
| --- | --- | --- | --- |
| **Typed Service Contracts** | Spec&Handler + Design by Contract + Result Monad + Parse don't validate | Service boundary contract design, boundary error defense | `typed-service-contracts.md` |
| **Agent DX / CLI Scale** | 7-axis 0-3 scoring: Machine-Readable/Raw Payload/Schema/Context/Hardening/Safety/Knowledge | CLI/SDK agent friendliness assessment | `agent-dx-cli-scale.md` |
| **Agent Autonomy & Runtime Design** | Workflow-vs-agent decision + composable patterns + per-action autonomy dial + HITL + injection defense | Should this be an agent; how much autonomy; where do human checkpoints sit | `agent-autonomy-design.md` |
| **Clean Architecture** | Dependency inversion layering + Port & Adapter + domain layer zero external dependencies | New project architecture design, framework/database replacement | `clean-architecture.md` |
| **Domain-Driven Design** | Bounded context + aggregate root + ubiquitous language + event storming | Complex business system modeling, microservice boundary definition | `domain-driven-design.md` |
| **Microservices Patterns** | Saga/CQRS/Event Sourcing + service governance + resilience patterns | Monolith decomposition, distributed data consistency, service governance | `microservices-patterns.md` |
| **API Design** | RESTful/GraphQL/gRPC selection + version management + idempotency + error response | Interface design, API standardization, version compatibility | `api-design.md` |
| **Database Schema Design** | Data modeling + index strategy + safe migration + normalization/denormalization | New project data model, schema restructuring, query optimization | `database-schema-design.md` |
| **TRIZ Contradiction Separation** | Template-named contradiction → IFR → separate in time/space/condition/scale → reuse existing resources → lock no-compromise or record residual trade-off | Design parameters pull in opposite directions, "can't have both" trade-offs | `triz-contradictions.md` |

### Process Methodologies

| Methodology | One-line description | Best scenario | Reference |
| --- | --- | --- | --- |
| **CI/CD Pipeline Design** | 7-stage pipeline (Trigger→Build→Test→Security→Quality→Deploy→Post-Deploy) + gates + rollback | Pipeline setup, release strategy design, quality gates | `cicd-pipeline-design.md` |
| **Security by Design** | STRIDE threat modeling + secure coding patterns + CI continuous verification | Security architecture design, compliance requirements, security hardening | `security-by-design.md` |
| **Observability** | Logs + Metrics + Traces 3-pillar collaboration + SLO-driven alerting | Production incident investigation, distributed system tracing, capacity planning | `observability.md` |
| **Performance Optimization** | Measure→Locate→Optimize→Verify cycle + bottleneck layering + anti-pattern warnings | Performance troubleshooting, baseline establishment, resource cost optimization | `performance-optimization.md` |
| **Back-of-Envelope Estimation** | Fermi decomposition + c×10^e magnitude target + unit checksum + hardware/cost constant table | Pre-build capacity/QPS/cost feasibility checks, design sanity checks | `napkin-math-estimation.md` |
| **Theory of Constraints** | Identify→Exploit→Subordinate→Elevate→Recheck on the single binding stage + resource vs policy classification | One stage queues while downstream idles, added capacity doesn't raise end-to-end output | `theory-of-constraints.md` |
| **Incident Response & Postmortem** | Detect→Respond→Mitigate→Resolve + blameless postmortem + Action Item closure | Production incident emergency, On-Call process building, experience capture | `incident-response-postmortem.md` |

### Minimum Information Requirements per Methodology

- **TDD Red-Green-Refactor**: Requires runnable test framework
- **Bite-Sized Plan**: Requires task decomposition capability + clear file paths
- **Code Review Checklist**: Requires PR/MR to review + project architecture context
- **Refactoring Patterns**: Requires code to refactor + test coverage
- **Git Workflow Strategies**: Requires team size + release cadence + CI/CD maturity
- **Dependency Management**: Requires project dependency list + security scanning tools
- **Typed Service Contracts**: Requires service boundary identification + type system support
- **Agent DX / CLI Scale**: Requires CLI/SDK to evaluate + 7-dimension scoring capability
- **Agent Autonomy & Runtime Design**: Requires a concrete task description + tool inventory (the workflow-vs-agent verdict is the entry's output, not its input)
- **Clean Architecture**: Requires business domain analysis + tech stack constraints
- **Domain-Driven Design**: Requires business expert participation + domain knowledge
- **Microservices Patterns**: Requires existing system architecture + team organizational structure
- **API Design**: Requires API usage scenarios + consumer requirements
- **Database Schema Design**: Requires business entity relationships + query patterns
- **TRIZ Contradiction Separation**: Requires two named opposing states of one parameter + the benefit each state serves
- **CI/CD Pipeline Design**: Requires project type + deployment environment + team size
- **Security by Design**: Requires system data flow diagram + compliance requirements
- **Observability**: Requires system architecture + SLA/SLO definitions
- **Performance Optimization**: Requires performance baseline data + SLO targets
- **Back-of-Envelope Estimation**: Requires workload shape (request size / rates / data volumes) + hardware or cost constants for the rows used
- **Theory of Constraints**: Requires flow stage sequence + per-stage rate or queue evidence + a throughput goal
- **Incident Response & Postmortem**: Requires incident timeline + monitoring data

### Routing Trigger Signals

- "Test-driven development" → TDD Red-Green-Refactor (primary)
- "Bite-sized executable plan" → Bite-Sized Plan (primary)
- "Code review / PR review" → Code Review Checklist (primary)
- "Refactoring / code smells / code cleanup" → Refactoring Patterns (primary)
- "Git branching strategy / workflow / release process" → Git Workflow Strategies (primary)
- "Dependency management / dependency selection / dependency vulnerabilities / dependency audit" → Dependency Management (primary)
- "Service boundary contract design" → Typed Service Contracts (primary)
- "Agent friendliness assessment" → Agent DX / CLI Scale (primary)
- "Should this be an agent or a workflow / how much autonomy / where does the human check / multi-step LLM orchestration / prompt injection defense for the loop" → Agent Autonomy & Runtime Design (primary) ⚡ If choosing between agent frameworks (langgraph/crewai/autogen) or reviewing built agent code → diting; if authoring ZCode workflow scripts → dynamic-workflows
- "Architecture design / layering / hexagonal / onion architecture" → Clean Architecture (primary)
- "Domain-driven / DDD / bounded context / event storming / aggregate root" → Domain-Driven Design (primary)
- "Microservices / distributed systems / Saga / CQRS / service governance" → Microservices Patterns (primary)
- "API design / RESTful / GraphQL / gRPC / interface design" → API Design (primary)
- "Database design / schema / indexing / data modeling / migration" → Database Schema Design (primary)
- "CI/CD / pipeline / continuous integration / continuous deployment / release strategy" → CI/CD Pipeline Design (primary)
- "Security design / threat modeling / STRIDE / secure coding" → Security by Design (primary)
- "Observability / monitoring / logging / tracing / alerting" → Observability (primary)
- "Performance optimization / performance troubleshooting / latency / throughput" → Performance Optimization (primary)
- "Back-of-envelope / napkin math / Fermi estimation / capacity estimation / cost estimation" → Back-of-Envelope Estimation (primary)
- "Bottleneck / throughput constraint / where work piles up / system-wide limit / five focusing steps" → Theory of Constraints (primary)
- "Design contradiction / conflicting requirements / resolve trade-off / can't have both" → TRIZ Contradiction Separation (primary)
- "Incident response / On-Call / Postmortem / review" → Incident Response & Postmortem (primary)

### Common Combinations

- **Capacity & cost design**: Back-of-Envelope Estimation (design-time magnitude) → Performance Optimization (measured verification once the system runs)
- **Throughput workup**: Theory of Constraints (identify the binding stage) → Performance Optimization (profile the code inside that stage)
- **Contradiction-first design**: Microservices Patterns (check the pattern inventory first) → TRIZ Contradiction Separation (no standard pattern fits the conflict)
