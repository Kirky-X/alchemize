# Strategic Analysis (compact aggregate)
> Aggregated from `references/strategy/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh strategy "<methodology>"`

## SWOT
> source: swot.md (original title: SWOT Analysis)
### Core Concept
4-quadrant assessment: internal Strengths/Weaknesses × external Opportunities/Threats. A comprehensive but simple framework for situation assessment and strategic direction.

### Applicable Scenarios
✅ **Best for**
- Annual planning
- Product launch assessment
- Strategic transformation

⚠️ **When NOT to use**
- Fast-moving environments — a SWOT is a static snapshot that dates within months; date it and set a refresh trigger
- Industry-structure questions — SWOT describes one player at a time and hides relative position; use **Porter's Five Forces** for industry attractiveness or **PESTLE** for macro context
- Strategy derivation from the matrix alone — S-O/W-O/S-T/W-T pairings are generative prompts, not strategy; they need capability and feasibility assessment behind them
- Unprioritized inputs — 8 bullets per quadrant with no evidence is wall art, not analysis

### Key Steps
1. Define the analysis target (product/company/market)
2. List internal Strengths (what we do well, unique resources)
3. List internal Weaknesses (what we lack, competitive disadvantages)
4. List external Opportunities (market trends, unmet needs)
5. List external Threats (competitors, regulations, market shifts)
6. Generate strategies: S-O (leverage strengths for opportunities), W-O (fix weaknesses to capture opportunities), S-T (use strengths against threats), W-T (minimize weaknesses to avoid threats)

### Output Template

```
Target: [product/company/market]  Date: [date]  Refresh trigger: [event]
Strengths (top 2): [1. item + evidence] [2. item + evidence]
Weaknesses (top 2): [1. item + evidence] [2. item + evidence]
Opportunities (top 2): [1. item + evidence] [2. item + evidence]
Threats (top 2): [1. item + evidence] [2. item + evidence]
Strategy pairings:
  S-O: [leverage strength 1 → capture opportunity 1]
  W-O: [fix weakness 1 → unlock opportunity 2]
  S-T: [use strength 2 → blunt threat 1]
  W-T: [minimize weakness 2 → avoid threat 2]
Owners: [each pairing gets a name + next step]
```

### Failure Modes
- Wall-art lists: 8 items per quadrant with no ranking → force top-2 per quadrant, each backed by named evidence; if the room can't agree on the top 2, the analysis isn't done
- No-evidence brainstorm: strengths and opportunities asserted from optimism → every entry cites a data source or observable fact; the rest are hypotheses, labeled as such
- Pairing theater: S-O/S-T combos generated but never resourced → each pairing leaves the room with an owner and a next step, or it's decoration
- Static snapshot: last year's offsite SWOT still steering this year's bets → date the analysis, define the refresh trigger, treat it as a living planning input

### Evidence Strength
Practitioner consensus — universally taught and genuinely useful as a first-pass situational frame, but weak on prioritization (no built-in ranking mechanism), prone to producing static snapshots that date quickly, and structurally a list generator rather than a decision generator — its value depends entirely on the evidence discipline and follow-through applied after the quadrants are filled.

### Source
Albert Humphrey (1960s); Stanford Research Institute.

## PESTLE
> source: pestle.md (original title: PESTLE Analysis)
### Core Concept
6-dimension macro environment scan: Political, Economic, Social, Technological, Legal, Environmental. Maps the external forces that could impact your strategy.

### Applicable Scenarios
✅ **Best for**
- Entering new markets
- Policy impact analysis
- External risk assessment

⚠️ **When NOT to use**
- As a standalone strategy tool — PESTLE only scans; it cannot rank your options or produce a decision (feed it to SWOT's O/T)
- Single-quarter horizons — macro forces act over years; for near-term risk use FMEA or a risk matrix
- Unbounded brainstorming: without a decision on the table, the scan produces a news digest, not analysis

### Key Steps
1. For each PESTLE dimension, identify key factors affecting your organization
2. Rate each factor: impact (high/medium/low) × certainty (high/medium/low)
3. Prioritize high-impact, high-certainty factors
4. Assess: how do these factors create opportunities or threats?
5. Develop strategic responses for each prioritized factor

### Output Template

```
Scope: [market/geography] × horizon [3-5 yrs] × decision: [what this scan informs]

| Dim | Factor                     | Impact | Certainty | O/T | Response or watch trigger        |
| --- | -------------------------- | ------ | --------- | --- | -------------------------------- |
| P   | [data-localization bills]  | High   | Medium    | T   | [scenario-plan data residency]   |
| E   | [FX swing risk]            | Med    | Low       | T   | [hedge or price clause]          |
| S   | [aging demographics]       | High   | High      | O   | [product line for 55+]           |
| T   | [LLM cost collapse]        | High   | Medium    | O/T | [both: moat review + feature]    |
| L   | [AI labeling regulation]   | Med    | High      | T   | [compliance workstream]          |
| E   | [carbon reporting rules]   | Low    | Medium    | T   | [monitor]                        |

Watchlist (low certainty now): [factors + tripwire signals]
Feeds into: SWOT O/T — dated [today], owner [x], next scan [quarterly]
```

### Failure Modes
- News-digest mode: 25 factors, all medium, nothing prioritized → the impact × certainty cut is mandatory; most factors must die on it
- No decision attached: scan "for awareness" — awareness decays in a week → declare what decision this scan informs before starting
- Set-and-forget: a scan from 2 years ago still circulating → date it, own it, and schedule the refresh

### Evidence Strength
Practitioner consensus — a checklist ensuring breadth of external scanning; it makes no causal claims and has no validation beyond usefulness, and its factor lists are only as good as the research behind them.

### Source
Francisco Aguilar (1967); extended from PEST to PESTLE.

## Porter's Five Forces
> source: porter-five-forces.md
### Core Concept
Industry competitive structure analysis through 5 forces: Competitive Rivalry, Threat of New Entrants, Bargaining Power of Suppliers, Bargaining Power of Buyers, Threat of Substitutes.

### Applicable Scenarios
✅ **Best for**
- Industry entry assessment
- Competitive strategy formulation
- Industry attractiveness analysis

⚠️ **When NOT to use**
- Defining an entirely new category — forces describe an existing industry's structure; there are no incumbents yet
- Complementors/platform dynamics dominate (app stores, ecosystems) — the model analyzes rivalry and famously underweights cooperation
- Fast-liquidity markets where "industry" boundaries blur quarter to quarter — force ratings go stale quickly

### Key Steps
1. Assess each of the 5 forces (High/Medium/Low)
2. Identify which forces are strongest (these define industry profitability)
3. Develop strategy to position against the strongest forces
4. Monitor force changes over time

### Output Template

```
Industry: [definition + boundary]

| Force              | Level | Evidence (not vibes)                     | Trend | Implication            |
| ------------------ | ----- | ---------------------------------------- | ----- | ---------------------- |
| Rivalry            | High  | [n players, price wars, exit rate]        | [↑→↓] | [differentiate or exit]|
| New entrants       | Med   | [capex, regulation, switching costs]      |       | [raise which barrier?] |
| Supplier power     | Low   | [n suppliers, concentration, substitutes] |       |                        |
| Buyer power        | High  | [concentration, price transparency]       | [↑]   | [lock-in or scale]     |
| Substitutes        | Med   | [price-performance vs alternatives]       | [↑]   | [monitor: [X]]         |

Verdict: attractiveness [high/med/low] — structure shaped by [strongest forces]
Position: [how we handle each strong force, concrete]
Reassess trigger: [consolidation event / substitute milestone / regulation]
```

### Failure Modes
- Force ratings without evidence: "rivalry: high" because it feels competitive → every level needs a named observable (concentration ratio, capex floor, switching cost)
- Static snapshot: structure erodes and reforms — a 2019 analysis applied in 2026 misleads → date the analysis and set reassess triggers
- Boundary games: defining the industry to get the answer you want ("we're not in advertising, we're in attention") → state the boundary explicitly and test the closest alternative boundary

### Evidence Strength
Mixed — one of the most taught strategy frameworks; the industry-structure-profitability link has empirical support at industry level, but critics show it defines away cooperation and innovation responses, and firm-level application often degrades into a checklist.

### Source
Michael Porter, *Competitive Strategy* (1980).

## Business Model Canvas
> source: business-model-canvas.md
### Core Concept
9-block business model: Key Partners, Key Activities, Key Resources, Value Propositions, Customer Relationships, Channels, Customer Segments, Cost Structure, Revenue Streams. One-page complete business model visualization.

### Applicable Scenarios
✅ **Best for**
- Startup/transformation business model design
- Competitive business model analysis
- Business model pivot

⚠️ **When NOT to use**
- Hypothesis-stage startup without customer evidence — Lean Canvas's problem/assumption framing fits better
- Product-feature decisions — the canvas is business-model altitude; features live elsewhere
- Multi-sided markets treated as one side — draw one canvas per side or the economics average away

### Key Steps
1. Fill each of the 9 blocks (recommended order: Value Prop → Segments → Channels → Relationships → Revenue → Key Resources → Key Activities → Key Partners → Cost Structure)
2. Validate internal consistency between blocks
3. Identify risks and assumptions per block
4. Compare with competitor business models

### Output Template

```
Key Partners        | Key Activities            | Value Propositions      | Customer Relationships | Customer Segments
[who we don't own]  | [what we must do daily]   | [why customers pick us] | [how we acquire/keep]  | [who pays, ranked]
                    | Key Resources             |                         | Channels               |
                    | [assets we can't lose]    |                         | [how value reaches]    |
Cost Structure (top items + dominant driver): [...]
Revenue Streams (model + price + who): [...]

Consistency checks: Segments ↔ Channels [ok/conflict], Value Prop ↔ Revenue [ok/conflict], Resources ↔ Cost [ok/conflict]
Riskiest assumption: [block + assumption] → test: [experiment by date]
```

### Failure Modes
- Everything-for-everyone blocks: 5 segments, 6 value props — the canvas averages into mush → rank and cap: top segment, one core value prop
- Revenue stream fantasy: prices copied from wishes, not willingness-to-pay → mark each revenue number as tested/assumed
- Consistency skipped: each block plausible alone, combination incoherent (premium value prop, bargain channels) → run the three checks out loud with the team

### Evidence Strength
Practitioner consensus — the dominant shared vocabulary for business-model work; it structures description and comparison but validates nothing itself, and its 9-block split is a convention rather than an empirically derived model.

### Source
Alexander Osterwalder & Yves Pigneur, *Business Model Generation* (2010).

## Stakeholder Mapping
> source: stakeholder-mapping.md
### Core Concept
Influence×Interest matrix to identify and manage all key stakeholders.

### Applicable Scenarios
✅ **Best for**
- Organizational change, cross-department projects, policy implementation

⚠️ **When NOT to use**
- Stakeholder set is small and obvious (a 3-person decision loop) — the map adds ceremony
- Influence is dynamic or contested (reorgs, political flux) — a static map goes stale within weeks; re-map instead
- You need deep needs analysis of one stakeholder — use User Research or JTBD for the individual level

### Key Steps
1. List all stakeholders
2. Assess Influence (High/Low) and Interest (High/Low)
3. Plot on 2×2 matrix
4. Define engagement strategy per quadrant: Manage Closely (H/H), Keep Satisfied (H-I), Keep Informed (L-H), Monitor (L/L)

### Output Template

```
| Stakeholder | Influence | Interest | Quadrant        | Engagement owner | Cadence & channel   | Current stance |
| ----------- | --------- | -------- | --------------- | ---------------- | ------------------- | -------------- |
| [CTO]       | High      | High     | Manage Closely  | [you]            | [weekly 1:1]        | [supportive]   |
| [Legal]     | High      | Low      | Keep Satisfied  | [PM]             | [milestone briefs]  | [neutral]      |
| [Support]   | Low       | High     | Keep Informed   | [PM]             | [biweekly digest]   | [champion]     |
| [Other teams]| Low      | Low      | Monitor         | —                | [changelog]         | [unaware]      |

Movement risks: [High-Interest→Low if X] / [Low-Influence→High at gate review] — plan: [note]
```

### Failure Modes
- Influence scored by org chart: the real veto lives two levels down → calibrate with people who've run similar projects before plotting
- Static map for a moving project: quadrants flip at funding gates, launches, incidents → re-plot at every phase boundary
- Managed-on-paper only: every stakeholder gets "weekly" but the map never changes engagement behavior → each row must name a channel and owner that actually exists

### Evidence Strength
Practitioner consensus — the influence/interest grid is standard project-management practice with no controlled validation; its value is coverage (surfacing the forgotten stakeholder) more than quadrant precision.

### Source
Eden & Ackerman; standard stakeholder analysis methodology.

## Ansoff Matrix
> source: ansoff-matrix.md
### Core Concept
Existing/new markets × existing/new products 4-quadrant growth strategy.

### Applicable Scenarios
✅ **Best for**
- Growth direction selection, market expansion, diversification decisions

⚠️ **When NOT to use**
- The growth option is already forced (no viable "existing market" path) — the matrix adds vocabulary, not a decision
- "Existing vs new" cannot be defined crisply for your product (e.g. adjacent segments) — boundary debates replace analysis
- Growth requires sequencing many moves over time — use a roadmap instead of a single quadrant pick

### Key Steps
1. Map current products to markets
2. Identify growth options: Market Penetration (existing/existing), Market Development (existing/new market), Product Development (new/existing market), Diversification (new/new)
3. Assess risk per option (diversification = highest risk)
4. Select growth strategy based on risk appetite and capability

### Output Template

```
Growth options assessed:
  Market Penetration  [products: A, B → market: current]  risk: low   — [feasibility note]
  Product Development [new product → current market]       risk: med   — [capability gap]
  Market Development  [product A → new segment/geography]  risk: med   — [entry barrier]
  Diversification     [new/new]                            risk: high  — [why consider at all]

Selected: [option] — risk appetite: [x]; capability evidence: [why we can execute]
Deferred: [option] — [revisit condition]
```

### Failure Modes
- Boundary fuzz: a "new" market that is really the existing market relabeled → write explicit criteria for what counts as new before plotting
- Risk ranked but never weighed against capability → pair the selected quadrant with a capability check (VRIO)
- Diversification chosen for growth optics alone → require an explicit answer to "why us, why this market"

### Evidence Strength
Practitioner consensus — the risk ordering is directionally supported by decades of diversification research (related diversification tends to outperform unrelated), but the matrix itself is a vocabulary, not a predictor of outcomes.

### Source
Igor Ansoff (1957); classic growth strategy framework.

## Blue Ocean Strategy
> source: blue-ocean.md
### Core Concept
Value innovation: simultaneously pursue differentiation and low cost to create uncontested market space.

### Applicable Scenarios
✅ **Best for**
- Non-competitive growth, strategic differentiation, red ocean breakthrough

⚠️ **When NOT to use**
- Your market has strong network effects and the winner is already entrenched — escaping competition is rarely available
- The "uncontested space" is unproven demand you cannot cheaply test first
- Regulated or commodity markets where the ERRC levers are not yours to pull

### Key Steps
1. Map the current competitive landscape (red ocean)
2. Apply ERRC grid: Eliminate / Reduce / Raise / Create
3. Design the new value curve
4. Validate: is the blue ocean commercially viable?
5. Build the business model to deliver the new value

### Output Template

```
Current industry competing factors: [price, feature X, service Y, ...]

ERRC grid:
  Eliminate — [factor the industry races on that buyers don't value] → [savings redeployed to:]
  Reduce    — [over-designed factor]                                → [down to what level]
  Raise     — [underinvested factor buyers do value]                → [up to what level]
  New value curve: [one sentence — what buyers get that no one offers]

Viability check: [who pays, how much, why incumbents won't follow immediately]
Next validation step: [cheapest test of demand for the new curve]
```

### Failure Modes
- Blue ocean that was a puddle: "no competitors" because there is no demand → validate buyer pull before building the model
- Differentiation claimed, cost never actually removed → the ERRC grid fails unless Eliminate/Reduce genuinely fund Raise/Create
- Imitation unmodeled: oceans turn red → name what delays copying (scale, brand, switching costs) and for how long

### Evidence Strength
Contested — the book's headline cases are retrospective selections, and academic reviews question how often true uncontested spaces occur and persist; the ERRC grid itself is a useful reframe independent of the statistics.

### Source
W. Chan Kim & Renée Mauborgne, *Blue Ocean Strategy* (2005).

## McKinsey 7S
> source: mckinsey-7s.md
### Core Concept
7-dimension organizational diagnosis: Strategy, Structure, Systems, Staff, Skills, Style, Shared Values.

### Applicable Scenarios
✅ **Best for**
- Organizational capability assessment, internal consistency check, change resistance analysis

⚠️ **When NOT to use**
- Diagnosing a single team's dysfunction — the framework is organization-scale; team issues need narrower tools
- Rapid triage — honest assessment of 7 dimensions takes interviews across levels, not a workshop afternoon
- You lack access to the organization's informal reality (systems described on paper vs as practiced diverge)

### Key Steps
1. Assess each of the 7 dimensions
2. Identify misalignments between dimensions
3. Prioritize changes: start with Shared Values (the center)
4. Design change plan addressing misalignments
5. Monitor: do changes in one S cascade to others?

### Output Template

```
| S             | Current state (evidence, not adjectives)      | Aligned with strategy? | Misaligned with |
| ------------- | --------------------------------------------- | ---------------------- | --------------- |
| Strategy      | [one line + source]                           | —                      | [S1, S2]        |
| Structure     | [org shape, decision rights]                  | [yes/no/partial]       | [Systems]       |
| Systems       | [planning, comp, info flows as practiced]     | [yes/no/partial]       | [Incentives reward X while strategy needs Y] |
| Staff         | [composition, gaps]                           | ...                    | ...             |
| Skills        | [distinctive capabilities, missing ones]      | ...                    | ...             |
| Style         | [how leaders actually spend time/signals]     | ...                    | ...             |
| Shared Values | [stated vs lived — with examples]             | ...                    | ...             |

Top misalignments (ranked): 1. [A↔B because ...] 2. [...]
Change entry point: [Shared Values / one hard S] — why starting there: [cascade argument]
```

### Failure Modes
- Adjective soup: "strong culture, good systems" — uncheckable → every cell needs one piece of evidence (artifact, metric, quote)
- Hard-S bias: only Structure/Systems get assessed because they're visible → the soft S's are where misalignment usually hides
- Change plan ignores cascades: fixing Structure breaks Systems it was aligned with → after each planned change, re-scan adjacent S's

### Evidence Strength
Practitioner consensus — the dominant value is forcing simultaneous attention to soft and hard elements (most alternatives over-index on structure); there is no rigorous validation of the specific 7-way split, and firms rarely have data to score the soft S's well.

### Source
Tom Peters & Robert Waterman, *In Search of Excellence* (1982); McKinsey & Company.

## BCG Matrix
> source: bcg-matrix.md
### Core Concept
Market growth rate × relative market share 4-quadrant product portfolio management: Stars, Cash Cows, Question Marks, Dogs.

### Applicable Scenarios
✅ **Best for**
- Product investment allocation, portfolio balance, business trade-offs

⚠️ **When NOT to use**
- A single-product company or a portfolio of one — there is no portfolio to balance
- Share and growth are poor proxies in your industry (winner-take-all markets, fast commoditization)
- You need today's cash decisions for a young portfolio — positions take years to become readable

### Key Steps
1. List all products/business units
2. For each, determine market growth rate and relative market share
3. Plot on 2×2 matrix: Stars (high growth, high share), Cash Cows (low growth, high share), Question Marks (high growth, low share), Dogs (low growth, low share)
4. Strategy: Invest in Stars, Milk Cash Cows, Decide on Question Marks, Divest Dogs

### Output Template

```
| Product | Market growth | Rel. share | Quadrant      | Action              | Next checkpoint |
| ------- | ------------- | ---------- | ------------- | ------------------- | --------------- |
| [A]     | high          | high       | Star          | Invest to hold lead | [date/metric]   |
| [B]     | low           | high       | Cash Cow      | Milk, fund Stars    | [date/metric]   |
| [C]     | high          | low        | Question Mark | Invest or exit by   | [decision date] |
| [D]     | low           | low        | Dog           | Divest / niche      | [date/metric]   |

Portfolio balance note: [is there a Cow funding the Stars? too many Question Marks?]
```

### Failure Modes
- "Dog" hall of shame: low-share/low-growth businesses that later became winners (the matrix undervalues niches and synergies) → before divesting, check complementarities the matrix cannot see
- Definitions drift: "high growth" relative to what horizon and market? → fix numeric thresholds before plotting
- Self-fulfilling divestment: cutting Dogs starves future Stars → mark Dogs as "decide by [date]" with a real review, not automatic harvest

### Evidence Strength
Contested — the share-growth logic behind the matrix has been repeatedly challenged (high share does not guarantee returns, low-growth niches can be highly profitable); it survives as a portfolio conversation starter rather than an allocation algorithm.

### Source
Boston Consulting Group (1970); Bruce Henderson.

## Product Strategy Canvas
> source: product-strategy-canvas.md
### Core Concept
9-block strategy canvas: Vision, Segments, Value Prop, Trade-offs, Can't-Won't Defensibility, Capabilities, Metrics, Goals, Resources.

### Applicable Scenarios
✅ **Best for**
- Strategy visualization, creating a challengeable 1-page strategy document

⚠️ **When NOT to use**
- You need analysis, not synthesis — the canvas organizes decisions already made; feed it with SWOT / Five Forces / VRIO outputs
- Team has no mandate over the blocks (Resources, Goals set elsewhere) — half-filled canvases create false confidence
- Pivot exploration with many candidate directions — one canvas per direction gets expensive; shortlist first

### Key Steps
1. Fill each of the 9 blocks
2. Ensure internal consistency
3. Validate: can you articulate the strategy in one sentence?
4. Challenge: would a competitor copy this? Why not?

### Output Template

```
Vision       | [where we're going, one sentence]
Segments     | [who we serve first — ranked, not a list of everyone]
Value Prop   | [what they get that alternatives don't offer]
Trade-offs   | [what we deliberately do NOT do — empty = no strategy yet]
Defensibility| [Can't-Won't: why this survives a competent copyist]
Capabilities | [what we must be excellent at, max 3]
Metrics      | [the 2-3 that define winning]
Goals        | [time-bound targets for those metrics]
Resources    | [people/budget assigned — must square with Goals]

One-sentence strategy: [Segments] win via [Value Prop], accepting [Trade-offs], measured by [Metrics], defended by [Defensibility].
Challenge log: [copy question → answer], [consistency conflicts found → resolved how]
```

### Failure Modes
- Trade-offs block left empty or written as "focus" without naming what's forgone → strategy without trade-offs is a wish list; force 2+ explicit "we will not" items
- Blocks filled independently and never reconciled: Goals exceed Resources, Metrics don't track the Value Prop → run the one-sentence test; contradiction shows up immediately
- Canvas worship: a filled canvas treated as a finished strategy — it's a map of hypotheses → attach the riskiest assumption and its test

### Evidence Strength
Practitioner consensus — a synthesis scaffold aggregating better-validated parts (JTBD value props, Can't-Won't defensibility, goal metrics); the canvas itself claims no predictive power, only coherence.

### Source
Product strategy methodology; adapted from multiple strategy frameworks.

## Lean Canvas
> source: lean-canvas.md
### Core Concept
BMC adapted for startups: Problem, Solution, Key Metrics, Unfair Advantage, Customer Segments, Value Proposition, Channels, Cost Structure, Revenue Streams.

### Applicable Scenarios
✅ **Best for**
- Early-stage startup 30-minute business model validation

⚠️ **When NOT to use**
- Post-product/market fit scaling — blocks like "Problem" are settled; switch to full BMC or an operating plan
- The canvas would be filled from imagination for a market you can't reach to interview — validate demand channels first
- Complex multi-sided platforms where 9 boxes must split per side — one canvas will average away the dynamics

### Key Steps
1. Fill each block (order: Problem → Customer Segments → Value Prop → Solution → Channels → Revenue → Cost → Key Metrics → Unfair Advantage)
2. Identify riskiest assumptions
3. Design experiments to validate assumptions
4. Iterate canvas based on learning

### Output Template

```
Problem (top 3)          | Customer Segments (early adopters)
  1. [pain]              |   [who feels problem #1 most acutely]
  2. [pain]              |
  3. [pain]              |
Solution (top 3 features)| Unique Value Proposition
  1-3, one line each     |   [single, clear, one sentence]
Channels                 | Revenue Streams              | Cost Structure
  [path to early adopters]| [model + price]              | [biggest items]
Key Metrics              | Unfair Advantage
  [the few that matter]  |   [something that can't be copied easily]

Riskiest assumption right now: [#1 problem truly pains early adopters] → test: [interview/landing/smallest experiment] by [date]
Canvas version: [n] — what changed since last version and why: [learning]
```

### Failure Modes
- Solution-first filling: boxes get reverse-engineered from a pet feature → fill Problem and Segments before Solution, and cap Solution at 3 lines
- Canvas as artifact: iteration stops after the first pretty version → every review must change at least one box or kill an assumption
- Unfair Advantage inflated: "passion", "first mover", "AI" — none survive contact → something not copyable for ~a year (data, distribution, expertise), else write "none yet"

### Evidence Strength
Practitioner consensus — a widely adopted adaptation of Business Model Canvas for hypothesis-driven startups; its value depends entirely on whether assumption tests actually run (the canvas itself validates nothing).

### Source
Ash Maurya, *Running Lean* (2012); adapted from Business Model Canvas.

## Startup Canvas
> source: startup-canvas.md
### Core Concept
9-block strategy + Cost Structure + Revenue Streams, separating strategy from business model.

### Applicable Scenarios
✅ **Best for**
- Early-stage startups needing to answer strategy and monetization simultaneously

⚠️ **When NOT to use**
- Pure strategy work with monetization already settled — half the canvas is dead weight; use Product Strategy Canvas
- Pre-problem-validation — both halves will encode unvalidated guesses; run discovery interviews first
- Complex multi-side businesses — strategy/model per side, not one averaged canvas

### Key Steps
1. Define strategy blocks (customer, problem, solution, value prop)
2. Define business model blocks (cost structure, revenue streams)
3. Validate: does the strategy support the business model?
4. Iterate strategy and business model independently

### Output Template

```
STRATEGY HALF
  Customer    | [who, ranked by urgency]
  Problem     | [top 1-2 pains, with cost of the pain]
  Solution    | [1-3 capabilities, no more]
  Value Prop  | [from → to instead of alternative]

BUSINESS MODEL HALF
  Revenue Streams | [model + who pays + price]
  Cost Structure  | [what dominates: build / serve / acquire]
  Fit check: gross margin per [customer] ≈ [price − serve cost] → [positive/underwater]

Coherence questions:
  Does the strategy segment match who can pay? [answer]
  Does the solution's cost shape fit the revenue model? [answer]
Weakest link right now: [block] → next test: [experiment by date]
```

### Failure Modes
- Halves filled by different people who never reconcile: the strategy targets non-payers, the model prices what strategy can't deliver → always run the two coherence questions in joint session
- Strategy half copied from an incumbent, model half from another — the mashup has no owner economics → check margin per customer before iterating either half
- Iterate independently = iterate never: "independent" blocks go stale at different rates → version the canvas, date each half's last change

### Evidence Strength
Practitioner consensus — a framing device combining standard strategy blocks with business-model blocks; the separation is useful discipline, not an empirically validated model, and its output is only as good as the discovery behind each half.

### Source
Startup strategy methodology; separating strategic choices from business model design.

## JDB Value Proposition
> source: jdb-value-proposition.md
### Core Concept
6-block JTBD template: Who / Why / What before / How / What after / Alternatives. Crystallize a challengeable value proposition.

### Applicable Scenarios
✅ **Best for**
- Distilling a challengeable value proposition before writing PRD or website

⚠️ **When NOT to use**
- No validated job statement yet (uninterviewed users) — the template will only organize guesses; run The Mom Test first
- Positioning against named competitors is the real task — use Positioning Strategy
- Internal tools with a single captive user — "alternatives" is trivially "do nothing", the template degenerates

### Key Steps
1. Who: who is the customer?
2. Why: why do they care?
3. What before: what's their current situation?
4. How: how does your product help?
5. What after: what does their life look like after?
6. Alternatives: what would they do without you?

### Output Template

```
Who:         [specific user, not a demographic]
Why:         [the job/anxiety that makes this urgent now]
What before: [current workflow and its cost — minutes/money/errors]
How:         [what we do differently, in one sentence]
What after:  [observable after-state, ideally measurable]
Alternatives: [spreadsheet / agency / do nothing / competitor] — why we beat each: [one line]

One-sentence value proposition: [Who] uses [product] to go from [before] to [after] instead of [alternative], because [how].
Challenge: would [Who] repeat this sentence back to a colleague? If not, it isn't crisp yet.
```

### Failure Modes
- Persona fog: "Who" is a segment ("marketers") instead of a person with a job → write it so you could name a real customer who matches
- After-state unmeasurable: "better collaboration" — measure nothing → force a number or observable event into "What after"
- Alternatives dismissed: the do-nothing option wins more often than teams admit → argue seriously for each alternative before dismissing it

### Evidence Strength
Practitioner consensus — a structuring device descended from Jobs-to-be-Done practice; it improves proposition clarity (testable by whether users repeat it back) but makes no empirical claim of its own.

### Source
JTBD-based value proposition framework.

## Monetization Strategy
> source: monetization-strategy.md
### Core Concept
7 monetization models: Freemium, Subscription, Usage-based, Per-seat, One-time, Marketplace, Advertising.

### Applicable Scenarios
✅ **Best for**
- Business model selection, monetization efficiency optimization

⚠️ **When NOT to use**
- Willingness to pay is unknown — model selection before price validation picks a container for an unvalidated guess
- Unit economics are underwater — no monetization model fixes a product that costs more to serve than any price users accept
- Marketplace dynamics absent for the "Marketplace" option — take rate monetization requires liquidity you may never reach

### Key Steps
1. List all 7 monetization models
2. Assess fit for each: your product type, user willingness to pay, market norms
3. Select primary model + backup
4. Design pricing tiers
5. Validate with market data

### Output Template

```
| Model        | Fit with product type | WTP evidence | Market norm | Conflict risk | Verdict |
| ------------ | --------------------- | ------------ | ----------- | ------------- | ------- |
| Freemium     | [why fits/doesn't]    | [data or none]| [norm]     | [cannibalization?] | [keep/cut] |
| Subscription | ...                   | ...          | ...         | ...           | ...     |
| Usage-based  | ...                   | ...          | ...         | ...           | ...     |
| (… all 7)    |                       |              |             |               |         |

Primary: [model] — because [decisive reason]
Backup: [model] — trigger to switch: [metric/threshold]
Tier draft: [Free: x / Pro: $y — value metric: z]
Validation next step: [pricing survey / A/B / sales test] by [date]
```

### Failure Modes
- Model by imitation: copying a famous company's model without their cost structure → every row needs your economics, not theirs
- Value metric mismatch: charging per seat when value scales with usage (or vice versa) → derive the metric from what drives customer value, not from billing convenience
- Primary without backup: market norms shift (seat-based → usage-based across SaaS) → name the trigger that flips you before you need it

### Evidence Strength
Practitioner consensus — the taxonomy is descriptive and the fit logic is sound, but model-to-success claims are anecdotal; pricing research (e.g. Van Westendorp, A/B) supplies the actual evidence, so treat this as the structuring layer on top.

### Source
Standard monetization strategy methodology.

## Pricing Strategy
> source: pricing-strategy.md
### Core Concept
Van Westendorp Price Sensitivity Meter + value metric identification + tier design.

### Applicable Scenarios
✅ **Best for**
- Pricing/repricing decisions, price sensitivity assessment

⚠️ **When NOT to use**
- Fewer than ~200 surveyable respondents who match the buyer — Van Westendorp curves from tiny samples mislead
- Brand-new category with no price anchors in respondents' heads — the four questions return noise
- B2B negotiated pricing where list price is a fiction — interview sales outcomes instead

### Key Steps
1. Identify your value metric (what unit of value do customers buy?)
2. Conduct Van Westendorp survey: at what price is it too cheap / cheap / expensive / too expensive?
3. Find optimal price range
4. Design tiers based on value metric
5. Validate with A/B testing

### Presentation Psychology (folded)

The PSM answers *what the price is*; these levers shape *how the price is presented* — applied inside tier design, after the range exists:
- **Decoy / asymmetric dominance**: a middle tier priced to make the intended home look strictly better (the `[Pro] — the intended home` row above is this lever in template form); the decoy must be dominated, not merely worse
- **Reference price & anchoring**: buyers judge against the first price seen — order tiers high-to-low, and never show the discount next to a fabricated "original" price you cannot defend
- **Price endings & per-period framing**: charm endings and per-month-per-seat framing change perception without changing the number; disclose the annualized cost honestly
- **Versioning**: split one product into tiers on a value metric the customer controls (Shapiro & Varian, *Information Rules*, 1998) — the metric choice is a pricing decision, not a packaging detail
- **Bundling / unbundling test**: bundle when valuations are heterogeneous and marginal costs near zero; unbundle when a segment's valuation of one component is extreme — test both against the PSM band before committing

Evidence grade: lab-strong (prospect theory, decoy effects replicate), field-mixed — the lever moves perception; revenue moves only with the A/B validation step above.

### Output Template

```
Value metric: [per user / per 1k events / per seat — why this tracks customer value]

Van Westendorp (n=[sample], respondent profile: [who]):
  Point of Marginal Cheapness (PMC): $[x]   — below: quality doubts
  Indifference Price Point (IPP):    $[y]
  Point of Marginal Expensiveness (PME): $[z] — above: rejection
  Optimal Price Range (OPP): $[a – $b]

Tier design:
  [Starter] $[x]/[metric] — for [segment], capped at [usage]
  [Pro]     $[y]/[metric] — for [segment], the intended home
  [Scale]   $[z]/[metric] — for [segment]

Validation: A/B or sales test of [$y vs $y±15%] on [segment], success criterion: [revenue per visitor / conversion floor]
```

### Failure Modes
- Asking willingness-to-pay directly ("what would you pay?") — the PSM's four questions exist precisely because direct answers are unreliable → never replace the four questions with one
- Surveying users instead of buyers: end users tolerate prices they don't pay → sample the budget holder
- Metric locked before testing: seat pricing on a product whose value is usage-shaped → A/B the metric itself when unsure, not just the number

### Evidence Strength
Mixed — Van Westendorp is a standard, cheap first pass, but stated-price methods systematically diverge from revealed willingness to pay (the gap is well documented); treat its range as a hypothesis band to be confirmed by real transactions, which the framework itself prescribes.

### Source
Peter van Westendorp (1976); pricing strategy methodology. Presentation-psychology fold added v0.1.16 (necessity audit: distinct lever set — what the price is vs how it is presented — but applied inside this entry's tier design; a separate card would force a routing arbitration between two pricing entries).

## Can't-Won't Defensibility
> source: cant-wont-defensibility.md
### Core Concept
Competitor can't or won't replicate your advantage. Moat strategies based on structural or will-based barriers.

### Applicable Scenarios
✅ **Best for**
- Investor questions about competition, moat design

⚠️ **When NOT to use**
- Early exploration with no traction yet — most "moats" claimed pre-launch are wishes; use the framework to rank hypotheses, not to conclude
- The advantage is a feature or a price point — those are copied in weeks; the framework is for structural positions
- You only need a competitor response forecast, not a moat audit (use Competitive Battlecard instead)

### Key Steps
1. List your competitive advantages
2. For each, classify: Can't (structural — competitor physically can't copy) vs Won't (competitor chooses not to because it conflicts with their model)
3. Strengthen Can't-Won't advantages
4. Be honest about copyable advantages

### Output Template

```
| Advantage              | Can't / Won't / Copyable | Why a top-3 competitor can't or won't          | Halflife if copied | Strengthen by        |
| ---------------------- | ------------------------ | ---------------------------------------------- | ------------------ | -------------------- |
| [proprietary dataset]  | Can't                    | [years of accumulation, no external source]     | [~3 yrs]           | [exclusive feeds]    |
| [SMB-first pricing]    | Won't                    | [incumbent's enterprise sales model can't go down] | [~18 months]    | [lock in segment]    |
| [nicer UI]             | Copyable                 | —                                              | [weeks]            | [don't bet on it]    |

Honest summary: our durable moat is [X]; [Y] buys time only; [Z] is not a moat.
```

### Failure Modes
- Confusing "hasn't yet" with "can't" → name the specific mechanism (patent, data accumulation, unit-economics conflict) or classify as copyable
- Won't barriers assumed permanent: incumbents pivot when the prize grows big enough → attach a halflife and a tripwire
- Moat talk replacing momentum: early teams spend more time claiming moats than building them → cap this analysis at one page until there is traction to defend

### Evidence Strength
Practitioner consensus — the Can't/Won't taxonomy (from the 7 Powers tradition) is a widely used lens among investors and strategists; persistence of specific moats varies hugely by industry and is an empirical question per case, not something the framework settles.

### Source
Hamilton Helmer, *7 Powers* (2016); moat strategy framework.

## Porter Diamond Model
> source: porter-diamond-model.md
### Core Concept
National competitive advantage: Factor Conditions, Demand Conditions, Related Industries, Firm Strategy/Rivalry + 2 variables (Government, Chance).

### Applicable Scenarios
✅ **Best for**
- Cross-border site selection, industrial policy, national competitiveness analysis

⚠️ **When NOT to use**
- Firm-level strategy inside one market — the diamond explains why locations excel, not why your company wins
- Digital/remote industries where geography barely binds (talent and customers are global) — factor conditions weaken as constraints
- Short-horizon decisions — diamond advantages take decades to build or erode

### Key Steps
1. Assess each of the 4 main factors for the target country/industry
2. Assess Government and Chance variables
3. Identify competitive advantages from factor combinations
4. Make location/investment decisions based on diamond analysis

### Output Template

```
Target: [country] × [industry]

Factor Conditions        — [specialized talent, infrastructure, capital: strength + evidence]
Demand Conditions        — [sophistication of local buyers: what they demand earlier/harder]
Related/Supporting Ind.  — [supplier and complementary clusters nearby]
Firm Strategy & Rivalry  — [intensity of local competition: sharpens or bleeds]
Government               — [policy levers and risks: incentives, protection, instability]
Chance                   — [exogenous events that could re-rank the above]

Verdict: locate/expand here because [combination advantage]; hedge against [top 2 risks]
Revisit trigger: [election / regulation / demand shift]
```

### Failure Modes
- Checklist flattening: four boxes ticked, no interaction analyzed — the model's point is that advantages reinforce each other (skilled suppliers + demanding buyers + rivalry) → write at least one reinforcing loop per verdict
- Government read as permanent: incentives get renegotiated → separate structural factors from policy-dependent ones in the verdict
- National averages hiding regional variance — diamond strength is cluster-specific (a country can be strong in autos, weak in software) → score the cluster, not the flag

### Evidence Strength
Mixed — cluster-level evidence supports the interaction thesis (successful industries concentrate), but the model is hard to test prospectively and critics note successful firms thrive in "weak-diamond" home bases; treat it as a structured lens for location hypotheses, then verify with market data.

### Source
Michael Porter, *The Competitive Advantage of Nations* (1990).

## GE-McKinsey Matrix
> source: ge-mckinsey-matrix.md
### Core Concept
Industry attractiveness × business strength 9-cell matrix. An upgraded BCG matrix for diversified portfolio management.

### Applicable Scenarios
✅ **Best for**
- Diversified business portfolio management, SBU resource allocation

⚠️ **When NOT to use**
- Fewer than ~3 business units — the 9-cell machinery costs more than it returns; use a simple decision matrix
- Attractiveness or strength cannot be scored with defensible criteria — composite scores hide the guesses
- Capital allocation is not actually on the table (units are strategic commitments) — the matrix implies divestment options that don't exist

### Key Steps
1. List all SBUs (Strategic Business Units)
2. Assess Industry Attractiveness (High/Medium/Low) for each
3. Assess Business Strength (High/Medium/Low) for each
4. Plot on 3×3 matrix
5. Strategy: Invest/Grow (top-left), Selectivity (diagonal), Harvest/Divest (bottom-right)

### Output Template

```
Scoring criteria (declare before scoring):
  Industry attractiveness = [market size 30% / growth 30% / margin 20% / regulation 20%]
  Business strength       = [share 30% / margin vs peers 30% / brand 20% / capabilities 20%]

| SBU | Attractiveness | Strength | Cell              | Action                | Capital shift |
| --- | -------------- | -------- | ----------------- | --------------------- | ------------- |
| [A] | 7.2 High       | 7.8 High | Invest/Grow       | [double down]         | +[x]          |
| [B] | 5.0 Medium     | 5.5 Med  | Selectivity       | [invest in wins only] | 0             |
| [C] | 2.8 Low        | 3.1 Low  | Harvest/Divest    | [exit by date]        | -[x]          |

Rebalance summary: [net reallocation and rationale]
```

### Failure Modes
- Composite-score laundering: two units with identical 5.0 scores built from completely different criteria mixes → publish the criteria weights and per-factor scores
- Central overreach: corporate picks winners for markets only the unit team knows → score jointly, let the unit challenge attractiveness inputs
- Harbor/Divest autopilot: bottom-right cells exit by default, killing turnaround candidates → require a stated turnaround thesis before harvesting

### Evidence Strength
Practitioner consensus — the multi-factor scoring fixes BCG's two-proxy rigidity and is standard in corporate strategy; but like all portfolio matrices, its output quality is bounded by the scoring criteria, and there is no evidence the 9-cell grid beats simpler allocations when criteria are weak.

### Source
McKinsey & Company / GE (1970s); multi-portfolio analysis.

## Strategic Group Mapping
> source: strategic-group-mapping.md
### Core Concept
Map companies within an industry by strategic similarity. Identify clusters and mobility barriers between groups.

### Applicable Scenarios
✅ **Best for**
- Industry competitive structure analysis, new entrant positioning, strategic differentiation

⚠️ **When NOT to use**
- Industry with < ~8 heterogeneous players — groups need enough members to be meaningful
- All competitors converge on one strategy (commodity) — there is one group; the map is empty
- The strategic dimensions that matter can't be observed (private companies, opaque pricing)

### Key Steps
1. Identify key strategic dimensions (e.g. price/quality, geographic scope, vertical integration)
2. Plot all industry players on 2D map
3. Identify clusters (strategic groups)
4. Assess mobility barriers between groups
5. Identify your position and whitespace opportunities

### Output Template

```
Dimensions: x = [price tier], y = [channel model]

  high ┤  [Group A: premium direct — Firm1, Firm2]
       │            ↑ mobility barrier: [brand + field org]
       │  [our position ★]
       │  [Group B: value retail — Firm3, Firm4, Firm5]
  low  ┤  [Group C: regional niche — Firm6, Firm7]
       └──────────────────────────────
Group performance notes: [avg margin / growth per group, where observable]
Whitespace: [position with demand evidence but no incumbent] — why empty: [barrier or no demand?]
Entry target group & required barriers to cross: [list]
```

### Failure Modes
- Arbitrary dimensions: axes picked for visual convenience produce groups that don't behave alike → test alternative dimension pairs; keep the one where within-group performance clusters
- Whitespace romanticized: an empty map region may be empty because it's unprofitable → demand-side evidence before calling it opportunity
- Barrier blindness: planning a group jump while ignoring what pins incumbents in (assets, contracts, identity) → list the barrier, then the plan to cross or nullify it

### Evidence Strength
Practitioner consensus — the concept of intra-industry strategic clusters is well established in strategy research; precise group boundaries are analyst-dependent, and profitability differences between groups are an empirical question per industry rather than a given.

### Source
Michael Porter; strategic group analysis methodology.

## Value Chain Analysis
> source: value-chain-analysis.md
### Core Concept
Primary activities + support activities, analyzing each for competitive advantage sources.

### Applicable Scenarios
✅ **Best for**
- Competitive advantage diagnostics, cost leadership/differentiation strategy, process optimization

⚠️ **When NOT to use**
- Asset-light digital businesses where "inbound logistics → operations → outbound" barely describes reality — re-map activities before the template fits
- Without competitor comparison data — the chain identifies activities but advantage is always relative
- Single-process improvement — use process-specific tools; the chain is firm-scale

### Key Steps
1. Map primary activities (inbound logistics, operations, outbound logistics, marketing/sales, service)
2. Map support activities (infrastructure, HR, technology, procurement)
3. For each activity, assess: cost and value contribution
4. Identify activities where you have advantage or disadvantage vs competitors
5. Develop strategy to strengthen advantageous activities

### Output Template

```
| Activity          | Cost share | Buyer value contribution | vs competitors | Implication              |
| ----------------- | ---------- | ------------------------ | -------------- | ------------------------ |
| Inbound logistics | [x%]       | [low/med/high]           | [ahead/parity/behind] | [note]            |
| Operations        | [x%]       | [high]                   | [ahead]        | [protect and amplify]    |
| Outbound          | ...        | ...                      | ...            | ...                      |
| Marketing/sales   | ...        | ...                      | ...            | ...                      |
| Service           | ...        | ...                      | ...            | ...                      |
| Support: [tech]   | [x%]       | [enables Operations]     | [ahead]        | [advantage source]       |

Verdict: advantage lives in [activity link(s)] — strategy: [cost leadership via X / differentiation via Y]
Linkages to exploit: [activity A → B handoff where we're uniquely good]
```

### Failure Modes
- Template transplant: forcing a digital business into manufacturing vocabulary until every box is "low" → redraw the activity list for the business model first, then analyze
- Activity-by-activity myopia: optimizing each box while advantage lives in the links between them → score handoffs explicitly
- Cost-only lens: value contribution ignored, every weak-cost activity flagged for cuts → a differentiator's "expensive" activity is the moat; compare value before cutting

### Evidence Strength
Practitioner consensus — the primary/support decomposition and the linkages thesis are foundational in strategy teaching; empirical use is limited by data availability at activity granularity, so outputs are typically directional rather than audited.

### Source
Michael Porter, *Competitive Advantage* (1985).

## Benchmarking
> source: benchmarking.md
### Core Concept
Identify gaps by comparing against industry/cross-industry best practices.

### Applicable Scenarios
✅ **Best for**
- Performance improvement, process improvement, best practice learning

⚠️ **When NOT to use**
- No comparable peer data exists and none can be constructed — the gap numbers would be fiction
- The goal is differentiation, not parity — benchmarking converges you toward the average of best practice, which is the opposite of standing out
- The process being compared is entangled with a deliberately different strategy (cost vs premium) — copying "best" breaks the model

### Key Steps
1. Identify what to benchmark (process, metric, practice)
2. Select benchmark targets (industry leaders + cross-industry best)
3. Gather data (at least 2 independent sources)
4. Analyze gaps: where are you behind? By how much?
5. Develop improvement plan based on best practices

### Output Template

```
Benchmark subject: [process/metric]
Comparison set: [peer A, peer B, cross-industry C]

| Metric       | Us    | Peer A | Best-in-class | Gap    | Root driver of the gap     |
| ------------ | ----- | ------ | ------------- | ------ | -------------------------- |
| [throughput] | 100   | 150    | 180           | -44%   | [batching / automation]    |
| [cost/unit]  | 9.0   | 7.5    | 7.0           | +29%   | [vendor contract]          |

Adoption plan: [practice] from [target] — adapted how for our context: [note]; owner: [x]; target: [metric by date]
Not adopting: [practice] — [why it conflicts with our strategy]
```

### Failure Modes
- Metric worship: hitting the benchmark number while missing the practice that produces it → benchmark the mechanism, not just the KPI
- Context blindness: adopting a practice that depends on scale, regulation, or culture you don't have → adapt before adopting, state what was changed
- Benchmarking the laggards (only peers who share data) → triangulate at least 2 independent sources per data point

### Evidence Strength
Practitioner consensus — gap analysis and target setting are uncontroversial mechanics; claims that benchmarking per se drives performance gains are weaker (firms that benchmark often already differ in management quality, a known confounder).

### Source
Benchmarking methodology; Xerox benchmarking approach (1970s).

## Product Life Cycle
> source: product-life-cycle.md
### Core Concept
4-stage strategy matching: Introduction → Growth → Maturity → Decline.

### Applicable Scenarios
✅ **Best for**
- Product strategy, investment timing, portfolio management

⚠️ **When NOT to use**
- The stage diagnosis is uncertain — strategies are stage-specific, so a wrong stage call outputs the wrong playbook entirely
- Products with restart dynamics (platforms, fashion cycles, pivot-heavy startups) — the linear S-curve doesn't hold
- Fine-grained feature decisions — the unit of analysis is the product/market, not a feature

### Key Steps
1. Determine which stage each product is in
2. Apply stage-appropriate strategy:
   - Introduction: awareness, early adopters
   - Growth: market share, differentiation
   - Maturity: efficiency, defend share
   - Decline: harvest, divest, or reinvent
3. Plan transitions between stages

### Output Template

```
| Product | Stage evidence (growth rate, adoption %, price pressure) | Stage call | Stage strategy          | Transition plan            |
| ------- | -------------------------------------------------------- | ---------- | ----------------------- | -------------------------- |
| [A]     | [adoption 8%, +40%/qtr]                                  | Growth     | [share capture, channels]| [maturity signals to watch: CAC up, churn flattens] |
| [B]     | [flat sales, price wars]                                 | Maturity   | [efficiency, retention]  | [decline triggers: ...]    |

Reinvestment choice for [declining product]: harvest (cut spend, keep cash) / divest (sell, kill) / reinvent ([new segment or form])
Stage-boundary metrics: [adoption % vs category potential, sales growth, margin trend]
```

### Failure Modes
- Stage called by revenue alone: a rising line can be early adoption or peak-before-decline → triangulate adoption % of the addressable market, price pressure, and competitor exits
- Stage-mismatched KPIs: demanding efficiency from an Introduction product (or awareness from a Mature one) → change the scorecard when the stage changes
- Decline treated as failure: harvest can be the value-maximizing play → evaluate explicitly against reinvention cost

### Evidence Strength
Practitioner consensus — the pattern is widely observed at the category level, but stage duration and shape vary enormously across industries (some products skip or loop stages); use the stage call as a strategy-matching hypothesis verified by market data, not a forecast.

### Source
Theodore Levitt (1965); product life cycle theory.

## VRIO Framework
> source: vrio.md
### Core Concept
4-question resource-based view: Is it Valuable? Rare? Costly to Imitate? Organized to capture value? Determines sustainable competitive advantage.

### Applicable Scenarios
✅ **Best for**
- Resource/capability assessment, sustainable competitive advantage identification

⚠️ **When NOT to use**
- Listing generic resources ("brand", "team") instead of specific ones — VRIO on vague nouns produces vague verdicts
- Fast-moving advantage environments where "sustainable" means months — ask "how long is imitation costly" instead
- Assessing an early-stage company's hypothetical resources — there is rarely enough evidence to answer O honestly

### Key Steps
1. List key resources and capabilities
2. For each, answer 4 questions: Valuable? Rare? Costly to Imitate? Organized?
3. Classification:
   - No to V = Competitive Disadvantage
   - V yes, R no = Competitive Parity
   - V+R yes, I no = Temporary Advantage
   - V+R+I yes, O no = Unused Advantage
   - All yes = Sustainable Competitive Advantage

### Output Template

```
| Resource / capability   | V? | R? | I (costly to imitate)? | O (organized)? | Verdict                 | Action              |
| ----------------------- | -- | -- | ---------------------- | -------------- | ----------------------- | ------------------- |
| [proprietary usage data]| Y  | Y  | Y (10-yr accumulation) | N (no feedback loop using it) | Unused Advantage | [build the loop]    |
| [exclusive channel deal]| Y  | Y  | N (replicable in 1 yr) | Y              | Temporary Advantage     | [convert to durable: ...] |
| [generic SaaS stack]    | Y  | N  | N                      | Y              | Competitive Parity      | [table stakes]      |
| [legacy process]        | N  | —  | —                      | —              | Competitive Disadvantage| [retire]            |

Portfolio verdict: durable advantage rests on [item]; imitation halflife estimate: [time]
```

### Failure Modes
- Answering V/R/I from inside the company: "our data is unique" without market evidence → each Yes needs an external proof point (competitor equivalent named and compared)
- O as an afterthought: the unused-advantage row is where most real firms live — value exists but structure doesn't capture it → treat O-gaps as first-class findings
- Sustainability inflation: "costly to imitate" asserted without naming the cost driver (path dependency, causal ambiguity, complexity) → no driver, no I

### Evidence Strength
Practitioner consensus with strong academic roots — the resource-based view is a central strategy theory, but applying it reliably is hard: imitation costs are unobservable ex ante, and the framework's verdicts degrade to hypotheses without competitor data.

### Source
Jay Barney (1991); resource-based view of the firm.

## Wardley Mapping
> source: wardley-mapping.md
### Core Concept
Value chain (vertical axis) × evolution stage (horizontal axis) strategic terrain map. Genesis → Custom → Product → Commodity.

### Applicable Scenarios
✅ **Best for**
- Strategic evolution awareness, Build/Buy/Outsource decisions, competitive dynamics analysis

⚠️ **When NOT to use**
- Quick decisions on a component that is obviously commodity — just buy it; mapping adds nothing
- The user need cannot be stated plainly — evolution is meaningless without an anchor need at the top of the chain
- You want a point forecast — maps communicate position and drift, not dates; pair with scenario planning for timing

### Key Steps
1. Define the user need (anchor at top)
2. Map the value chain (components needed to fulfill the need)
3. For each component, assess evolution stage: Genesis (novel), Custom-Built (emerging), Product (standard), Commodity (ubiquitous)
4. Plot on the map
5. Identify strategic moves: build what's evolving, buy/outsource what's commoditized

### Output Template

```
User need: [one plain sentence]

  Need ──┬── [Component A]  custom-built   → build (differentiating)
         ├── [Component B]  product        → buy
         │      └── [Component B1] commodity → outsource
         └── [Component C]  genesis        → option: watch / seed experiment

Movement to expect: [A is drifting toward product within ~x years — plan the transition]
Weakness signals on map: [commodity treated as custom (legacy cost), genesis treated as product (premature standardization)]
Next action: [cheapest strategic move + date]
```

### Failure Modes
- Component soup: mapping at inconsistent granularity (a whole system beside one API call) → fix altitude: decompose until each box is independently buyable or buildable
- Evolution stage argued by opinion: "our CRM is definitely custom" → use stage proxies (certainty of specification, ubiquity of vendors, publication density) and let disagreement flag uncertainty
- Map without moves: a beautiful map that changes no decision → every map session ends with ≥1 build/buy/outsource/watch call and an owner

### Evidence Strength
Practitioner consensus — an applied practice with a growing practitioner base and useful open literature, but no controlled validation of mapping quality or outcome lift; its evolution axis is inherently judgment-based. Value lies in making evolution assumptions explicit and contestable.

### Source
Simon Wardley (2015); Wardley Mapping methodology.

## Game Theory
> source: game-theory.md (original title: Game Theory & Nash Equilibrium)
### Core Concept
Model multi-party decisions as games — players, strategies, payoffs — and predict outcomes that are stable because no player gains by unilateral deviation (Nash equilibrium). The discipline it imposes: stop analyzing your move in isolation; derive the other side's best response first, then your best response to that. It also classifies the game type — prisoners' dilemma (individually rational, collectively bad), coordination, zero-sum, repeated — because the escape from a bad structure is changing the game (commitment, communication, repetition), not playing it better.

### Applicable Scenarios
✅ **Best for**
- Competitive moves where rivals visibly react: pricing against a responder, feature races, bidding/auctions
- Multi-party platform/standard contests and coalition building
- Designing cooperation: contracts, alliances, retaliation rules in repeated relationships
- Any plan silently assuming "the competitor will do nothing"

⚠️ **When NOT to use**
- Single-agent decisions with no strategic interaction (capacity, portfolio, prioritization) — the game frame adds nothing
- 3+ players with unknown payoffs: assumptions collapse and you are decorating opinions with equilibrium language
- Behavioral or emotional conflicts — use Stakeholder Mapping; people are not payoff functions. One counterpart with terms on the table → Principled Negotiation (Decision Making)
- Payoffs not estimable even ordinally — garbage-in equilibria: the matrix looks rigorous and is fiction

### Key Steps
1. Name the players — include the absent ones your move affects (regulators, customers, rivals' rivals)
2. List each player's realistic strategies (including "do nothing")
3. Estimate the payoff matrix per combination; ordinal (win/lose/draw) is enough
4. Mark each player's best response in every column/row
5. Locate the Nash equilibrium or equilibria — where no unilateral deviation pays
6. Classify the game: dilemma / coordination / zero-sum / repeated — a dilemma verdict points to changing payoffs (commitment devices, repetition, side-payments), not to playing harder
7. Derive the move: play the equilibrium, commit visibly (burn the option), signal credibly, or restructure payoffs

### Output Template

```
Players: [each with what they actually control]
Strategies per player: [2-4 realistic options each, "do nothing" included]
Payoff matrix: [ordinal outcome per combination — who gains, who bleeds]
Best responses: [marked per cell]
Equilibrium(a): [stable outcomes + whether multiple]
Game type verdict: [dilemma / coordination / zero-sum / repeated]
Move: [play it / commit / signal / change the payoffs — and the concrete device]
Confidence: [what the verdict survives: payoffs wrong by how much?]
```

### Failure Modes
- Equilibrium worship: multiple equilibria or none in pure strategies → report the set; the real question becomes which one coordination selects
- Rationality overreach: assuming a counterpart optimizes when they satisfice or spite → bound the analysis with best-response ranges instead of point predictions
- Payoff numbers invented to complete the matrix → ordinal and honest beats cardinal and fake; state what would change the verdict
- One-shot analysis of a repeated game: repetition flips incentives (cooperation via tit-for-tat becomes stable); check the shadow of the future before concluding defection
- Decorative matrix: if the completed matrix does not change the move you would have made anyway, the tool misfit — say so and stop

### Evidence Strength
Strong formal core — equilibrium existence results, auction design, and mechanism design are in live industrial use (spectrum auctions, ad auctions); informal strategic sketches have a mixed transfer record, and applied equilibrium claims routinely overstate their precision. Nobel-recognized lineage (Nash, Schelling, auction design).

### Source
John von Neumann & Oskar Morgenstern, *Theory of Games and Economic Behavior* (1944); John Nash, "Equilibrium Points in N-Person Games" (1950); Thomas Schelling, *The Strategy of Conflict* (1960). Admission verdict: **Build** (v0.1.11) — interdependent-decision modeling was absent from the strategy corpus: Porter's Five Forces is static industry structure, not move-and-countermove.

## Scenario Planning
> source: scenario-planning.md
### Core Concept
Under deep uncertainty — where outcomes depend on forces you cannot forecast — stop betting on one predicted future. Construct 3-4 plausible, internally consistent, structurally different futures; test the strategy against every one; act on what survives across all of them (robust moves), place hedges where scenarios diverge, and monitor signposts that tell you which future is arriving.

### Applicable Scenarios
✅ **Best for**
- Multi-year strategy amid regulatory/market/technology upheaval
- Large irreversible bets (capacity, platform, market entry) with long payback
- Challenging a single-point forecast a plan silently depends on

⚠️ **When NOT to use**
- Near-term planning in a stable trend — forecasting plus Product Life Cycle is sharper and cheaper
- Narrow, quantifiable uncertainty (one number, estimable) → Probabilistic Reasoning (Decision Making) — scenarios are for structural, not statistical, uncertainty
- A specific interactive contest against identifiable rivals → Game Theory
- No willingness to act differently per scenario — the exercise becomes a document, not a decision

### Key Steps
1. Define the focal question and time horizon ("Should we build the second factory by 2029?")
2. List driving forces; rank by impact × uncertainty; discard the predetermined (aging population) and the trivial
3. Pick the two highest-impact uncertainties as axes; the 2×2 yields four candidate scenarios
4. Flesh out each scenario: internally consistent narrative, named winners/losers, observable signposts
5. Stress-test the current strategy in each: win / survive / die
6. Choose the response set: no-regret moves (pay off in all four), big bets (pay off in one), hedges (cheap options on divergence)
7. Set signpost monitoring with owners and triggers to re-plan

### Output Template

```
Focal question: [decision + horizon]
Driving forces ranked: [impact × uncertainty, predetermined stripped]
Scenario 1..4: [name + narrative + signposts: [observable events]]
Strategy robustness matrix: [strategy × scenario → win/survive/die]
Response set: no-regret: [moves]; big bets: [moves + the scenario they ride]; hedges: [options + cost]
Signpost dashboard: [event → owner → trigger action]
Confidence: [what would invalidate the driver ranking]
```

### Failure Modes
- Rosy-vs-grim collapse: the four scenarios differ only by mood, not structure → force orthogonal axes and check that each scenario's winners differ
- Forecast in disguise: probabilities assigned to scenarios and one picked → scenarios are instruments for robustness, not weighted predictions
- No decision changed: the strategy survives all four scenarios unchanged → either the strategies tested are too coarse, or say openly what the exercise failed to move
- Signpost-free plan: scenarios written, monitoring never set — the plan is blind within a quarter
- Scenario explosion: six scenarios that nobody can hold in mind → 3-4, structurally distinct, named memorably

### Evidence Strength
Practitioner consensus — Shell's scenario work anticipating the 1973 oil shock is the canonical case, and scenario methods are standard in energy, defense, and sovereign planning; as a forecasting-improvement device the evidence is mixed (scenarios improve preparedness and assumption discipline, not point-forecast accuracy).

### Source
Pierre Wack, "Scenarios: Uncharted Waters Ahead" (HBR, 1985, Shell practice); Peter Schwartz, *The Art of the Long View* (1991). Admission verdict: **Build** (v0.1.12) — deep-uncertainty multi-future strategy was absent: PESTLE scans environment, Game Theory models interaction, Wardley maps evolution; none produces robust-across-futures strategy.

## Balanced Scorecard
> source: balanced-scorecard.md
### Core Concept
Kaplan & Norton's answer to "how do you know your strategy is working": translate the strategy into a **linked set of objectives and measures across four perspectives** — financial, customer, internal business process, learning & growth — arranged as a strategy map. The perspectives form a causal chain: learning and growth enable process, process delivers customer outcomes, customer outcomes drive financial results. The scorecard's real content is the map (the causal links), not the list of measures.

### Applicable Scenarios
✅ **Best for**
- Translating a chosen strategy into an executable measurement system
- Balancing a metric set that has drifted into "revenue only"
- Cascading strategy across an organization that has disconnected goals from outcomes
- Linking investment in capability to results customers and shareholders feel

⚠️ **When NOT to use**
- A startup or single-team product where one metric suffices → North Star Framework plus input metrics is the right size
- The strategy itself is unsettled → BSC measures a strategy you have not chosen; settle it first (Strategy Red Team, or SWOT)
- Only two perspectives get populated — that is a scorecard, not a Balanced Scorecard, and the causal chain does not exist; use OKR + North Star instead
- Reporting and ranking only → BSC without a decision and an owner per objective is a monthly dashboard nobody acts on
- Attribution-grade questions ("which of these four caused revenue?") → BSC is a monitoring and alignment tool, not a causal-inference method
- Very small teams where measurement overhead exceeds the decision value

### Key Steps
1. Clarify the strategy in one sentence: "we will do X, unlike Y, to win at Z" — no measures yet
2. Build the strategy map: objectives per perspective, linked by explicit cause-and-effect arrows (learning → process → customer → financial); every objective should hang off something above it and support something below
3. Choose measures per objective: prefer leading (process, capability) with a lagging partner (outcome); every measure must have a decision attached ("if this moves, we do Y")
4. Set targets and initiatives: the initiative that moves the objective, not the measure
5. Assign owners and cadence: one owner per objective, a fixed review rhythm; BSC fails on cadence before it fails on content
6. Prune: every measure must have an owner and a decision; an unowned measure is deleted, not deferred

### Output Template

```
Strategy: [one sentence — what we will do differently to win]
Strategy map:
  Learning & growth: [objective] ← [initiative]
  Internal process:  [objective] ← depends on above
  Customer:          [objective] ← depends on above
  Financial:         [objective] ← depends on above
Measures:
  [objective] → [leading measure] + [lagging measure] → [decision if it moves]
Initiatives: [objective → initiative → owner]
Pruned: [measures removed for having no decision attached]
Review cadence: [who, when, what triggers a re-plan]
```

### Failure Modes
- Strategy map of wishes: boxes with arrows drawn after the fact to look causal → draw links only where you can name the mechanism ("faster release → fewer escalations → better retention")
- Activity measures crowding out outcomes ("number of training hours") → keep one outcome measure per objective, pair it with a leading indicator
- The four perspectives collapse into financial + one → the balance is gone; if only finance is filled in, use OKR
- Reporting graveyard: measures are collected and reviewed but no decision ever changes → every measure needs a decision attached; if none exists, delete the measure
- Targets copied from industry benchmarks → the benchmark knows nothing about your strategy; set targets from the strategy's own logic
- Scorecard used for individual performance appraisal → measurement becomes self-protection, numbers stop being trustworthy; keep it at the objective level and out of comp
- Created once and never revisited: the strategy changes, the map does not → set the map's re-derivation trigger (strategy shift, new objective, measure with no decisions for two cycles)
- Confusing it with OKR: BSC organizes measures against a strategy; OKR sets time-boxed goals and key results. They compose — BSC chooses what to measure, OKR moves it — but they are not interchangeable

### Evidence Strength
**Mixed.** Adoption is enormous and the two original studies (over a thousand firms, spanning diverse industries) documented real measurement-system effects. The causal claim — that introducing a BSC causes performance improvement — is weakly supported; later work and the 3.0 revision emphasize learning and strategy formulation rather than scorecard mechanics, and practitioner evidence on measurement systems correlating with performance is stronger than evidence that the causal links in a specific map are real. Use it as a disciplined way to connect strategy to measures, not as a performance formula.

### Source
Robert Kaplan & David Norton, "The Balanced Scorecard—Measures That Drive Performance", *Harvard Business Review* (1992); *The Balanced Scorecard* (1996); *The Execution Premium* (2008). Admission verdict: **Build** (v0.1.15) — the v0.1.13 Recipe verdict (OKR + North Star "own" it) was factually wrong: neither holds the strategy→measures translation, so the pointer in `okr.md` was a dead route. BSC composes with OKR rather than duplicating it (choose what to measure vs move it).

## Category Guide
## Strategic Analysis

**When to use**: Need to evaluate overall situation, make directional decisions


### Minimum Information Requirements per Methodology

- **SWOT / PESTLE**: Requires clear analysis target (product/company/market)
- **Porter's Five Forces**: Requires a named industry + major competitors + per-force competitive evidence
- **Business Model Canvas**: Requires clear analysis target (which company/product)
- **Ansoff Matrix**: Requires clear current product scope and market scope
- **Stakeholder Mapping**: Requires clear project/decision scope
- **Blue Ocean Strategy**: Requires current industry competition factor awareness
- **McKinsey 7S**: Requires clear organization/team scope
- **BCG Matrix**: Requires per-product market growth rate and relative market share data
- **Product Strategy Canvas**: Requires team's preliminary thinking on 9-block strategy
- **Lean Canvas**: Requires early business model assumptions + co-founder alignment
- **Startup Canvas**: Requires strategy thinking + cost/revenue structure data
- **JDB Value Proposition**: Requires clear customer + alternative awareness
- **Monetization Strategy**: Requires product form + unit economics data
- **Pricing Strategy**: Requires reachable users for PSM research + value metric candidates
- **Can't-Won't Defensibility**: Requires competitor awareness + own resource inventory
- **Porter Diamond Model**: Requires target country/industry 4-factor data
- **GE-McKinsey Matrix**: Requires per-SBU industry attractiveness and business strength multi-factor data
- **Strategic Group Mapping**: Requires major industry players' strategic variable data
- **Value Chain Analysis**: Requires per-stage cost and value data + competitor comparison
- **Benchmarking**: Requires accessible benchmark data (at least 2 independent sources)
- **Product Life Cycle**: Requires product sales/competition/customer composition trend data
- **VRIO Framework**: L1: enterprise resource/capability inventory; L2: competitor comparison data
- **Wardley Mapping**: Requires value chain component decomposition + per-component evolution stage judgment + major competitor comparison
- **Game Theory**: Requires named players + per-player strategy lists + at least ordinal payoffs per strategy combination
- **Scenario Planning**: Requires a named focal decision + time horizon + awareness of driving forces (the ranking can be built in-session)
- **Balanced Scorecard**: Requires a settled one-sentence strategy (measures follow it, not the reverse) + at least three perspectives with real content

### Routing Trigger Signals

- "Comprehensive internal+external situation assessment" → SWOT (primary) ⚡ If only analyzing industry competitive structure → use Porter's; if only macro environment scan → use PESTLE
- "Industry competitive structure / entry barriers / five forces" → Porter's Five Forces (primary) ⚡ If need comprehensive internal+external assessment → use SWOT; if need intra-industry group comparison → use Strategic Group Mapping
- "Macro 6-dimension environment scan (political/economic/social/technological/legal/environmental)" → PESTLE (primary) ⚡ If need comprehensive internal+external assessment → use SWOT
- "Business model design/evaluation/restructuring" → Business Model Canvas (primary)
- "Multi-stakeholder alignment / driving organizational change" → Stakeholder Mapping (primary)
- "Growth strategy selection / market expansion direction" → Ansoff Matrix (primary)
- "Non-competitive growth / value innovation" → Blue Ocean Strategy (primary)
- "Organizational capability assessment / internal consistency diagnosis" → McKinsey 7S (primary)
- "Product portfolio management / investment balance" → BCG Matrix (primary)
- "Strategy visualization / 9-block strategy canvas" → Product Strategy Canvas (primary)
- "Early-stage startup 30-minute problem-solution fit validation" → Lean Canvas (primary) ⚡ If need to independently iterate strategy and monetization → use Startup Canvas
- "Strategy choice and monetization model design simultaneously with independent iteration" → Startup Canvas (primary) ⚡ If only need quick problem-solution fit validation → use Lean Canvas
- "Value proposition copy / 6-block JTBD template" → JDB Value Proposition (primary)
- "Monetization model selection" → Monetization Strategy (primary)
- "Pricing / price sensitivity assessment" → Pricing Strategy (primary)
- "Moat / competitive non-replicability design" → Can't-Won't Defensibility (primary)
- "Resource/capability assessment / sustainable competitive advantage identification" → VRIO Framework (primary) ⚡ If need to assess per-stage value creation → use Value Chain Analysis
- "National competitive advantage / cross-border site selection / industrial policy" → Porter Diamond Model (primary)
- "Diversified business portfolio / SBU resource allocation" → GE-McKinsey Matrix (primary)
- "Intra-industry competitive structure / strategic groups" → Strategic Group Mapping (primary)
- "Per-stage cost and differentiation analysis / activity-level competitive advantage diagnostics" → Value Chain Analysis (primary) ⚡ If need to assess whether resources themselves constitute advantage → use VRIO
- "Benchmarking best practices / performance gap analysis" → Benchmarking (primary)
- "Product stage strategy / investment timing judgment" → Product Life Cycle (primary)
- "Strategic evolution awareness / value chain visualization / Build vs Buy" → Wardley Mapping (primary)
- "Rival will react to our move / pricing war response / bid against competitors / will they retaliate / trust and retaliation design" → Game Theory (primary) ⚡ If analyzing static industry structure with no specific move → use Porter's Five Forces; if negotiating one counterpart with terms on the table → use Principled Negotiation (Decision Making)
- "Deep uncertainty / multiple plausible futures / what if the market goes either way / stress-test the strategy across futures" → Scenario Planning (primary) ⚡ If uncertainty is narrow and quantifiable (one estimable number) → use Probabilistic Reasoning (Decision Making); if modeling a specific rival interaction → use Game Theory
- "Which metrics should we track / translate strategy into a measurement system / our scorecard only has revenue / cascade strategy into goals" → Balanced Scorecard (primary) ⚡ If the goal is a time-boxed target and key results → use OKR (Decision Making); if you need one north-star metric and its input metrics → use North Star Framework (Product & Growth)

### Common Combinations

- **Strategic planning**: PESTLE → SWOT → OKR
  - Step outputs: PESTLE → O/T factor list with evidence; SWOT → 4-quadrant fit assessment consuming that O/T list; OKR → quarterly objectives with measurable key results
  - Branch: policy or regulatory shock surfacing mid-analysis → re-run PESTLE before continuing; no shocks → proceed
  - Final deliverable: macro scan + 4-quadrant assessment + quarterly OKR sheet — one synthesized conclusion, not three stapled reports
- **Business model design**: PESTLE/Porter's → Business Model Canvas → Value Proposition Canvas
- **Competitive analysis**: Porter's Five Forces → SWOT → First Principles
  - Step outputs: Five Forces → industry structure verdict (where profit pools sit and why); SWOT → position fit consuming that structure analysis; First Principles → challenge any "industry law" the plan quietly assumed
  - Branch: analysis target is one company's full assessment → SWOT leads and Five Forces feeds it (see constraint table); industry entry decision → Five Forces leads
  - Final deliverable: industry structure verdict + positioned assessment + assumption audit — synthesized, not stapled
- **Organizational change**: Stakeholder Mapping → Six Thinking Hats → OKR
- **Growth strategy**: Cynefin (judge problem domain) → Ansoff Matrix (select direction) → Blue Ocean (differentiation)
- **Product portfolio optimization**: BCG Matrix (portfolio classification) → Ansoff Matrix (growth direction) → RICE (execution ranking)
- **Organizational capability diagnosis**: McKinsey 7S (internal consistency) → SWOT (internal-external fit) → OKR (improvement goals)
- **Competitive advantage diagnostics**: Value Chain Analysis → Benchmarking → VRIO
- **Diversified portfolio management**: BCG Matrix (initial screening) → GE-McKinsey Matrix (deep assessment) → Ansoff (growth direction)
- **Industry competitive structure analysis**: Porter's Five Forces (overall) → Strategic Group Mapping (intra-industry groups) → Blue Ocean (breakthrough direction)
- **Product stage strategy**: Product Life Cycle (stage positioning) → BCG Matrix (portfolio mix) → OKR (stage goals)
- **Strategic evolution awareness**: Wardley Mapping (value chain × evolution stage) → Blue Ocean (differentiation direction) → Value Chain Analysis (competitive advantage diagnostics)
- **Technology investment strategy**: Wardley Mapping (component evolution positioning) → Gartner Hype Cycle (technology maturity) → DCF (ROI assessment)

### Methodology Mutual Exclusion and Ordering Constraints

| Constraint pair | Rule | Reason |
| --- | --- | --- |
| Lean Canvas ↔ Startup Canvas | **Pick one**, don't use both simultaneously | Output overlaps heavily; both are BMC adaptations for early-stage startups |
| PESTLE → SWOT | **PESTLE before SWOT** | PESTLE expands the O/T dimensions of SWOT; doing PESTLE first avoids external analysis omissions |
| Porter's Five Forces → SWOT | **Porter's before SWOT** (competitive analysis scenario) | Porter's provides industry structure deep analysis, serving as more complete SWOT input |
| Value Chain Analysis → VRIO | **Value Chain first, then VRIO** (competitive advantage diagnostics scenario) | First identify per-stage value sources, then assess whether resources are sustainable |
| SWOT vs Porter's Five Forces | **Choose by analysis target**: comprehensive single-enterprise assessment→SWOT; industry competitive structure→Porter's | SWOT is 4-quadrant comprehensive assessment; Porter's is industry five-forces deep analysis; different dimensions |
| Game Theory vs Porter's Five Forces | **Choose by question**: which move to make knowing rivals react→Game Theory; what industry structure determines profitability→Porter's | Static structure vs interdependent moves; Five Forces' bargaining-power findings are payoffs input to the game, not a substitute for it |
| Balanced Scorecard vs OKR vs North Star Framework | **Choose by job**: choose which measures reflect a strategy→Balanced Scorecard; set time-boxed goals with key results→OKR (Decision Making); pick one metric plus its input metrics→North Star Framework (Product & Growth) | They compose in that order (what to measure → what to move → the one number), and each has a distinct output; using two interchangeably leaves the strategy unmeasured or the goals unmeasured |
