# Product & Growth (compact aggregate)
> Aggregated from `references/product-growth/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh product-growth "<methodology>"`

## AARRR Funnel
> source: aarrr.md
### Core Concept
5-stage growth funnel: Acquisition → Activation → Retention → Referral → Revenue. Identify which stage is the bottleneck to focus growth efforts.

### Applicable Scenarios
✅ **Best for**
- Growth bottleneck identification
- User lifecycle analysis
- Growth team prioritization

⚠️ **When NOT to use**
- Retention is broken: pouring users into a leaking funnel wastes everything upstream — fix retention first; the funnel's stage order isn't a work order
- Metrics for stages undefined or gameable — a funnel of vanity metrics points experiments in wrong directions
- Products with multi-loop value paths (marketplaces, UGC) — single linear funnel misses loops; consider growth loops alongside

### Key Steps
1. Define metrics for each stage: Acquisition (signups), Activation (first key action), Retention (return usage), Referral (invites), Revenue (payment)
2. Measure conversion rates between stages
3. Identify the stage with the lowest conversion (the bottleneck)
4. Focus growth experiments on the bottleneck stage
5. Re-measure after experiments; iterate

### Output Template

```
Stage metrics (defined before measuring):
  Acquisition: [visits → signups]        [8%]
  Activation:  [signup → first key action: created 1st project] [35%]
  Retention:   [week-4 return rate]      [22%]   ← health check first
  Referral:    [users sending ≥1 invite] [4%]
  Revenue:     [trial → paid]            [9%]

Bottleneck: [Activation 35% vs benchmark x] — why here and not a vanity-low stage: [highest leverage × fixable]
Experiment queue for bottleneck: [3 hypotheses with owners and dates]
Re-measure: [after each experiment — did the stage rate move? did it hold?]
```

### Failure Modes
- Funnel-wide ping-pong: experiments scattered across all five stages each week — motion without leverage → one bottleneck at a time, and re-evaluate only after its rate moves
- Activation defined as login: "activated" users who never touched core value → the activation event must be the first moment of real value, not a technical step
- Referral measured as invites sent, not invites converted: k-factor theater → measure new users acquired through referral, not invitation buttons clicked

### Evidence Strength
Practitioner consensus — the canonical startup metrics funnel; the stage decomposition and bottleneck logic are sensible and near-universally taught, while benchmark conversion rates float around as folklore — treat external benchmarks as rough context and your own trend as the real signal.

### Source
Dave McClure, 500 Startups (2007); *Startup Metrics for Pirates*.

## JTBD
> source: jtbd.md (original title: JTBD — Jobs To Be Done)
### Core Concept
Users "hire" products to get a "job" done. The job is not the product — it's the progress the user wants to make in a specific situation. Focus on the job, not the customer attributes.

### Applicable Scenarios
✅ **Best for**
- Demand mining
- Product positioning
- Competitive replacement analysis

⚠️ **When NOT to use**
- Pure usability refinement of a shipped flow — the job is settled; you need usability testing, not switch interviews
- Aesthetic/emotional products where the "functional job" frame flattens what matters — stretch to social/emotional jobs deliberately or the analysis misses
- Jobs invented from internal brainstorming — JTBD without the switch interview is personas with new vocabulary

### Key Steps
1. Conduct "switch interview": ask about the moment they decided to hire/fire a product
2. Identify the job statement: "When [situation], I want to [motivation], so I can [outcome]"
3. Classify the job: functional / emotional / social
4. Map the job process (8 steps: define → locate → prepare → confirm → execute → monitor → modify → complete)
5. Identify pain points and opportunities in the job process

### Output Template

```
Switch story: [who, from what → to what, when, trigger event]
  Push of the old: [what made the old solution intolerable]
  Pull of the new: [what attracted]
  Anxiety: [what almost stopped the switch]
  Habit: [what nearly kept them]

Job statement: When [I'm onboarding a new analyst], I want to [get our reporting consistent fast], so I can [trust the numbers by Friday]
  Functional: [consistent reports] Emotional: [confidence] Social: [look competent to leadership]

Job map pain points: [biggest friction steps with evidence]
Competition by job: [spreadsheet / agency / doing nothing — all compete for the same job]
Opportunity: [underserved step + what serving it would look like]
```

### Failure Modes
- Product-shaped jobs: "when I want to create a pivot table" — that's a feature, not a job → jobs survive product categories; write them so a non-customer could read them and nod
- Single-interview certainty: one vivid switch story becomes strategy → look for the pattern across switches (and fires); n of 1 is anecdote
- Ignoring the fire side: why customers leave teaches as much as why they buy → interview recent quitters, not just recent adopters

### Evidence Strength
Practitioner consensus — switch interviewing and job statements are widely credited for demand insight and stable positioning (jobs outlive products); the theory's stronger causal claims (jobs fully predict adoption) remain debated in the innovation literature, and interview-based methods inherit small-n and recall-bias limits.

### Source
Clayton Christensen, *The Innovator's Solution* (2003); Anthony Ulwick, *What Customers Want*.

## Design Thinking
> source: design-thinking.md
### Core Concept
Human-centered design loop: Empathize → Define → Ideate → Prototype → Test. A non-linear, iterative process for creative problem solving that keeps the user at the center.

### Applicable Scenarios
✅ **Best for**
- New product 0-to-1 design
- Service design
- Innovation workshops

⚠️ **When NOT to use**
- The problem is already well-defined and the question is technical execution — the loop's front end would re-litigate a settled problem
- Hard constraints dominate (regulatory, safety-critical) — user desirability can't veto engineering necessity; run compliance in parallel, not after
- Workshop-only adoption: one ideation offsite labeled "design thinking" with no user contact — empathy is the load-bearing stage; skip it and it's just brainstorming theater

### Key Steps
1. **Empathize**: conduct user interviews, observations, immerse in user context
2. **Define**: synthesize findings into a clear problem statement (point of view)
3. **Ideate**: generate many solutions (diverge), then select promising ones (converge)
4. **Prototype**: build quick, low-fidelity prototypes of top ideas
5. **Test**: put prototypes in front of users, learn, iterate

### Output Template

```
Empathy evidence: [n interviews / observations — key quotes and behaviors, not summaries]
POV (Define): [User] needs [need] because [insight] — one sentence, evidence-backed

Ideation: [n ideas generated] → converged shortlist [3], selection criteria: [desirability evidence / feasibility note]
Prototypes: [what each shows — deliberately low-fi: paper, clickthrough, service walkthrough]
Test rounds: [n users per round] — what users did/said → what changed as a result
Iteration log: [round → learning → change] — the loop's actual output

Exit: [validated concept + evidence, or killed cheaply — both are wins]
```

### Failure Modes
- Skipping to solutions: ideation starts before empathy evidence exists → no Define stage without named user evidence; count interviews before counting ideas
- Prototype inflation: pixel-perfect prototypes that took weeks — too precious to change or discard → fidelity matches the question being tested; if it hurts to throw away, it was overbuilt
- Test as validation ritual: showing prototypes hoping to hear "great" → tests are for learning what breaks; log behavior, not compliments

### Evidence Strength
Practitioner consensus — the process packages long-established design practices (user research, iterative prototyping); systematic reviews find benefits for user-centered outcomes but note weak comparative evidence and high variance in how teams apply it — the human-contact stages carry the value; the ceremony does not.

### Source
Stanford d.school (Hasso Plattner Institute); IDEO popularization.

## Lean BML Loop
> source: lean-bml.md (original title: Lean BML Loop (Lean Build-Measure-Learn Loop))
### Core Concept
Minimize assumptions → Build the minimum thing to test → Measure results → Learn and decide (pivot or persevere). The fastest loop wins.

### Applicable Scenarios
✅ **Best for**
- Product validation
- MVP design
- Hypothesis testing

### Key Steps
1. State the riskiest assumption clearly
2. Design the minimum build to test it (not a full product — the smallest experiment)
3. Define success metrics and threshold in advance
4. Build and run the experiment
5. Measure: did it meet the threshold?
6. Learn: Pivot (change assumption) or Persevere (continue)

### When NOT to use

- The riskiest assumption is already verified — the loop re-tests a settled question and burns a cycle for nothing
- Safety-critical or irreversible domains (medical dosing, structural load, security controls): "minimum build to test" and "pivot" are the wrong vocabulary
- Regulated processes where the experiment itself must be protocol-compliant (clinical trials, financial model validation)
- A team with one committed direction and no capacity for parallel experiments — the loop optimizes iteration speed, not delivery speed

### Output Template

```
Riskiest assumption: [the one whose falsity kills the plan]
Minimum build to test it: [smallest artifact + what it deliberately omits]
Success metric + threshold: [number, fixed BEFORE the run]
Result: [metric measured] vs [threshold] → met / missed
Decision: Pivot (assumption was wrong because…) | Persevere (assumption held; next riskiest assumption is…)
```

### Failure Modes

- **Threshold set after seeing results** — the loop quietly becomes "keep building what works"; write the number before the run or it is not a test
- **The minimum build grows into a product** — scope creep between steps 2 and 4; anything not required to falsify the assumption is out
- **Measuring activity instead of the assumption** — shipping is not learning; the metric must move if the assumption is false
- **Pivoting without naming the next riskiest assumption** — the loop restarts at "build" and skips the diagnostic

### Evidence Strength

**Practitioner consensus on the loop, weaker on "fastest loop wins."** The build-measure-learn framing is the most widely adopted loop in product practice. The speed claim is weaker: a fast loop only helps when the assumption under test is genuinely the riskiest, which is a judgment the framework cannot verify for you.

### Source
Eric Ries, *The Lean Startup* (2011).

## Value Proposition Canvas
> source: value-proposition-canvas.md
### Core Concept
Two-part fit validation: Customer Profile (Jobs, Pains, Gains) ↔ Value Map (Products/Services, Pain Relievers, Gain Creators). When the two parts achieve fit, you have product-market fit evidence.

### Applicable Scenarios
✅ **Best for**
- PMF (Product-Market Fit) validation
- Feature prioritization
- Differentiated positioning

⚠️ **When NOT to use**
- Desk-fit exercises — filling both circles from internal opinion then declaring fit; every pain and gain must trace to customer evidence (**The Mom Test** for interviews, **JTBD** for job statements)
- Ranking a large backlog — the canvas shows gaps, not ordered bets; combine with impact/effort or **Kano** for prioritization
- Exhaustive lists — 25 pains with equal weight is not analysis; force the top 2-3 per block in the customer's own ranking
- Claiming PMF — fit on paper is hypothesis, not evidence; pair with experiments before building

### Key Steps
1. **Customer Profile**: List customer Jobs (functional/social/emotional), Pains (before/during/after the job), Gains (expected/desired/unexpected outcomes)
2. **Value Map**: List your Products/Services, how each relieves specific Pains, how each creates specific Gains
3. Assess fit: does each Pain have a reliever? Does each Gain have a creator?
4. Identify gaps: pains without relievers, gains without creators
5. Prioritize features to close the biggest gaps
6. Validate with customer interviews

### Output Template

```
Segment: [segment]  Evidence: [# interviews / data sources]
Customer Profile
  Jobs: [functional / social / emotional — ranked by importance]
  Pains: [top 2-3, ranked by severity]
  Gains: [expected / desired / unexpected — ranked]
Value Map
  Products/Services: [list]
  Pain relievers: [which reliever kills which pain — explicit pairing]
  Gain creators: [which creator delivers which gain — explicit pairing]
Fit gaps: [pains without relievers / gains without creators]
Priorities: [features closing the biggest gaps]
Validation: [interview or experiment plan for the top gap]
```

### Failure Modes
- Self-referential fit: the team writes both circles and celebrates alignment → require evidence per item, mark unverified ones, and treat unvalidated fit as a hypothesis map
- Pain/gain inflation: exhaustive lists dilute focus → force-rank to the top 2-3 per block; customers don't experience 25 pains equally
- Pairing theater: drawing a reliever next to a pain doesn't make it relieve → validate each pairing in interviews; weak relievers create fit illusions
- Canvas as conclusion: fit on paper treated as PMF evidence → the canvas generates hypotheses; demand must be validated with experiments before build

### Evidence Strength
Practitioner consensus — a standard lean-startup and design tool that structures hypothesis formation well; its limitation is that canvas "fit" is not validated demand — the evidence value depends entirely on whether the customer profile side is grounded in real customer research rather than internal assumption.

### Source
Alexander Osterwalder et al., *Value Proposition Design* (2014).

## SCAMPER
> source: scamper.md
### Core Concept
7-dimension creative trigger for systematic innovation: Substitute / Combine / Adapt / Modify (Magnify) / Put to other use / Eliminate / Reverse. Forces thinking about existing products from 7 different angles.

### Applicable Scenarios
✅ **Best for**
- Product iteration
- Experience optimization
- Systematic innovation workshops

⚠️ **When NOT to use**
- Zero-based innovation — SCAMPER iterates an existing artifact; from-scratch concepts need open generative methods, not 7 angles on what exists
- Unvalidated idea generation — SCAMPER yields quantity, not quality; without screening it feeds the backlog with gimmicks
- Substitute for diagnosis — pushing modification angles at a misidentified job produces polished wrongness; nail the job with **JTBD** first
- Strategy setting — which dimension to push should follow a positioning insight, not mechanical traversal of the letters

### Key Steps
1. Take the existing product/service/process as the target
2. Apply each SCAMPER dimension:
   - **S**ubstitute: what component can be replaced?
   - **C**ombine: what can be merged?
   - **A**dapt: what can be borrowed from elsewhere?
   - **M**odify/Magnify: what can be exaggerated or changed?
   - **P**ut to other use: who else could use this?
   - **E**liminate: what can be removed?
   - **R**everse/Rearrange: what can be reordered?
3. Evaluate generated ideas for feasibility and impact
4. Select top ideas for prototyping

### Output Template

```
Target: [product/service/process + current state in one line]
S Substitute: [component → replacement]
C Combine: [what merges with what]
A Adapt: [borrowed from which context]
M Modify/Magnify: [what scales, shrinks, or changes shape]
P Put to other use: [new user / new scenario]
E Eliminate: [what gets removed + what risk that carries]
R Reverse/Rearrange: [what sequence or layout inverts]
Screen: [top ideas by impact × feasibility → prototype candidates]
```

### Failure Modes
- Mechanical traversal: forcing one idea per letter produces filler → treat the dimensions as triggers; linger where they spark and allow zero ideas for some letters
- Quantity worship: 40 ideas presented as the deliverable with no screening → always close with impact × feasibility screening; ideation is half the work, evaluation is the other half
- Anchor blindness: 7 angles on the same artifact still anchor to it → occasionally pair with a from-scratch prompt ("if this didn't exist, what would we build?")
- Novelty bias: weirder ideas feel more creative in the room → judge ideas by evidence of user value, not session energy

### Evidence Strength
Practitioner consensus — a widely used ideation heuristic with no formal validity studies; its value is as a structured prompt set that reduces blank-page paralysis and forces angles teams skip, not as a validated predictor of which ideas will succeed.

### Source
Bob Eberle (1971); based on Alex Osborn's brainstorming techniques.

## Kano Model
> source: kano.md
### Core Concept
Classify features into 5 categories based on how they affect satisfaction: Must-be (dissatisfiers if absent), Performance (linear satisfaction), Excitement (delighters), Indifferent (don't matter), Reverse (some users dislike). Prevents over-investing in features that don't move satisfaction.

### Applicable Scenarios
✅ **Best for**
- Requirement nature classification
- Satisfaction strategy
- Feature type judgment

⚠️ **When NOT to use**
- Fewer than ~50 credible respondents per feature set — the classification matrix is statistical; small samples produce noise labeled as insight
- Features users can't meaningfully imagine (novel technology) — both Kano questions assume the respondent can picture presence and absence
- As the sole prioritization input — Kano reads satisfaction impact, not effort, revenue, or strategy; pair with RICE/ICE

### Key Steps
1. List candidate features
2. Design Kano questionnaire: for each feature, ask functional (if present) and dysfunctional (if absent) questions
3. Classify each feature: Must-be / Performance / Excitement / Indifferent / Reverse
4. Prioritize: Must-be first, then Performance, then selective Excitement
5. Monitor: features migrate from Excitement → Performance → Must-be over time

### Output Template

```
Survey: n=[respondents], segment [who], features [list]

| Feature        | Functional Q: "if you had X" | Dysfunctional Q: "if you didn't" | Classification | Strength |
| -------------- | ---------------------------- | -------------------------------- | -------------- | -------- |
| [offline mode] | like / must-have             | normal / don't care              | Must-be        | strong   |
| [AI summaries] | love it                      | neutral                          | Excitement     | medium   |
| [skins]        | neutral                      | neutral                          | Indifferent    | —        |
| [forced tour]  | dislike                      | like it                          | Reverse        | —        |

Priority: 1. Must-be gaps [list] 2. Performance investments [list] 3. selective delighters [1 max, cheap ones]
Migration watch: [which features crossed from delighter to expected since last survey]
```

### Failure Modes
- Self-reported delight: users claiming features they'd never use as "must-haves" — stated importance inflates → cross-check with behavior data where available; weight Must-be only when both agree
- Category from one answer pair: classification needs the full answer matrix with strength (mixed answers mean ambiguity, not a category) → use the standard evaluation table, report ambiguous separately
- Kano rerun never: delighters from 2020 are today's table stakes → re-classify annually or at major version points; the model describes a moving target

### Evidence Strength
Practitioner consensus — the satisfaction asymmetry it captures (absence hurts more than presence helps, for basics) is consistent with well-known satisfaction research; the questionnaire method is straightforward but sensitive to sample quality and question wording, and feature classifications should be treated as segment-specific snapshots rather than stable truths.

### Source
Noriaki Kano (1980s); customer satisfaction model.

## North Star Framework
> source: north-star.md
### Core Concept
Define one North Star Metric (NSM) that best captures the core value your product delivers to customers, plus 3-5 input metrics that drive it. Aligns the entire organization around a single growth direction.

### Applicable Scenarios
✅ **Best for**
- Metrics framework design
- Company-wide growth alignment
- Cross-functional coordination

⚠️ **When NOT to use**
- Pre-PMF products — core value is still being discovered; locking a metric entrenches a wrong hypothesis
- Multi-sided or heavily multi-segment products — a single blended NSM can hide one side's decline; define per-side metrics alongside
- Gameable metrics — signups, sessions, raw counts rise while value falls; any NSM needs counter-metrics from day one
- Metric diagnosis — the framework aligns direction but doesn't explain why a number moved; use **Cohort Analysis** or **RFM Model** to dissect changes

### Key Steps
1. Define your product's core value proposition
2. Identify the metric that best captures that value delivery (NSM)
3. Good NSM criteria: reflects customer value, is a leading indicator, is actionable, is measurable
4. Identify 3-5 input metrics that drive the NSM
5. Build a metrics hierarchy: Input Metrics → NSM → Business Outcomes
6. Align teams around input metrics they can influence

### Output Template

```
Core value proposition: [what value, for whom]
North Star Metric: [precise, auditable definition]
  Why it captures customer value: [reasoning]
  Checks: leading? actionable? measurable? game-resistant? [assessment]
Input metrics (3-5): [each with owning team + baseline + target]
Counter-metrics: [what catches gaming / quality erosion]
Hierarchy: [input] → [NSM] → [business outcome]
Review cadence: [who reviews what, how often]
Re-validation trigger: [strategy shift that forces an NSM rethink]
```

### Failure Modes
- Gamed metric: the NSM climbs while customer value falls (signups, sessions, low-intent actions) → pair the NSM with counter-metrics and quality thresholds that can veto growth
- Proxy drift: the metric stops tracking value as the product evolves → treat the NSM as a hypothesis and re-validate it on strategy shifts
- Input sprawl: 15 input metrics nobody owns → cap at 3-5, each with a named owning team and a baseline
- One-metric tyranny: optimizing a blended NSM by sacrificing a segment or marketplace side → segment the NSM or add per-side metrics; averages hide collapsing cohorts

### Evidence Strength
Practitioner consensus — the framework is standard growth practice and reliably aligns organizations around value delivery, but metric choice is judgment rather than science: a wrong NSM efficiently aligns the whole company in the wrong direction, which is why counter-metrics and periodic re-validation are mandatory companions rather than optional extras.

### Source
Sean Ellis & Morgan Brown, *Hacking Growth* (2017); Amplitude's North Star framework.

## Category Guide
## Product & Growth

**When to use**: Product design, user growth, demand validation


### Minimum Information Requirements per Methodology

- **AARRR**: Requires existing product user data or clear business stage
- **Value Proposition Canvas**: Requires at least preliminary user interview data or hypotheses
- **SCAMPER**: Requires clear existing product/service/process as transformation target
- **Kano Model**: Requires candidate feature list + accessible target users (for survey)
- **North Star**: Requires clear product core value proposition
- **JTBD**: Requires accessible target users for interviews (JTBD is a qualitative framework, uncovering real jobs through interviews)
- **Design Thinking**: Requires clear problem/user group + cross-functional team commitment
- **Lean BML Loop**: Requires expressible minimum hypothesis + measurable learning metrics

### Routing Trigger Signals

- "What job do users want done / feature substitution analysis / demand mining" → JTBD (primary) ⚡ If need to describe typical user's complete profile → use User Personas (Market Research); if need empathetic understanding of user feelings → use Empathy Map (User Research)
- "Growth bottleneck analysis" → AARRR Funnel (primary)
- "0-to-1 product/service design" → Design Thinking (primary)
- "Product iteration hypothesis validation" → Lean BML Loop (primary)
- "Product-demand fit validation" → Value Proposition Canvas (primary)
- "Systematic product/service creativity" → SCAMPER (primary)
- "Feature requirement nature classification" → Kano Model (primary)
- "Key metrics framework design" → North Star Framework (primary)

### Common Combinations

- **Product innovation**: JTBD → Design Thinking → Lean BML
- **Systematic creativity**: Six Thinking Hats (Green Hat) → SCAMPER → RICE (screening)
- **Growth diagnostics**: AARRR → 5 Whys → RICE
- **Requirement full lifecycle**: Kano (classify nature) → MoSCoW (scope) → RICE (prioritize)
- **Metrics framework**: North Star (define core metric) → AARRR (layered decomposition) → OKR (goal alignment)

### Methodology Mutual Exclusion and Ordering Constraints

| Constraint pair | Rule | Reason |
| --- | --- | --- |
| JTBD vs User Personas | **Choose by goal**: uncover users' "jobs"→JTBD; describe typical user archetype→Personas | Input data may overlap but output purposes differ; JTBD outputs job statements, Personas outputs user profiles |
| JTBD vs Empathy Map | **Choose by goal**: uncover functional/emotional jobs→JTBD; empathetic understanding of user feelings→Empathy Map | JTBD is a qualitative interview framework; Empathy Map is an empathy mapping tool |
| Kano → MoSCoW → RICE | **Requirement full lifecycle order** | Kano classifies nature → MoSCoW scopes → RICE prioritizes; order cannot be reversed |
