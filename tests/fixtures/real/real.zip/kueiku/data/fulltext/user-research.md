# User Research (compact aggregate)
> Aggregated from `references/user-research/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh user-research "<methodology>"`

## Customer Journey Map
> source: customer-journey.md
### Core Concept
Visualize the user's complete journey across all touchpoints, mapping actions, emotions, pain points, and opportunities at each stage. Enables service optimization and cross-department alignment.

### Applicable Scenarios
✅ **Best for**
- Service optimization
- Product experience design
- Cross-department alignment

⚠️ **When NOT to use**
- Pre-purchase touchpoint dynamics only — the **Consumer Decision Journey** models the consideration/advocacy loop more sharply; a journey map earns its cost when service stages (onboarding, support, renewal) enter scope
- No research in hand — mapping without interviews produces the org chart of wishes; start with interviews (**The Mom Test** format works)
- Every persona × scenario at once — comprehensive maps become wall art; fix the highest-impact persona/scenario pair first
- As a substitute for ownership — a map with no stage owners is a poster, not a tool

### Key Steps
1. Define the persona and scenario
2. Map journey stages: Awareness → Consideration → Purchase → Onboarding → Usage → Support → Renewal/Churn
3. For each stage, document: user actions, touchpoints, emotions (high/low), pain points
4. Identify "moments of truth" (critical decision points) and pain peaks
5. Prioritize improvement opportunities based on impact and feasibility
6. Share with cross-functional teams for alignment

### Output Template

```
Persona: [name]  Scenario: [specific goal]  Evidence: [# interviews / data sources]
Stage: [Awareness / Consideration / Purchase / Onboarding / Usage / Support / Renewal]
  Actions: [what the user does]
  Touchpoints: [where it happens]
  Emotion: [high/low + trigger]
  Pain points: [friction, ranked by severity]
Moments of truth: [critical decision points]
Top opportunities: [ranked by impact × feasibility, each with owner + metric]
```

### Failure Modes
- Aspirational journeys: stages drawn from how the process should work → source every action and emotion from interviews, logs or tickets; mark unverified cells as hypotheses
- Persona-stuffed maps: one generic "user" journey fits nobody → one persona and one scenario per map; parallel journeys get parallel maps
- Pain dumps without prioritization: 40 pain points, zero decisions → force-rank to the top 3 before the workshop ends
- Map-as-deliverable: a beautiful artifact nobody revisits → attach owners and metrics to the top opportunities and review at operating cadence

### Evidence Strength
Practitioner consensus — journey mapping is a standard service-design and CX practice with consistent reported value for cross-functional alignment; its output is only as good as the underlying research, and in practice most maps underweight evidence in favor of internal assumptions — treat unverified cells as hypotheses to test.

### Source
Service design methodology; widely used in UX and customer experience.

## Empathy Map
> source: empathy-map.md
### Core Concept
4-dimension user profile: Say / Do / Think / Feel. Forces the team to go beyond demographics and truly empathize with the user's experience. Built from interview data, not assumptions.

### Applicable Scenarios
✅ **Best for**
- User research kickoff
- Persona supplementation
- Building user empathy in teams

⚠️ **When NOT to use**
- No interview data — filling quadrants from imagination is assumption mapping, not empathy; run interviews first (**The Mom Test** format works)
- Making positioning or prioritization decisions — the map builds shared understanding, not decision-grade output; use **JTBD** or the **Value Proposition Canvas** for that
- One map for a whole segment — users within a segment vary; build per persona and label the evidence base
- Alignment theater — a one-hour workshop with no follow-through produces a poster; convert contradictions into research questions or design decisions

### Key Steps
1. Conduct 1-2 user interviews (minimum)
2. Create a large 4-quadrant canvas: Say / Do / Think / Feel
3. Populate each quadrant with direct quotes and observations from interviews
4. Identify contradictions (e.g., says X but does Y)
5. Synthesize key insights: what does the user really care about?
6. Use as input for personas, JTBD, or design decisions

### Output Template

```
User: [persona/segment]  Evidence base: [# interviews, dates]
SAY: [direct quotes, verbatim]
DO: [observed behaviors, from logs or observation]
THINK: [beliefs and concerns — inferred, marked as inference]
FEEL: [emotional states + the moment that triggers them]
Contradictions: [says X but does Y → what it implies]
Insights: [one line each, evidence-linked]
Handoff: [feeds which persona / JTBD statement / design decision]
```

### Failure Modes
- Invention in disguise: quadrants filled from team imagination → every cell must trace to a quote or observation; mark Think/Feel inferences explicitly and verify them in the next round
- Taking SAY at face value: what users say conflicts with what they do → treat contradictions as the highest-value output, not noise to smooth over
- One vivid interview generalized: a single story becomes "the user" → aggregate per segment and note the n behind the map
- Canvas as endpoint: the map gets hung up and nothing changes → convert insights into JTBD statements, design decisions or research questions with owners

### Evidence Strength
Practitioner consensus — the empathy map is a widely used synthesis and team-alignment tool in design practice with no formal psychometric validation; it is a strong thinking scaffold and a weak data source — its value depends entirely on being grounded in real interview and observation data.

### Source
Dave Gray, *Gamestorming* (2010); Stanford d.school empathy mapping tool.

## Consumer Decision Journey
> source: consumer-decision-journey.md
### Core Concept
Non-linear decision journey: Consider → Evaluate → Purchase → Experience → Advocate. Unlike the traditional funnel, consumers loop back and forth between stages. Map touchpoints at each stage to optimize the journey.

### Applicable Scenarios
✅ **Best for**
- Journey optimization
- Touchpoint design
- Churn analysis
- Loyalty loop design

⚠️ **When NOT to use**
- B2B committee buying — the CDJ models an individual consumer loop; multi-stakeholder purchases need **B2B Buying Center Mapping** (Go-to-Market)
- Service-stage redesign (onboarding, support, renewal) — the **Customer Journey Map** covers the full lifecycle with stage owners; the CDJ is sharpest on the pre-purchase loop and advocacy
- Categories where the loop doesn't cycle — one-shot or infrequent purchases may have no loyalty loop to optimize
- Replacing measurement with mapping — the journey is a hypothesis; stage-level churn data decides, not the diagram

### Key Steps
1. Map the 5 stages for your product category
2. For each stage, identify: touchpoints, decision drivers, emotional state, drop-off risk
3. Measure: experience score per stage, churn rate per stage
4. Identify the weakest stage (highest churn or lowest satisfaction)
5. Design interventions for the weakest stage
6. Monitor the loyalty loop: do advocates feed back into Consider?

### Output Template

```
Category: [product category] — confirm the 5 stages apply: [evidence]
Stage: [Consider / Evaluate / Purchase / Experience / Advocate]
  Touchpoints: [ranked by influence]
  Decision drivers: [what moves users forward]
  Drop-off risk: [where and why users stall or exit]
  Experience score: [x]  Churn rate: [%]
Weakest stage: [name] — evidence: [data]
Intervention: [what changes, owned by whom, measured by]
Loyalty loop: [does advocacy feed Consider? evidence: [data]]
```

### Failure Modes
- Funnel relapse: drawing the journey as one-way arrows → keep the loops explicit; the model's entire value is that evaluation and advocacy feed back into consideration
- Mapped but unmeasured: stages charted from internal opinion → ground each stage in behavioral or survey data; unmeasured stages hide the real weakest link
- Optimizing the measurable stage: fixing checkout because it's instrumented while consideration leaks silently → rank stages by drop-off and satisfaction evidence, then fix the weakest
- Assumed advocacy: treating the loyalty loop as automatic → measure whether advocates actually feed new consideration; in most categories the loop needs engineering, not hope

### Evidence Strength
Mixed — the CDJ reframed funnel thinking and is widely adopted in consumer marketing, but its empirical basis is McKinsey's own category research rather than a broad independent literature; stage universality and loyalty-loop strength vary by category, and low-involvement purchases often skip the full loop. Use it as a mapping lens validated per category, not a universal sequence.

### Source
McKinsey & Company, *The Consumer Decision Journey* (2009).

## Maslow Hierarchy
> source: maslow-hierarchy.md (original title: Maslow's Hierarchy of Needs)
### Core Concept
5-level need hierarchy: Physiological → Safety → Love/Belonging → Esteem → Self-Actualization. Users are motivated by their current dominant unmet need. Products that address the right need level resonate more deeply.

### Applicable Scenarios
✅ **Best for**
- User need mining
- Product positioning
- Marketing appeal design
- Upgrade path planning

⚠️ **When NOT to use**
- Ladder-literal product reasoning — assuming users must satisfy lower needs before your higher-level appeal lands; needs don't march in strict order, so treat the hierarchy as a lens, not a sequence
- Feature prioritization — mapping backlog items to pyramid levels is pseudo-rigor; use **Kano Model** for feature-level decisions
- Single-level positioning — real products serve several levels at once (safety plus belonging); map the mix, not one rung
- Cross-cultural universality claims — need salience varies by culture and context; validate the dominant need locally before building appeals

### Key Steps
1. Identify your target users' dominant need level through interviews/behavior analysis
2. Map your product's value proposition to the need hierarchy
3. Assess: does your product address the right need level for your target users?
4. Design marketing appeals that resonate with the dominant need level
5. Plan upgrade paths: as lower needs are met, users seek higher-level fulfillment

### Output Template

```
Target users: [segment]  Evidence: [# interviews / behavior data]
Dominant need level: [Physiological / Safety / Belonging / Esteem / Self-Actualization] — salience: [strong/mixed/weak]
Secondary needs in play: [levels + evidence]
Product mapping: [which need(s) our value proposition actually serves]
Fit assessment: [does the dominant need match what we serve? what's the gap?]
Appeal design: [message tuned to the dominant need — don't claim a level we don't deliver]
Upgrade hypothesis: [as X is met, users seek Y — and what product change serves it]
```

### Failure Modes
- Ladder literalism: treating the hierarchy as a strict sequence users climb → use it to diagnose need salience; people pursue multiple levels at once and skip levels
- Single-rung positioning: pinning the product to "self-actualization" while ignoring the security expectations that gate adoption → map the full mix of needs the product touches
- Culture-free universality: applying Western-individualist salience everywhere → validate which needs dominate in this market's context before crafting appeals
- Feature-level misapplication: rating backlog items by pyramid level → Maslow informs positioning and messaging, not feature ranking; that's **Kano Model**'s job

### Evidence Strength
Contested — as a strict motivational sequence the hierarchy has weak empirical support: later research shows needs pursued in parallel with order varying by person and culture. It remains a useful heuristic lens for need salience and messaging design, but do not build product logic on the assumption that needs are satisfied in order.

### Source
Abraham Maslow, *A Theory of Human Motivation* (1943).

## Qualitative Research Plan
> source: research-plan.md
### Core Concept
Design the whole study before talking to any user: goal → method & sample → screener → interview guide → analysis plan. Division of labor with The Mom Test: Mom Test is the interviewing *attitude* (ask about past facts, not future predictions); this card is the *full study design* — who to recruit, what to ask, how findings feed a decision. It sits upstream of analysis cards: its outputs (transcripts from well-chosen participants) are the raw material Empathy Map and Customer Journey Map consume.

### Applicable Scenarios
✅ **Best for**
- Planning generative interviews, usability tests, diary studies, contextual inquiries
- Vague research requests ("we want to talk to users about onboarding") that need structure
- Before recruiters are engaged or a discussion guide is written

⚠️ **When NOT to use**
- The decision is already made and only confirmation is wanted — research can't help; skip it
- The question is quantitative (how many / how much) — run surveys or log analysis
- Informal 1:1 chats with no recruitment, screener, or guide — a checklist suffices

### Key Steps
1. **Clarify the goal**: write the Big Q — specific enough to answer, broad enough for surprise — starting with a finite outcome verb: describe / identify / evaluate / compare / characterize ("understand" and "explore" have no finish line). Then decision mapping: name the concrete decision this research feeds ("whether to add X to the roadmap"). No decision = sideshow; fix or cancel. Draft the Little q: an experience-near opener ("tell me how you handle X day-to-day").
2. **Choose method & sample**: how people actually do it → contextual inquiry; mental models and motivations → semi-structured interviews (default); behavior over time and triggers → diary study. Sample: ~5 per segment for usability (uncovers ~80% of issues), 8-12 per segment for generative interviews (thematic saturation). Profile by behavior, not demographics — "switched tools in the last 6 months" beats "ages 25-40".
3. **Design the screener**: 2-4 questions, screen-outs first so unqualified applicants exit cheaply. No yes/no questions — people agree to win the incentive; ask for specific tools, quantities, dates instead. Clarity over cleverness: ambiguous phrasing silently screens out the qualified. If budget allows, end with one articulacy check ("tell me about a recent time you…") — a storied answer previews interview data quality.
4. **Write the interview guide**: hourglass structure (general → specific → general). Open with master/apprentice framing: the participant is the expert; "we're testing the product, not you." Excavate stories — on "I usually…", redirect: "walk me through a specific time that happened." Probe with their own words ("what were you thinking at that moment?", "what happened next?"). Ban leading questions:
   - "Is this easy to use?" → "How would you describe using it?"
   - "Don't you hate when…?" → "What happened the last time you…?"
   - "Would you use a feature that…?" → "What did you do last time you needed to…?"
5. **Pre-register the analysis plan**: before fieldwork, fix the coding approach (in-vivo: participants' words; descriptive: your labels), the dimensions you'll code, and how themes map back to the Big Q's decision. This is the contract that stops post-hoc storytelling; deviations get documented, not hidden.

### Output Template

```
Big Q: [finite-verb question] → Feeds decision: [one concrete decision]
Method: [interviews / inquiry / diary] — n=[8-12 generative / 5 usability] per segment — [60] min
Screener: Q1 [screen-out] → Q2 [target behavior] → Q3 [articulacy check]
Guide: Little q opener → topics as story prompts + probes → summary check + wrap-up
Analysis plan (pre-registered): [coding approach + dimensions] → mapped to [decision]
```

### Failure Modes
- "Understanding" as the goal: open-ended objectives never terminate → rewrite with a finite verb and a named decision
- Demographic recruiting: screening for age and title instead of the behavior under study → recruit people who actually do the thing
- Leading questions smuggled in: the answer is installed by the question → episodes and past behavior only; the ban list above is the check
- Post-hoc analysis: themes decided after seeing the data → pre-register dimensions in step 5 and treat them as a commitment device

### Evidence Strength
Practitioner consensus — grounded in documented interview biases (social desirability, incentive gaming) and widely taught research-design practice; sample-size figures are heuristic saturation estimates, not statistical guarantees.

### Source
Qualitative research methodology tradition (contextual inquiry, master-apprentice framing).
Provenance: five-phase planning flow absorbed from [cookiy-ai/user-research-skill](https://github.com/cookiy-ai/user-research-skill) (MIT license); platform bindings stripped, rewritten in kueiku style, absorbed 2026-09.
Admission: Build (new entry) — owns whole-study design before fieldwork (goal → sample → screener → guide → analysis plan); user-research entries each covered a single method, not the sequencing.

## Category Guide
## User Research

**When to use**: Deep understanding of user needs, behaviors, pain points


### Minimum Information Requirements per Methodology

- **Customer Journey Map**: Requires observable user behavior path data or interviews
- **Empathy Map**: Requires at least 1-2 user interview records
- **Consumer Decision Journey**: Requires per-stage touchpoints + experience scores + churn data
- **Maslow Hierarchy**: Requires user interview/behavior data/review mining to determine dominant need level
- **Qualitative Research Plan**: A named decision the research feeds + access to participants matching the target behavior

### Routing Trigger Signals

- "User journey mapping" → Customer Journey Map (primary)
- "Understanding user feelings / pain point empathy" → Empathy Map (primary) ⚡ If need to uncover users' "jobs" → use JTBD (Product & Growth)
- "User persona" (backup) → Empathy Map (as persona supplement) ⚡ If need complete user archetype description → use User Personas (Market Research)
- "Decision journey optimization / touchpoint design / churn analysis" → Consumer Decision Journey (primary)
- "User need mining / marketing appeal design / need hierarchy" → Maslow Hierarchy (primary)
- "Research plan / interview study design / screening questions / discussion guide" → Qualitative Research Plan (primary)
- "We want to talk to users" (vague, pre-fieldwork) → Qualitative Research Plan (primary) ⚡ If data is already collected → use Qualitative Synthesis (Research Methodology)

### Common Combinations

- **Need mining**: Empathy Map → Customer Journey → JTBD
- **Service optimization**: Customer Journey → SCAMPER (creative improvement)
- **Need level positioning**: Empathy Map → Maslow Hierarchy → User Personas
- **Decision journey optimization**: Consumer Decision Journey → RFM Model (identify key groups) → A/B Test (touchpoint validation)
- **Full interview study**: Qualitative Research Plan (design & recruit) → The Mom Test (interviewing discipline, Product Discovery) → Qualitative Synthesis (analysis, Research Methodology)

### Methodology Mutual Exclusion and Ordering Constraints

| Constraint pair | Rule | Reason |
| --- | --- | --- |
| Empathy Map → JTBD | **Empathy Map first, then JTBD** (need mining scenario) | Empathy Map builds user empathy foundation; JTBD then digs deeper into functional/emotional jobs |
| Empathy Map vs User Personas | **Empathy Map supplements User Personas**, not replaces it | Empathy Map focuses on feeling empathy; Personas focus on complete profile; output purposes differ |
| Qualitative Research Plan vs The Mom Test | **Complementary, not exclusive** — Plan designs the study; Mom Test governs how to ask once in the room | Plan covers who/what/how analysis; Mom Test covers questioning attitude (past facts, not predictions); strongest used together |
