# Problem Diagnosis (compact aggregate)
> Aggregated from `references/problem-diagnosis/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh problem-diagnosis "<methodology>"`

## 5 Whys
> source: five-whys.md (original title: 5 Whys — Root Cause Analysis)
### Core Concept
By repeatedly asking "why" (typically 5 times), pierce through the symptoms of a problem to find the **actionable root cause**. Created by Sakichi Toyoda, it is a core tool of the Toyota Production System (TPS).

> Symptoms are just symptoms; root causes are the disease. Treating symptoms leads to recurrence; solving root causes leads to cure.

---

### Applicable Scenarios

✅ **Best for**
- Production incident post-mortems
- Business metric anomaly decline
- Process errors or quality issues
- Results consistently below expectations

⚠️ **When NOT to use**
- Multiple independent root causes are plausible from the start — a single forced chain hides the branches; map with Fishbone first
- The system behaves as a feedback loop (causes and effects reinforce each other) — linear why-chains mislead on entangled systems; use Systems Thinking
- No evidence exists to check any "why" step (no logs, no data, no observations) — the output would be plausible fiction, not diagnosis; gather data first (see Red Flags in SKILL.md)
- The root cause is structural or political — 5 Whys can identify it but cannot resolve it; pair the finding with organizational tools

---

### Execution Steps

#### Step 1: Clearly define the problem statement

Write a clear problem statement including: **what went wrong + when + impact scope**

```
❌ Vague: "System is slow"
✅ Clear: "Since 2024-06-01 14:00, payment API response time increased from 200ms to 3000ms, affecting ~30% of users"
```

#### Step 2: First Why

For the problem statement, ask: **"Why did this happen?"**

Write the direct cause, supported by facts (logs, data, observations). No guessing without verification.

#### Step 3-5: Continue asking

For each previous answer, ask "why" until:
- You reach an actionable root cause (a level where action can be taken)
- Or the question can no longer be asked (reached system/human/resource constraint level)

**Each step requires validation:** Is this cause supported by data or evidence?

#### Step 6: Define corrective actions

For the **final root cause** (usually at the 4th-6th level), define:
- Immediate fix (treat the symptom)
- Long-term prevention (treat the disease)

---

### Output Template

```
Problem Statement: [specific, quantifiable problem description]

Why 1: [direct cause] — Evidence: [...]
  Why 2: [deeper cause] — Evidence: [...]
    Why 3: [deeper cause] — Evidence: [...]
      Why 4: [deeper cause] — Evidence: [...]
        Why 5: [root cause] — Evidence: [...]

Root Cause: [one-sentence summary]

Corrective Actions:
  - Immediate (symptom): [...]
  - Long-term (disease): [...]
  - Owner / timeline: [...]
```

---

### Execution Example

**Problem**: User complaints up 40%, support tickets from 200 to 280/day

```
Why 1: Why did tickets increase?
→ App update made onboarding confusing; many users don't know how to complete first-time setup

Why 2: Why is onboarding confusing?
→ New onboarding was ported directly from B2B product, not redesigned for end consumers

Why 3: Why wasn't it redesigned for consumers?
→ Tight iteration schedule; onboarding optimization was deprioritized as low priority

Why 4: Why was onboarding deprioritized?
→ No user behavior data to support onboarding's impact; prioritization was purely subjective

Root Cause: Lack of user behavior data tracking prevents quantifying new user experience value in product decisions

Corrective Actions:
  Immediate: Add temporary video tutorial popup (handled by support)
  Long-term: ① Add analytics tracking ② Build onboarding funnel monitoring ③ Standardize onboarding priority assessment
```

### Failure Modes

- **Stopping at symptoms**: the chain ends at Why 1-2 with a restated symptom → force the question until the level found is actionable (system/process/design), never a person
- **Evidence-free steps**: each "why" answered from plausibility instead of observation → every step carries its evidence; a step that cannot be verified ends the chain honestly ("cause not established" at that level)
- **Single-chain bias**: one tidy causal chain reported for a multi-cause problem → when a second chain surfaces mid-analysis, switch to Fishbone and branch
- **"Human error" terminal**: the chain stops at "someone made a mistake" — a non-actionable end → keep asking what made the error likely (system, process, training)

---

### Evidence Strength

Practitioner consensus for simple, chain-traceable causation — decades of Toyota Production System use. The specific "five" is convention, not calibration: stop at the actionable level, whether that takes three whys or seven. Contested for complex systems, where linear root-cause narratives can false-compress multi-factor failures (see When NOT to use).

---

### Relationship with Other Methodologies

- **Pair with Fishbone**: When there are multiple independent root causes, use Fishbone to map the full picture first, then apply 5 Whys to each branch
- **Output to RICE**: After root cause is confirmed, use RICE to prioritize fix solutions
- **Output to OKR**: Long-term prevention measures can be converted to OKR Key Results

## Fishbone / Ishikawa
> source: fishbone.md (original title: Fishbone / Ishikawa Diagram)
### Core Concept
A fishbone (cause-and-effect) diagram systematically categorizes potential causes of a problem across multiple dimensions, helping teams visualize the full landscape of contributing factors rather than fixating on the first plausible cause.

### Applicable Scenarios
- Quality issues with multiple potential contributing factors
- Team brainstorming sessions for root cause identification
- When 5 Whys alone is insufficient due to multi-factor causation

⚠️ **When NOT to use**
- A single dominant cause chain — 5 Whys drills faster; a fishbone spends structure on breadth you don't need
- No domain knowledge in the room — the diagram organizes candidate causes but can't invent them; expertise is the input
- Data-driven prioritization is the actual task — the fishbone generates hypotheses; Pareto or measurement ranks them

### Key Steps
1. Write the problem statement at the "head" of the fish
2. Define major cause categories (common: 6M for manufacturing — Man/Machine/Material/Method/Measurement/Mother Nature; or 4P for services — Policies/Procedures/People/Plant)
3. Brainstorm potential causes within each category
4. For each potential cause, ask "why" to drill deeper (combine with 5 Whys)
5. Validate causes with data; prioritize the most likely root causes

### Output Template

```
Problem (head): [specific, measurable effect]

  Man        — [operator skip]        → why: [no checklist]
  Machine    — [calibration drift]    → why: [schedule not enforced]
  Method     — [manual data entry]    → why: [no barcode integration]
  Material   — [supplier lot variance]→ why: [no incoming inspection]
  Measurement— [gauge worn]           → why: [no calibration log]
  Environment— [humidity swings]      → why: [HVAC fault]

Prioritized causes (validated with data): 1. [gauge worn — measured] 2. [...]
Actions per confirmed cause: [owner + fix + verification]
```

### Failure Modes
- Brainstorm-only fishbone: a full diagram of opinions where every bone has three sticky notes and nothing is measured → every candidate cause gets a validation plan before the session ends; the output is hypotheses, not conclusions
- Category bias: the 6M template imports causes from manufacturing into software (or wherever it doesn't fit) → pick categories that match the domain (people/process/technology/external) rather than forcing 6M
- Fish freeze: an elaborate diagram from last year still hanging on the wall → date it and re-draw per incident; stale bones hide new causes

### Evidence Strength
Practitioner consensus — a core quality-management tool since the 1960s; its value is exhaustive hypothesis generation (documented failure mode of narrower methods is early fixation), while the diagram itself makes no causal claim — validation is always external.

### Source
Kaoru Ishikawa (1960s); quality management tool.

## Issue Tree
> source: issue-tree.md (original title: Issue Tree — Hypothesis-Driven Decomposition)
### Core Concept
Split a fuzzy problem into a MECE tree of answerable sub-questions, then resolve it hypothesis-first. **Boundary**: MECE + Pyramid (`structured-thinking/mece-pyramid.md`) structures *communication*; the issue tree structures *analysis*. 5 Whys traces one chain backward; Fishbone fans out by fixed dimensions; the issue tree decomposes forward and drives the evidence hunt.

### Applicable Scenarios
✅ Large vague problems ("why is margin declining?") needing parallelizable workstreams · team investigations, where each branch is a work package · limited analysis budget — the tree tells you which analyses to skip
⚠️ **When NOT to use**: single-chain causation (5 Whys is faster) · pure reporting — the answer is settled and only needs expression (use MECE + Pyramid directly) · zero domain knowledge (orient before attempting a Day-1 answer)

### Key Steps
1. **State the problem as a question** ("Why is X below Y?"), not a solution in disguise.
2. **Write the Day-1 answer**: "If I had to recommend right now, what would I say?" A disposable lead hypothesis — the thing to disprove, not defend.
3. **Decompose MECE**, 2–4 levels: each layer mutually exclusive, collectively exhaustive. Overlap double-counts causes; gaps let causes escape.
4. **Turn leaves into killer analyses**: name the one check that settles each leaf ("if raw-material inflation drives this, COGS/unit rose faster than price"); run cheapest first.
5. **Mark each node validated / refuted / open**, prune dead branches, deepen live ones, converge: restate the Day-1 answer as confirmed, revised, or overturned — all three are legitimate outcomes.

### Output Template

```
Problem question: [single question] · Day-1 answer: [disposable hypothesis]

? Why is [metric] off target?
├─ Branch A: [sub-question] — validated/refuted/open — evidence: [...]
│   └─ A.1 [leaf question] — [status] — check: [...]
└─ Branch B: [sub-question] — [status] — evidence: [...]

Converged answer: [surviving branches → revised or overturned Day-1 answer]
Open nodes: [leaf → cheapest discriminating check]
```

### Failure Modes
- **Fake MECE**: overlapping or omitting branches — per layer, can any two items merge? does any cause fit nowhere?
- **Boiling the ocean**: equal depth everywhere — deepen only branches the Day-1 answer and early evidence mark as live.
- **Anchoring**: evidence slots filled by the Day-1 assumption instead of checks — log node statuses honestly; an overturned answer is a result.
- **Tree that never converges**: endless expansion, every validated branch sprouting two more — cap depth at 2–4 levels and force the converge step; "where to look next" is a legitimate landing.

### Evidence Strength
Practitioner consensus — hypothesis-driven decomposition is the standard consulting/ROOT-cause playbook for large vague problems; MECE is a communication discipline, not an empirical law, and tree quality is bounded by the domain expertise of whoever cuts the branches.

### Source
McKinsey-style problem structuring; hypothesis-driven consulting practice (MECE lineage of Barbara Minto).
Provenance: framework ideas absorbed from [claude-skill-management-consultant-B1](https://github.com/DogInfantry/claude-skill-management-consultant-B1) FRAMEWORKS.md (Apache-2.0 license), absorbed 2026-09.
Admission: Build (new entry) — owns hypothesis-driven forward decomposition of an unsolved problem; MECE + Pyramid Principle structures the communication of an already-formed answer.

## Why Tree
> source: why-tree.md (original title: Why Tree — Evidence-Graded Causal Tree)
### Core Concept
A multi-branch causal tree where **every node carries three tags: evidence kind, confidence (Strong/Mod/Weak), and citation** — the kind says *what you are trusting* before how much. Unlike 5 Whys (one chain), it maps the causal web and grades each link's support.

### Evidence Kinds (seven)
**Measured** (hard number, n + window) · **Instance** (n=1-few, not a rate) · **External** (named third-party fact) · **Claim** (said, not verified) · **Inference** (logic on measured premises) · **Hypothesis** (untested; settling test nameable) · **Framing** (a lens — the apex is always one).

A number is not yet a fact. Measured carries a validation state: `raw` (pipeline unchecked — caps at Mod, cannot support the conclusion) → `validated` (denominator, definition, window, attribution, survivorship checked) → `triangulated` (two independent pipelines agree). `contested` = both values stay visible; the node cannot act as fact.

### Applicable Scenarios
✅ High-stakes "why" questions · auditable diagnoses · merged unequal-reliability evidence
⚠️ **When NOT to use**: quick single-chain incidents (5 Whys) · low-stakes questions with no audit need — the tag ledger costs more than the answer · lightweight contexts — degrade to the calling protocol's **fact / inference / assumption** tagging

### Key Steps
1. **Frame the apex**: one observed gap, stated measurably.
2. **Fan branches backward**; tag every node.
3. **Validate Measured sources** once each; record the state.
4. **Adversarial pass**: try to kill each load-bearing branch (data-otherwise / broken mechanism / mis-attribution / dirty pipeline); refuted stay visible with killing evidence.
5. **Converge**: load-bearing nodes still Hypothesis → headline is "where to look"; ship the cheapest test.

### Output Template

```
Apex: [observed gap]
├─ [cause] — Inference/Mod — [cite]
│   ├─ [support] — Measured/Strong, validated — "42% (n=310, Mar)"
│   └─ [support] — Hypothesis — test: [...]
├─ [cause] — REFUTED — killed by: [evidence]
└─ Contested: [A/src] vs [B/src] → reconcile: [check]
Census: [x% measured · y% hypothesis] → cheapest test: [...]
```

### Failure Modes
- **Green-chip fiction**: unchecked-pipeline numbers as facts.
- **Ritual tags**: every node labeled, none load-bearing checked — the ledger becomes decoration → tag only what the conclusion leans on, and validate those.
- **Skipped adversarial pass**: load-bearing branches never attacked (data-otherwise / broken mechanism / mis-attribution) → run step 4 before converging; refuted branches stay visible with their killing evidence.
- **Measurable-in-hand blindness**: one query would settle it — run it now.
- **Pruning the corpse**: deleting refuted branches and their lesson.

### Evidence Strength
Practitioner consensus on the discipline (grade evidence before trusting it; `raw → validated → triangulated` mirrors standard data-quality practice), but the seven-kind taxonomy is an authored framework, not a validated instrument — node grades are only as honest as whoever tags them, and the tree makes no causal claim its citations don't carry.

### Source
Goldratt CRT lineage; the evidence-grading discipline extends it.
Provenance: evidence grading absorbed from [systems-thinking-skills](https://github.com/BayramAnnakov/systems-thinking-skills) (MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns evidence-graded multi-branch causal mapping; 5 Whys is a single ungraded chain.

## IS/IS-NOT Difference Analysis (Kepner-Tregoe)
> source: kepner-tregoe.md
### Core Concept
Diagnose a *selective* deviation by asking not only "where does it occur?" but "**where does it NOT occur, though it plausibly could?**" The IS vs IS-NOT boundary is a discriminator: a valid cause must explain *both* sides. Flipped to choices it becomes Decision Analysis: screen on pass/fail MUSTs, rank survivors on weighted WANTs, expose what could reverse the ranking. Boundary discrimination is its unique mechanism among the diagnosis cards (positioning table below).

### Applicable Scenarios
✅ A defect hits some objects, locations, times, or cohorts but not comparable others ("only EU, only since Tuesday") · several candidate causes the boundary can discriminate · a consequential choice with explicit non-negotiables
⚠️ **When NOT to use**: uniform, non-selective failure — with no meaningful contrast, IS/IS-NOT has no discriminating power (use 5 Whys) · no comparable non-cases exist to fill the IS-NOT side · cause already confirmed or one cheap observation settles it · forward failure discovery for a planned change (premortem territory)

### Key Steps

**Mode 1 — Problem Analysis**
1. Frame the deviation: object, defect, location, time, extent.
2. For WHAT / WHERE / WHEN / EXTENT record IS, the closest comparable IS-NOT, and the distinction unique to the IS side; list changes near first occurrence.
3. Generate candidates from distinctions + changes; a candidate **survives only if it explains both IS and IS-NOT** — reject causes fitting only the IS side.
4. Run the cheapest discriminating check; stop when one verified cause explains the full boundary.

**Mode 2 — Decision Analysis**
1. Define MUSTs (pass/fail) and WANTs (weight 1–10) **before** scoring — post-hoc weights invite reverse-engineering.
2. Eliminate options failing any MUST; never rescue them with high WANT totals.
3. Score survivors per WANT; for leaders, list adverse consequences (probability × impact) and the assumption or weight change that would flip the ranking.
4. Decide — or return "none passes the MUSTs" rather than force a winner.

**Mode 1 software variant — fault localization**
The same boundary discipline, mechanical over code:
1. Precondition: a **minimal reproduction** — the smallest input/setup that still shows the defect; no repro, no diagnosis (an unreproducible bug is a logging task first)
2. Bisect = IS/IS-NOT over the **time axis** (`git bisect`: passes / fails / distinction = the change), delta debugging = IS/IS-NOT over the **input axis** (shrink the failing input until the minimal differentiating case remains)
3. Candidates must explain both sides: a theory that fits "fails on Tuesday" must also fit "not on Monday" — reject single-side theories
4. Fix-verification gate: the fix must pass the minimal repro **and** the adjacent IS-NOT cases (the fix that breaks the passing side is a new defect)
5. Situation still moving (intermittent under live traffic) → **OODA Loop**; confirmed code-level cause found → fix directly, no framework

### Output Template

```
Problem Analysis — deviation: [object + defect + where/when/extent]
| Dimension | IS | IS-NOT (closest) | Distinction |   ← WHAT/WHERE/WHEN/EXTENT
Nearby changes: [...] · Candidates: [cause → explains both sides? y/n]
Verified cause: [...] or next check: [...]

Decision Analysis — decision: [...] · alternatives: [A, B, C]
MUST screen: [...] → eliminated: [...]
WANT matrix (weight × score) → totals: [...]
Leader risks: [risk → p × impact] · flips if: [...]
Choice: [...] or "none passes — reopen criteria"
```

### Four-Way Positioning (diagnosis cards)

| Card | Motion | Reach for it when |
|------|--------|-------------------|
| 5 Whys | Single chain, backward | One obvious causal thread |
| Fishbone | Divergent, all cause families | Team brainstorm, unknown factors |
| Issue Tree | Forward decomposition + evidence hunt | Big vague problem, workstreams |
| IS/IS-NOT | Boundary discrimination | The failure is *selective* — contrasts discriminate causes |

### Failure Modes
- **Contrast-free matrix**: IS-NOT rows filled with non-comparable cases — the distinction column turns to noise → pick the *closest comparable* non-case, not any non-case.
- **Score theater**: WANT weights tuned until the preferred option wins → fix weights and scale before scoring; report the flip condition.
- **Forced winner**: no cause explains both sides, no option passes the MUSTs, yet the template demands an answer → return open/none; that is a finding.

### Evidence Strength
Practitioner consensus — taught and deployed in industry since 1965, and the boundary/both-sides test is sound logic; but there is no rigorous comparative evidence it beats other diagnosis methods, and its ranking steps inherit whatever weights and distinctions humans feed them.

### Source
Charles Kepner & Benjamin Tregoe, *The Rational Manager* (1965); Kepner-Tregoe methodology.
Provenance: framework ideas absorbed from [cc-thinking-skills](https://github.com/tjboudreaux/cc-thinking-skills) (MIT license), absorbed 2026-09.
Admission: Build (new entry) — owns IS/IS-NOT boundary discrimination for selective deviations; 5 Whys traces causal chains but does not scope the deviation.

## First Principles
> source: first-principles.md (original title: First Principles Thinking)
### Core Concept
Break down a problem to its most fundamental truths (axioms), then reason up from there — rather than reasoning by analogy or convention. Forces you to question every assumption and rebuild from the ground up.

### Applicable Scenarios
- Innovative design where existing solutions are inadequate
- Disrupting conventional approaches
- Breaking through mental models and industry assumptions

⚠️ **When NOT to use**
- The conventional solution is actually near-optimal — rebuilding from axioms to rediscover the standard answer is expensive theater
- Safety-critical domains with codified practice — conventions encode failures you haven't lived; deviate deliberately, not casually
- Time-boxed execution work — reserve this for design and diagnosis, not for sprint tasks

### Key Steps
1. State the current assumption or conventional approach clearly
2. Ask: "What are the fundamental truths we know with certainty?"
3. Challenge every other assumption: "Is this a law of physics, or just a convention?"
4. Reconstruct the solution from the fundamental truths upward
5. Compare the first-principles solution with the analogy-based solution; identify the delta

### Output Template

```
Problem: [goal + current cost/constraint]

Assumption inventory:
  | Conventional belief                     | Fundamental truth or convention? | Evidence if fundamental |
  | [batteries cost $600/kWh, always have]  | convention — spot prices were $[x]  | [materials breakdown: ...] |
  | [launch needs a full rocket]            | partially convention            | [physics: propellant mass ratios] |

Fundamental truths (only what survives): 1. [...] 2. [...] 3. [...]

Rebuild from truths: [how would we solve it if only the truths applied]
Delta vs analogy-based solution: [what changes, what it's worth in cost/time/feasibility]
Cheapest test of the rebuilt approach: [experiment by date]
```

### Failure Modes
- "First principles" as rhetoric: calling any fresh-thinking session first-principles while every assumption survives unchallenged → the assumption inventory with explicit convention/truth verdicts is the method; skip it and you did nothing
- Wrong floor: stopping at "industry best practice" instead of physics, math, or verified data → keep asking "why is this true?" until you hit evidence or a law
- Rebuild abandoned at friction: the from-truths design meets its first hard problem and quietly becomes the conventional design again → write the delta explicitly before comparing costs

### Evidence Strength
Practitioner consensus — a reasoning discipline with philosophical roots and famous applied cases (cost rebottoming in manufacturing); its value is assumption surfacing, and its cost is time — there is no systematic evidence on when it beats analogy-based reasoning, which in most situations remains the efficient default.

### Source
Aristotle; popularized in modern business by Elon Musk.

## Pareto Analysis
> source: pareto.md
### Core Concept
The 80/20 rule: roughly 80% of effects come from 20% of causes. Identify and prioritize the vital few factors that drive the majority of results, enabling focused resource allocation.

### Applicable Scenarios
- Resource allocation decisions
- Problem prioritization
- Key driver identification

⚠️ **When NOT to use**
- Cause impacts are unmeasured and can't be estimated — the ranking becomes opinion in a chart
- Causes interact strongly (fixing A fixes B) — independent-ranking breaks down; use systems thinking
- Fairness/compliance allocation — concentrating resources on the "vital few" customers/incidents is a policy decision the tool can't make

### Key Steps
1. List all contributing factors or problems with their measured impact
2. Sort by impact descending
3. Calculate cumulative percentage for each factor
4. Identify the ~20% of factors that contribute ~80% of total impact (the "vital few")
5. Focus resources on the vital few; deprioritize or eliminate the "trivial many"

### Output Template

```
Impact unit: [revenue lost / tickets / downtime minutes] — period: [range]

| Rank | Cause                 | Impact  | % of total | Cumulative % | Action     |
| ---- | --------------------- | ------- | ---------- | ------------ | ---------- |
| 1    | [checkout timeout]    | 4,100   | 41%        | 41%          | fix now    |
| 2    | [search no-results]   | 2,300   | 23%        | 64%          | fix now    |
| 3    | [slow images]         | 1,200   | 12%        | 76%          | schedule   |
| 4-10 | [long tail]           | 2,400   | 24%        | 100%         | deprioritize |

Vital few: [2-3 causes ≈ 76% of impact] — cut line: [why there, not at exactly 80%]
Re-check: [does the tail hide a cause about to grow? name it]
```

### Failure Modes
- Uncounted causes: categories drawn before counting ("other" swallows 40%) → define mutually exclusive categories first; cap "other" or re-investigate it
- 80/20 asserted, not computed: vital few announced without the cumulative table → run the arithmetic; sometimes the distribution is flat (60/40) and focus is wrong
- Frozen priorities: last year's Pareto driving this year's budget — cause impact drifts → recompute each period, and say what changed rank

### Evidence Strength
Mixed — heavy-tailed distributions are empirically common (defects, revenue, complaints), but the exact 80/20 split is folklore: measured splits range widely. The durable value is rank-and-cumulate discipline, which is arithmetic, not theory.

### Source
Vilfredo Pareto (1896); popularized by Joseph Juran in quality management.

## Category Guide
## Problem Diagnosis

**When to use**: A known problem exists; need to find the root cause or redefine the problem


### Minimum Information Requirements per Methodology

- **5 Whys / Fishbone**: Requires a quantifiable or observable specific problem statement
- **Issue Tree**: Requires a problem expressible as a decomposable question + enough domain knowledge to attempt a Day-1 answer
- **Why Tree**: Requires a measurable deviation statement + citable evidence sources (data queries, stakeholders, documents)
- **IS/IS-NOT Difference Analysis (Kepner-Tregoe)**: Requires a deviation with comparable non-cases (where it doesn't occur); Decision Analysis mode additionally requires alternatives + explicit non-negotiables
- **First Principles**: Clear assumption or analogy to disrupt
- **Pareto Analysis**: Requires quantifiable impact metrics + candidate list

### Routing Trigger Signals

- "Find root cause" / "why did this happen" → 5 Whys (primary)
- "Disruptive thinking" / "break assumptions" → First Principles (primary)
- "80/20 focus identification" / "resource focus" → Pareto Analysis (primary)
- "Multi-factor causation analysis" / "fishbone diagram" → Fishbone / Ishikawa (primary)
- "Decompose complex problem" / "problem tree" / "hypothesis-driven analysis" / "Day-1 answer" → Issue Tree (primary)
- "Evidence-graded diagnosis" / "stress-test the diagnosis" / "which claims can we trust" → Why Tree (primary)
- "Only some users/instances affected" / "where does it NOT occur" / "IS vs IS-NOT" / "MUST-WANT screening" → IS/IS-NOT Difference Analysis (primary)

### Triage — before picking a framework

The keyword routing above assumes the problem type is already known. When it is not, triage first — three questions whose answers pick the branch. Answer them from evidence the user provides; do not guess:

| # | Question | Yes → | No → |
| --- | --- | --- | --- |
| 1 | Do multiple independent cause families look plausible from the start (people / machine / method / measurement all candidates)? | Multi-factor branch: Fishbone → Pareto | next question |
| 2 | Is there a comparable non-case (a similar unit without the problem)? | Selective-defect branch: IS/IS-NOT Difference Analysis | next question |
| 3 | Is the causal chain short and directly observable end-to-end? | Chain-traceable branch: 5 Whys | Chain not directly observable: recurring/oscillating behavior → Systems Thinking (Structured Thinking); deep-but-gradable evidence → Why Tree |

Triage typically yields a working root-cause label — pricing misalignment, churn spike, weak PMF, broken GTM activation, process decay — to carry into whichever branch or combination fits. The label names the problem family; the rows above name the method chains.

**First-response contract**: until comparable component-level evidence is in hand, every conclusion is labeled **"cause not established"** — name the candidate causes, then name the evidence that would discriminate between them. Report it with stop_reason `degraded(L2)` so a paused diagnosis is never structurally indistinguishable from a finished one. Premature attribution is the failure this contract exists to prevent. (This specializes the SKILL.md L3 degradation — "ask 1-3 critical questions" — to diagnosis tasks.)

### Common Combinations

- **Structured takedown of a big vague problem**: Issue Tree (decompose into sub-questions) → Why Tree (evidence-grade the live branches) → 5 Whys (chain-trace the confirmed branch to its actionable root)
  - Step outputs: Issue Tree → MECE sub-question list with Day-1 hypotheses; Why Tree → evidence-tagged branch verdicts (supports / refutes / unknown); 5 Whys → causal chain ending in an actionable root cause
  - Branch: a branch surviving evidence grading goes straight to 5 Whys; branches still "unknown" get a data-collection task, not more analysis
  - Final deliverable: root-cause statement + discriminating-evidence log + fix options ranked by impact — synthesized, not stapled
- **Selective defect diagnosis**: Fishbone (diverge candidate causes) → IS/IS-NOT (keep only candidates explaining both sides of the boundary) → Pareto Analysis (rank fixes by measured impact)
  - Step outputs: Fishbone → cause-family map; IS/IS-NOT → shortlist of boundary-consistent causes with the discriminating observation; Pareto → ranked fix list with measured impact shares
  - Branch: a cause surviving the boundary test but unmeasurable → treat as "cause not established" and instrument first, do not rank on guesses
  - Final deliverable: verified cause + ranked corrective actions with expected impact
- **Diagnose then fix**: IS/IS-NOT (verify the cause) → RICE (prioritize corrective actions) — run sequentially; do not mix causal evidence with option scores
