# Go-to-Market (compact aggregate)
> Aggregated from `references/go-to-market/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh go-to-market "<methodology>"`

## Beachhead Segment
> source: beachhead-segment.md
### Core Concept
Select your initial market segment using 4 criteria: Burning Pain (must-have), Willingness to Pay, Winnable (60-70% win rate), Referral potential. Concentrate all resources on winning one segment before expanding — "crossing the chasm."

### Applicable Scenarios
✅ **Best for**
- Crossing the chasm (early market entry)
- Concentrating resources on a winnable segment
- B2B market segmentation

⚠️ **When NOT to use**
- The market is a single homogeneous segment — there is nothing to concentrate; go straight to GTM Strategy
- No segment data exists yet (no win rates, no WTP signals) — the 4 criteria become guesses; run cheap validation experiments first
- Platform/marketplace businesses where the "segment" is defined by network effects rather than customer attributes — the concentration logic differs

### Key Steps
1. List all potential market segments
2. Evaluate each against 4 criteria: Burning Pain / WTP / Winnable 60-70% / Referral
3. Score and rank segments
4. Select the top segment as beachhead
5. Develop go-to-market plan focused exclusively on this segment
6. Win the beachhead before expanding to adjacent segments

### Output Template

```
Segments considered: [list, one line each]

Scoring (1-5 per criterion: Burning Pain / WTP / Winnable / Referral):
  [Segment A]  4 / 4 / 4 / 3  → 15  ← beachhead
  [Segment B]  3 / 5 / 2 / 2  → 12

Beachhead: [segment] — why winnable: [evidence behind the 60-70% claim]
Explicitly deferred: [B, C] — what would reopen them
Beachhead plan: [channel + first 10 target accounts/communities]
```

### Failure Modes
- Scoring theater: segments scored from enthusiasm instead of evidence → require one observable fact per criterion before a score counts
- Beachhead drift: "winning" loosely, then expanding with nothing won → define "won" (e.g. 3 referenceable customers) before starting
- Wrong-unit segments: segments defined by product features instead of customer situations → re-express each segment as "people who hire X for job Y"

### Evidence Strength
Practitioner consensus from B2B go-to-market practice (Moore's chasm model); the 60-70% winnability figure is a heuristic, not an empirical constant. Survivor bias applies — beachhead successes get told more often than beachhead dead-ends.

### Source
Geoffrey Moore, *Crossing the Chasm* (1991) — beachhead/chasm strategy; the 4-criteria scorecard is practitioner convention (cf. Bill Aulet, *Disciplined Entrepreneurship*, beachhead selection).

## Ideal Customer Profile
> source: ideal-customer-profile.md (original title: Ideal Customer Profile (ICP))
### Core Concept
4-dimension ICP definition: Demographics (who they are), Behaviors (what they do), JTBD (what job they hire your product for), Needs (what outcomes they need). Used for sales lead scoring and targeted advertising.

### Applicable Scenarios
✅ **Best for**
- Sales lead scoring
- Targeted advertising
- Product-market fit validation

⚠️ **When NOT to use**
- No customers exist yet (0→1) — an ICP reverse-engineered from nothing is fiction; use Beachhead Segment hypotheses + interviews instead
- Product-led motion with self-serve signup — ICP gating at the door strangles volume; score for expansion propensity instead
- Founder-led sales with fewer than ~20 closed deals — there is no contrast data to score against; talk to every prospect instead of gating

### Key Steps
1. Analyze your best customers (highest LTV, lowest churn)
2. Define Demographics: company size, industry, role, location
3. Define Behaviors: usage patterns, buying signals, engagement
4. Define JTBD: what job do they hire your product to do?
5. Define Needs: what outcomes matter most?
6. Score leads against ICP; focus resources on highest-fit prospects

### Output Template

```
ICP (reverse-engineered from [N] best customers):
  Demographics: [size, industry, role, geo]
  Behaviors: [usage/buying signals that predict success]
  JTBD: [the job they hire the product for]
  Needs: [outcomes that matter most]

Anti-ICP (worst customers, and why): [disqualifying traits]
Lead scoring: [dimensions + weights, sales-follow-up threshold]
Refresh trigger: [e.g. quarterly, or a churn-pattern shift]
```

### Failure Modes
- ICP by vanity traits: "companies like Stripe" — resemblance without outcome data → derive every dimension from best/worst customer contrast, not aspiration
- Frozen ICP: the profile outlives the market → re-fit quarterly against fresh win/churn data
- Over-gating: disqualifying leads that would have expanded → score in tiers; review disqualified-but-won losses each quarter

### Evidence Strength
Practitioner consensus in B2B sales/marketing; outcome-linked ICPs reliably improve lead quality in case practice, but published effect sizes are mostly vendor-reported. The 4-dimension decomposition is a framework choice, not a validated model.

### Source
Standard B2B sales/marketing practice (ICP scoring is a convention of ABM and sales-development playbooks); the JTBD dimension references Clayton Christensen's jobs framework.

## GTM Motions
> source: gtm-motions.md
### Core Concept
7 go-to-market motion types: Inbound (content/SEO), Outbound (sales prospecting), Paid (ads), Community (organic community), Partners (channel partners), ABM (account-based marketing), PLG (product-led growth). Choose the right motion based on ICP, price point, and sales cycle.

### Applicable Scenarios
✅ **Best for**
- GTM motion selection
- Channel strategy design
- Sales/marketing alignment

⚠️ **When NOT to use**
- No ICP or price point defined yet — motion fit cannot be evaluated; define those first (see Ideal Customer Profile)
- Pre-product-market-fit — motions optimize acquisition of demand that doesn't reliably convert yet; validate PMF first
- Evaluating a single channel in isolation — motion choice is a portfolio decision (1 primary + 1 backup), not a beauty contest

### Key Steps
1. Define ICP and price point
2. Assess sales cycle length and complexity
3. Evaluate each GTM motion's fit for your ICP
4. Select 1-2 primary motions + 1 backup
5. Design the motion-specific playbook
6. Measure and optimize per motion

### Output Template

```
Inputs: ICP=[...] price=[...] cycle=[length/complexity]

Motion fit (fit reasons per motion):
  Inbound  [fit + why]   Outbound [fit + why]   Paid [fit + why]
  Community [fit + why]  Partners [fit + why]   ABM [fit + why]   PLG [fit + why]

Selection: primary=[motion] secondary=[motion] backup=[motion]
Why not the rest: [one line each — missing inputs, mismatched cycle, wrong ACV band]
Motion playbook: [stages, owners, per-motion metric]
```

### Failure Modes
- Motion spray: running five motions at low intensity instead of two at full intensity → cap at 2 primary + 1 backup; kill or scale at the review cadence
- Copying a motion without its prerequisites: PLG without a self-serve product, ABM without account data → each motion lists its prerequisites; unmet prerequisite disqualifies
- Measuring motions by activity (posts sent, ads run) instead of pipeline → per-motion metric must be a pipeline/retention metric

### Evidence Strength
Practitioner consensus on the motion taxonomy and fit factors (ACV × cycle × buyer type); motion-level success rates are anecdotal and context-dependent. Treat fit assessments as hypotheses to be instrumented, not conclusions.

### Source
Kyle Poyar, Alex MacCaw; modern B2B GTM strategy frameworks.

## GTM Strategy
> source: gtm-strategy.md
### Core Concept
Phased go-to-market plan covering: channel selection, messaging framework, success metrics, and launch phases. Translates product strategy into executable market entry.

### Applicable Scenarios
✅ **Best for**
- Launch planning
- Market entry execution
- Cross-functional GTM alignment

⚠️ **When NOT to use**
- Beachhead segment or ICP not yet chosen — the plan would inherit fiction; resolve those first
- A single-channel experiment or side project — full phased-launch machinery outweighs the decision; run the experiment instead
- Messaging when no customer language exists yet — draft messaging from interviews, not internal workshops

### Key Steps
1. Define target segment and ICP
2. Select GTM motions (see GTM Motions)
3. Craft messaging framework: problem → solution → differentiation → proof
4. Define success metrics per phase
5. Plan phased launch: soft launch → general availability → expansion
6. Align cross-functional teams (product, marketing, sales, support)

### Output Template

```
Segment / ICP: [...]  Motion: [primary + backup]

Messaging: problem=[...] solution=[...] differentiation=[...] proof=[...]
Phases:
  Soft launch   — scope=[...] metric=[...] exit criterion=[...]
  GA            — scope=[...] metric=[...] exit criterion=[...]
  Expansion     — scope=[...] metric=[...]
Cross-functional RACI: [product / marketing / sales / support]
Kill/pivot criteria: [what stops this plan]
```

### Failure Modes
- Phase theater: phases without exit criteria — GA happens because the calendar said so → every phase names its metric and exit criterion up front
- Messaging by committee: internally polished, customer-untested → validate messaging with 5 target-customer conversations before GA
- Success metrics nobody owns: launch metrics without a named owner per phase → each metric gets one owner and a review date

### Evidence Strength
Practitioner consensus (phased launch, messaging frameworks are standard practice); the specific phase structure is convention and varies by motion. No controlled evidence ranks messaging frameworks — instrument the funnel instead of debating frameworks.

### Source
Standard GTM methodology; combining multiple GTM frameworks.

## Growth Loops
> source: growth-loops.md
### Core Concept
5 types of sustainable growth loops: Viral (users invite users), Usage (more usage → more value → more usage), Collaboration (working together creates network effects), UGC (user-generated content attracts more users), Referral (explicit referral programs). Unlike funnels, loops compound.

### Applicable Scenarios
✅ **Best for**
- Sustainable growth mechanism design
- Moving beyond paid acquisition dependency
- Product-led growth strategies

⚠️ **When NOT to use**
- Pre-product-market-fit — loops compound retention problems too; validate PMF first
- The product's value is not measurable in-product (offline services, invisible outcomes) — K-factor cannot be quantified; use funnel analysis instead
- One-shot or infrequent-usage products with no repeat cycle to close a loop

### Key Steps
1. Map current acquisition channels (funnel view)
2. Identify potential loop types for your product
3. For each loop, define: Input → Activity → Output → Re-input
4. Quantify the loop coefficient (K-factor): how many new users per existing user per cycle?
5. Prioritize by measured K × cycle speed × testability — K > 1 is the exponential bar for a pure viral loop, not the admission bar for a loop: a compounding loop with K < 1 can still beat a linear funnel
6. Design experiments to test and optimize each loop

### Output Template

```
Current acquisition (funnel view): [channels + CAC + volume]

Candidate loops:
  [Loop type]  Input → Activity → Output → Re-input
               K estimate=[x]  time-to-cycle=[...]  confidence=[H/M/L]

Priority: [loop] — why: [highest K × fastest cycle × most testable]
First experiment: [hypothesis + instrument + decision rule]
```

### Failure Modes
- Loop wishlist: five loops "designed", none instrumented → one loop instrumented beats five diagrammed; K must be measured, not estimated, before prioritization
- Ignoring loop decay: K measured at launch, assumed forever → re-measure per cycle; loops saturate as invitation pools exhaust
- Forced virality: looping mechanics that degrade the core experience → the loop's Activity must be the product's natural use, not a bolt-on ask

### Evidence Strength
Practitioner consensus that compounding loops outperform linear funnels for products with in-product value and repeat usage; loop taxonomy is descriptive, and published K-factor benchmarks are survivor-biased. The funnel-vs-loop framing is well argued but not experimentally isolated.

### Source
Sarah Tavel, *The Hierarchy of Engagement* (2017); the loops-vs-funnels framing was popularized by Brian Balfour / Reforge (2018) and Gagan Biyani, *Why You Should Be Focusing on Growth Loops, Not Funnels* (2019); Elena Verna's Reforge work on loop design.

## Competitive Battlecard
> source: competitive-battlecard.md
### Core Concept
A one-page sales enablement tool with 4 sections: Where We Win / Where They Win / Common Objections & Responses / Landmines (traps to set for competitors). Updated quarterly based on win/loss data.

### Applicable Scenarios
✅ **Best for**
- Sales competitive response
- Win/loss pattern analysis
- Competitive positioning

⚠️ **When NOT to use**
- Fewer than ~10 competitive deals in CRM — the patterns are anecdotes; interview reps qualitatively instead
- The category has no real competitor (new category creation) — landmines and objections target named rivals; use Positioning Strategy
- As a strategy substitute: battlecards encode the current competitive position; they cannot decide it (route to Porter's Five Forces for structure)

### Key Steps
1. Gather win/loss data from CRM and sales interviews
2. Identify top 3-5 competitors
3. For each competitor, fill 4 sections: Where We Win / Where They Win / Objections & Responses / Landmines
4. Review with sales team; validate accuracy
5. Distribute and train sales team
6. Update quarterly with new competitive intelligence

### Output Template

```
Competitor: [name] — deal overlap: [segments where you meet]

WHERE WE WIN:  [conditions + deal evidence]
WHERE THEY WIN: [conditions + deal evidence — honest, or the card gets ignored]
OBJECTIONS & RESPONSES:
  "[objection]" → [response + proof point]
LANDMINES: [question to plant that surfaces their weakness honestly]
Refresh: [date + data source]  Owner: [...]
```

### Failure Modes
- Propaganda card: "we win everywhere" — reps stop trusting the card → the WHERE THEY WIN section must be honest enough to be useful
- Set-and-forget: card drifts behind the competitor's current release → quarterly refresh with a named owner, triggered also by any lost-deal pattern shift
- Landmines as FUD: questions that mislead rather than surface truth → a landmine must be a question you would want answered honestly as the buyer

### Evidence Strength
Practitioner consensus in sales enablement; win/loss-informed cards are standard practice with consistent anecdotal reports of improved competitive win rates. No controlled studies isolate the card's effect from rep quality; the 4-section structure is convention, not a validated model.

### Source
Standard sales enablement methodology; competitive intelligence frameworks.

## Positioning Strategy
> source: positioning-strategy.md
### Core Concept
Find whitespace in user minds by analyzing 5 classic positioning bases (Kotler-style) × top-5 competitor matrix. The 5 angles: Features/Benefits, Use Case/Application, User Category, Price/Quality, Competitor Comparison. Identify where competitors cluster and find the gap.

### Applicable Scenarios
✅ **Best for**
- User mindshare positioning
- Differentiated positioning
- Brand strategy

⚠️ **When NOT to use**
- Nobody holds the "position" being contested yet (new category) — a matrix of empty cells is noise; define the category first
- Positioning is not the constraint (distribution, product, or pricing is broken) — repositioning relabels a problem it cannot fix
- No access to customer perception data — the map must reflect minds, not internal slide decks; gather perception evidence first

### Key Steps
1. List top 5 competitors
2. For each competitor, map their current positioning across 5 angles
3. Create a positioning matrix showing competitor clusters
4. Identify whitespace: angles where no competitor is positioned
5. Select your positioning angle based on: whitespace + your strength + customer need
6. Craft positioning statement: For [target] who [need], [product] is a [category] that [benefit]. Unlike [competitor], we [differentiator].

### Output Template

```
Competitor × angle matrix (5 competitors × 5 angles): [table/map]

Clusters: [where competitors bunch and why]
Whitespace candidates: [angle + why it is open + why anyone cares]
Selected angle: [angle] — backed by [our strength] × [customer need]

Positioning statement: For [target] who [need], [product] is a [category]
that [benefit]. Unlike [competitor], we [differentiator].
Validation: [how perception will be re-measured and when]
```

### Failure Modes
- Whitespace for whitespace's sake: an empty cell nobody wants → every whitespace candidate must pass "a customer cares" before selection
- Aspirational mapping: the map reflects how we wish the market saw competitors → source each competitor's angle from their own messaging and customer quotes
- Statement without sacrifice: positioning that excludes nothing sticks nowhere → the statement must name what you are not

### Evidence Strength
Practitioner consensus from brand strategy; mindshare positioning theory traces to Ries & Trout, the 5-angle matrix to classic (Kotler-style) positioning bases, and the statement template to Geoffrey Moore. None of the three pieces is an empirically validated model, and mindshare causality is hard to measure — map quality depends entirely on the quality of perception data gathered.

### Source
Al Ries & Jack Trout, *Positioning: The Battle for Your Mind* (1981) — mindshare theory; 5 positioning bases follow classic (Kotler-style) practice; positioning-statement template follows Geoffrey Moore, *Crossing the Chasm* (1991).

## Marketing Mix
> source: marketing-mix.md (original title: Marketing Mix (4Ps / 7Ps))
### Core Concept
The four decision levers — **Product, Price, Place, Promotion** (McCarthy 1960), extended to seven for services by adding **People, Process, Physical evidence** (Booms & Bitner 1981) — that must hang together as one coherent offer. The mix is not a strategy generator; it is the **assembly and coherence check**: each P is delegated to the entry that owns it, then the Ps are verified against each other, because the classic failure is not a bad P but contradictory Ps (premium price sold through a discount channel, features advertised that do not exist).

### Applicable Scenarios
✅ **Best for**
- Assembling a launch plan after STP decisions exist (its intended downstream, per STP's own template)
- Auditing an existing offer for internal contradiction across the Ps
- Service businesses needing the 7Ps extension (where people/process/physical evidence are the actual failure points)

⚠️ **When NOT to use**
- STP not yet decided — the mix follows segment/target/positioning; a mix without them is four independent guesses → **STP Analysis**
- Deciding a single P in depth → each P has an owner: Price → **Pricing Strategy**; Place/Promotion channel-type → **GTM Motions**; Product value → **Value Proposition Canvas** / **Business Model Canvas**
- Writing ad copy or campaign content → owned messaging/copy territory (**GTM Strategy** frame; copy craft is content work)
- Pure-digital SaaS forced through 7Ps — Place is trivial there; run the 4Ps coherence check and skip the service extension honestly

### Key Steps
1. Take the STP outputs as fixed inputs: segment, target, positioning statement
2. Populate each P with its current decision, delegating depth to the owning entry (one line per P at this level)
3. Run the pairwise coherence check on the loaded Ps: Price × Place (premium price in a bargain channel?), Product × Promotion (promised features that don't exist?), Price × Product (value metric mismatched with what is built?), Place × Promotion (promoting where the buyer cannot purchase?)
4. Fix contradictions by changing the P that is least strategically committed — the mix reveals which commitment is cheapest to move
5. For services, extend to 7Ps and re-check: People (who delivers), Process (how it is delivered), Physical evidence (what the customer sees)
6. Re-run the coherence check after any single-P change — the mix is a loop, not a document

### Output Template

```
Inputs from STP: segment [..] · target [..] · positioning [..]
Mix:
  Product   : [one line — what is offered]        owner: [Value Prop Canvas / BMC]
  Price     : [one line — metric + range]          owner: [Pricing Strategy]
  Place     : [one line — channels]                owner: [GTM Motions / GTM Strategy]
  Promotion : [one line — motion + message frame]  owner: [GTM Motions]
  (services) People/Process/Physical: [one line each]
Coherence check:
  Price×Place: [consistent? contradiction named if not]
  Product×Promotion: [...]
  Price×Product: [...]
  Place×Promotion: [...]
Fixes: [contradiction → the P changed → why that P]
Re-check trigger: [any single-P change re-runs the matrix]
```

### Failure Modes
- Four independent decisions pasted into one grid: the coherence check is the mechanism; a grid without it is decoration
- Mix before STP: the levers get pulled with no target defined, then every P fights the others → STP first, always
- Treating the mix as the strategy: 4Ps organizes decisions, it does not make them — an empty grid filled with generic words ("high quality, competitive price") signals the strategy step was skipped
- Service business running only 4Ps: the failure lives in People/Process/Physical evidence, the three Ps the framework without its extension cannot see
- Promotion treated as "make ads": the P is a budget and a measurement commitment → delegate to the channel entries and record what success reads
- One-P optimization loops: Price changed without re-checking Place and Promotion → the matrix is a loop; any change re-runs it

### Evidence Strength
**Practitioner consensus as an organizing scaffold.** 4Ps (McCarthy 1960) has organized marketing planning for over sixty years, and 7Ps (Booms & Bitner 1981) is the standard service extension; the 4Cs critique (Lauterborn 1990) correctly observes it is seller-side — buyer-side framing is carried in this corpus by JTBD and the Value Proposition Canvas. As a checklist the mix is durable; as a strategy generator it is empty — its value here is strictly the cross-P coherence discipline.

### Source
E. Jerome McCarthy, *Product and Market: A Basis for Marketing Planning* (1960, 4Ps); Booms & Bitner, "Marketing Organizations and Services Marketing" (1981, 7Ps); Lauterborn, "New Marketing Litany: Four Ps Passé: C-Words Take Over" (1990, 4Cs critique). Admission verdict: **Build** (v0.1.16) — `stp-analysis.md` step 4 and its output template point at a mix method held nowhere (live dead pointer, the v0.1.15 defect class); the cross-P coherence check is the mechanism no other entry owns, and the Ps delegate to their existing owners rather than duplicating them.

## B2B Buying Center Mapping
> source: buying-center.md
### Core Concept
In committee purchases, no single person buys — and deal stalls are **role problems before they are product problems**. Map the buying center roles as they exist in this specific account: **initiator, gatekeeper, influencer, decider, buyer, user** (Webster & Wind's organizational buying model). Each role is measured on something different and loses something different, so each needs a different answer: the champion's business case does not answer procurement's risk mandate. The map's output is per-role coverage: who has been spoken to, and who has not.

### Applicable Scenarios
✅ **Best for**
- Stalled or slow B2B deals — locating whose objection is actually blocking
- Account planning before an ABM motion (GTM Motions disqualifies ABM "without account data" — this is that data)
- Enterprise or multi-stakeholder purchases of any kind

⚠️ **When NOT to use**
- Single-buyer consumer products → **Consumer Decision Journey** models the individual loop
- Deciding WHICH accounts to pursue → **Ideal Customer Profile** (firm-level); this entry maps WHO within the account
- Internal organizational influence and change → **Stakeholder Mapping** (Strategic Analysis) covers your own org and policy stakeholders, not the customer's buying group
- Writing per-role content and copy → owned messaging territory (**GTM Strategy** frame); this entry produces the role table the content must answer

### Key Steps
1. List every person who touches the purchase in this account — including the ones you have not met (the invisible gatekeeper is the standard finding)
2. Assign roles: initiator (felt the problem), gatekeeper (controls access), influencer (shapes the spec), decider (owns the yes), buyer (owns the budget signature), user (lives with the choice)
3. For each role, write what they are measured on and what losing looks like for them — the decider's loss frame is rarely the champion's
4. Identify the true decider and the true gatekeeper; champions are frequently neither
5. Map current coverage: which roles has anyone on your side actually spoken to; uncovered roles are where deals go quiet
6. Align the motion per role: champion gets the business case, gatekeeper gets the risk and compliance answer, buyer gets the procurement path, user gets the workflow demo, influencer gets the spec detail
7. Re-map at every deal-stage change — reorgs and stage transitions invalidate role maps silently

### Output Template

```
Account: [name] — deal stage [..]
| Role | Person | Measured on | What losing looks like | Covered? | Next action |
Champion vs decider: [same person? if not — who actually signs]
Gatekeeper: [who controls access + their filter criterion]
Coverage gaps: [roles with zero contact]
Per-role motion: [champion → business case | gatekeeper → risk answer | buyer → procurement path | user → demo]
Stall diagnosis: [the blocking objection → whose role it belongs to]
Re-map trigger: [stage change | reorg | new stakeholder appears]
```

### Failure Modes
- Champion mistaken for decider: the enthusiast signs nothing → separate influence from authority explicitly; ask "who signs" and "who can veto" as two different questions
- Procurement treated as an obstacle: it is a role with a risk mandate → give it the answer it is measured on (compliance, exit terms, references), not more enthusiasm
- Single-threaded deal: one contact means one reorg away from zero → coverage gaps are the actionable output; close them before the stage advances
- Stale role map: a stage change or reorg silently invalidates it → re-map on every stage transition
- The user ignored: the person who lives with the deployment can veto later or starve adoption → users are mapped and covered, not skipped as "not decision-makers"
- Uniform pitch to every role: the business case answers a question procurement is not asking → per-role loss frames drive per-role motions

### Evidence Strength
**Practitioner consensus, descriptive taxonomy.** The organizational buying model (Webster & Wind 1968; role set canonically presented in their 1972 book) has anchored B2B sales practice for five decades and the role vocabulary is stable across sales methodologies; validation sits mostly in sales-practice literature rather than controlled studies, and modern revisions add roles (coach, economic buyer) without displacing the core six. Use it as a coverage checklist, not a predictive model of who will do what.

### Source
Frederick Webster & Yoram Wind, "A General Model for Understanding Organizational Buying Behavior" (Journal of Marketing, 1968); *Organizational Buying Behavior* (1972). Admission verdict: **Build** (v0.1.16) — `consumer-decision-journey.md`'s boundary routes multi-stakeholder purchases to "account-based mapping", which no entry held (latent dead pointer, the v0.1.15 defect class); `ideal-customer-profile.md` covers which account to pursue, not who within it decides; and GTM Motions' ABM prerequisite ("without account data") is exactly this map.

## Category Guide
## Go-to-Market

**When to use**: Market entry, launch planning, growth flywheel, competitive response, positioning


### Minimum Information Requirements per Methodology

- **Beachhead Segment**: Requires candidate segment list + 4-criteria evaluation data
- **Ideal Customer Profile**: Requires existing customer data for reverse-engineering or clear assumptions
- **GTM Motions**: Requires ICP + price point + sales cycle awareness
- **GTM Strategy**: Requires GTM Motion selected + channel/metrics/phase planning capability
- **Growth Loops**: Requires product usage data + loop coefficient quantification capability
- **Competitive Battlecard**: Requires competitive product comparison data + sales feedback
- **Positioning Strategy**: Requires top-5 competitor awareness + 5 angles candidates
- **Marketing Mix**: Requires settled STP outputs (the mix follows them) + awareness of which entry owns each P
- **B2B Buying Center Mapping**: Requires a named account + contact list (role assignment happens in-session; uncovered roles are the output)

### Routing Trigger Signals

- "Crossing the chasm / beachhead market selection" → Beachhead Segment (primary)
- "Ideal customer profile definition" → Ideal Customer Profile (primary)
- "GTM motion selection" → GTM Motions (primary)
- "Launch plan" → GTM Strategy (primary)
- "Sustainable growth mechanism / growth flywheel" → Growth Loops (primary)
- "Competitive response / sales battlecard" → Competitive Battlecard (primary)
- "Positioning / user mindshare positioning" → Positioning Strategy (primary)
- "Assemble the launch offer / do the 4Ps hang together / premium price in a bargain channel / 7Ps for a service" → Marketing Mix (primary) ⚡ If STP not yet decided → use STP Analysis (Market Research); if deciding one P in depth → use Pricing Strategy (Strategic Analysis); if choosing the channel motion → use GTM Motions
- "B2B deal stalled / who is really the decider / procurement blocks us / who is on the buying committee / account planning before ABM" → B2B Buying Center Mapping (primary) ⚡ If deciding which accounts to pursue → use Ideal Customer Profile; if the buyer is a single consumer → use Consumer Decision Journey (User Research)

### Common Combinations

- **Market entry**: Beachhead Segment (pick the winnable wedge) → Positioning Strategy (claim mindshare whitespace) → GTM Strategy (channel + phased launch)
- **Sales enablement**: Ideal Customer Profile (qualify who to target) → GTM Motions (pick the motion matching ICP, price, and cycle) → Competitive Battlecard (arm reps for objections)
- **Positioning refresh**: Competitive Battlecard (win/loss signals) → Positioning Strategy (reposition into the gap competitors left)
- **Offer assembly**: STP Analysis (who/where/why) → Marketing Mix (assemble the Ps coherently) → GTM Strategy (channel + phased launch)
- **Enterprise deal rescue**: B2B Buying Center Mapping (whose objection blocks) → Competitive Battlecard (per-role answers)
