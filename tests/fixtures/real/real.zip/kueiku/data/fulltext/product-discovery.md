# Product Discovery (compact aggregate)
> Aggregated from `references/product-discovery/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh product-discovery "<methodology>"`

## Opportunity Solution Tree
> source: opportunity-solution-tree.md
### Core Concept
Align business outcomes with discovery work through a 4-layer structure: Outcome → Opportunities → Solutions → Experiments. Force focus on "opportunities" (user pain points/needs) at each layer rather than jumping straight to solutions, avoiding "build it and they won't come."

### Applicable Scenarios
- Continuous product discovery, need to align team work with business goals
- Prevent PMs from jumping to solutions without mining user opportunities
- When multiple solutions need parallel experiments, unify discovery planning

⚠️ **When NOT to use**
- No measurable outcome exists — a tree without a real target metric becomes an idea landfill
- One-off feature work with a settled opportunity — the full tree is overhead for a single known problem
- No interview pipeline feeding it — a tree built from internal brainstorming inherits every blind spot of the room

### Key Steps
1. Define the desired Outcome (business result, not feature output), e.g. "improve new user first-week retention by 20%"
2. Mine Opportunities through user interviews (user pain points/needs/unmet scenarios under this goal), prioritize by layer
3. Design multiple Solution candidates for each priority Opportunity (encourage divergence, at least 3)
4. Design minimum Experiments for each Solution (first-click/fake door/prototype etc.) to validate hypotheses
5. Weekly meeting traces bottom-up through the tree: experiment results → solution decisions → opportunities covered → outcome progress

### Output Template

```
OUTCOME: [first-week retention +20%] — baseline [x], owner [name]
├── Opportunity: [can't see value before setup is done] (n interviews: 7/12 mentioned)
│   ├── Solution A: [template gallery] → Experiment: [fake-door CTR, threshold ≥8%]
│   ├── Solution B: [guided first-run] → Experiment: [prototype 5-user test]
│   └── Solution C: [import from competitor] → Experiment: [concierge, 5 accounts]
├── Opportunity: [doesn't know what to do after signup] (5/12)
│   └── [solutions + experiments]
└── Deprioritized: [opportunities outside outcome scope — logged with reason]

Weekly trace: [experiment result] → [solution killed/iterated] → [opportunity still open?] → [outcome progress: +x pp]
```

### Failure Modes
- Solution layer smuggled into opportunity layer: "users want a dashboard" is a solution → opportunities are phrased as user pain/need, never as artifacts
- Interview-starved tree: opportunities invented in planning meetings → every node cites interview evidence (n mentions, recency); unfed nodes get pruned
- Tree as wall art: built once in a workshop, never traced weekly → the bottom-up weekly trace is the mechanism; a stale tree is worse than none because it lends false structure

### Evidence Strength
Practitioner consensus — a structuring practice from continuous discovery coaching; widely adopted by product orgs and coherent with evidence-based iteration norms, but there is no controlled study that OST adoption improves outcomes — its value is preventing solution-jumping, which is a process gain, not a causal claim.

### Source
Teresa Torres, *Continuous Discovery Habits* (2021)

## Assumption Mapping
> source: assumption-mapping.md
### Core Concept
Make implicit assumptions behind a product/project explicit, ranked on an Impact × Risk 2D matrix, prioritizing validation of high-impact + high-risk assumptions. The basic version uses 4 risk categories: Desirability (do users want it) / Viability (does the business work) / Feasibility (can we build it) / Usability (can users use it); the extended version adds 8 categories, supplementing with Ethics, Legal, Brand, Strategic Fit, etc.

### Applicable Scenarios
- Before launching a new feature/product, identify "what are we actually betting on"
- When multiple assumptions coexist, decide which to validate first
- Cross-team alignment on "what must be true for this to work"

⚠️ **When NOT to use**
- The proposal has one dominant bet — skip the matrix, design that one experiment
- Assumptions can be settled by reading data you already have — mapping exercise before a 10-minute log query is ceremony
- Regulated launches where the gate sequence is fixed by compliance — the ordering is prescribed, not discovered

### Key Steps
1. List all assumptions the proposal depends on, categorize by 4 (or 8) risk types
2. For each assumption assess: if false, impact on business (High/Medium/Low) + current risk (High/Medium/Low)
3. Plot on Impact × Risk matrix, prioritize the "high impact + high risk" quadrant
4. Design minimum experiments for each priority assumption (see experiment-design-library.md)
5. After experiments, return to matrix, update risk scores, and decide GO / Pivot / Kill

### Output Template

```
Proposal: [one line]

| Assumption (falsifiable form)                       | Type        | Impact | Risk | Priority | Experiment            |
| --------------------------------------------------- | ----------- | ------ | ---- | -------- | --------------------- |
| [Segment X will pay $Y for Z]                        | Viability   | High   | High | P0       | [pricing page A/B]    |
| [Users can complete flow W without help]             | Usability   | High   | Med  | P1       | [5-user prototype test]|
| [We can source data D under budget B]                | Feasibility | Med    | Low  | P3       | [vendor quotes]       |

Test order: P0 → P1 (P0 failing kills the bet regardless of P1)
Decision after tests: GO / Pivot / Kill — revisit date: [date]
```

### Failure Modes
- Unfalsifiable assumptions: "users will love it" can't be tested → rewrite each assumption so an experiment could prove it false
- Mapping meeting without re-mapping: risks scored once at kickoff, never updated after experiments → the matrix is a living artifact; re-plot after each result
- Comfortable quadrant: team validates low-risk assumptions first because they're easy → test order is set by the quadrant, not by convenience

### Evidence Strength
Practitioner consensus — an application of established decision logic (spend evidence where the bet is biggest); no controlled studies compare assumption-mapped vs unmapped launches, and impact/risk scores are judgment calls whose quality decides everything.

### Source
Popularized by Teresa Torres in *Continuous Discovery Habits*; 4-risk model originates from IDEO; 8-risk extension from Product Compass.

## Pretotypes
> source: pretotypes.md
### Core Concept
Before writing a single line of code, validate "should we build this?" (Right It) in the cheapest way possible, not "did we build it right?". Through XYZ hypotheses + lightweight pretotype experiments, filter out doomed ideas before investing in engineering.

### Applicable Scenarios
- New idea is still at "I think users would want this" stage
- High engineering cost, need to validate demand existence before development
- Multiple candidate ideas, need quick screening

⚠️ **When NOT to use**
- The cost to build the real thing is trivial — pretotyping overhead exceeds just shipping behind a flag
- The idea's risk is technical feasibility, not demand — build a spike, not a landing page
- Measurable brand/UX damage from fake-door tests on existing paying users — gate by audience

### Key Steps
1. Write XYZ hypothesis: X% of target users in Y context will Z behavior
2. Choose pretotype type: Landing Page for traffic / Video for clicks / Pre-order for payment willingness / Concierge MVP manual service for real usage
3. Add Skin-in-the-Game signals: let users invest time/email/money/data, not just say "I'd want it"
4. Set success threshold in advance (e.g. CTR ≥ 5%), abandon if not met, avoid post-hoc rationalization
5. Only proceed to real prototype/engineering after passing

### Output Template

```
XYZ hypothesis: [15]% of [solopreneurs] in [invoicing context] will [pre-order at $9/mo]

Pretotype: [pre-order page] — skin-in-the-game: [email + card hold]
Audience source: [n reachable via channel C] — sample size justification: [why n detects the threshold]
Success threshold (set BEFORE launch): [≥8% pre-order rate] — below: [abandon/pivot note]
Result: [x% at n=…] — decision: proceed / abandon / reframe
What we actually learned: [demand signal vs click-quality caveat — did converters match target segment?]
```

### Failure Modes
- Threshold written after results: "5% is actually good for this channel" — the post-hoc rationalization the method exists to kill → thresholds and sample sizes committed in writing before traffic
- Testing appetite, not demand: clickers who never convert → skin-in-the-game signals only; opinion-level signals (likes, "interesting!") don't count
- Wrong crowd: paid clicks from lookalike audiences validating demand of the real segment → check converter profile against the target before declaring victory

### Evidence Strength
Practitioner consensus — grounded in the standard logic of cheap falsification and revealed preference; Savoia's catalog is anecdote-driven, and pretotype results (especially landing-page conversion) are known to over- or under-state true demand depending on channel quality, so treat a pass as a license to build a smaller next test, not as proof.

### Source
Alberto Savoia, *The Right It* (2019)

## The Mom Test
> source: mom-test.md
### Core Concept
Even your mom will say your idea is great — so don't ask "what do you think of my idea", ask about her **past** real behaviors. Rob Fitzpatrick proposes 10 rules, the core being: avoid collecting false positive feedback.

### Applicable Scenarios
- Early-stage startup/new feature, need user interviews to validate demand
- You find yourself pitching ideas instead of listening
- Interview conclusions are always "users say they like it" but conversion data is poor

⚠️ **When NOT to use**
- Testing usability of a concrete design — you need task-based usability testing, not life-history interviews
- Expert/beta users giving technical feedback on a working build — specific critique here is genuine signal, not social politeness
- You need market sizing — interviews explain why, not how many; pair with Opportunity Score or market research

### Key Steps
1. Ask about the past, not the future — "last time you encountered problem X, what did you do?" not "would you use feature X?"
2. Don't pitch your idea — once you pitch, the other person will socially agree
3. 80/20 listening — you talk 20%, let the user talk 80%
4. Capture strong emotional signals — "I hate that process", "I spent three hours" — these are 10x more important than "it's fine"
5. Validate commitment, not opinions — "have you paid for this?", "what alternatives have you tried?"

### Output Template

```
Interview: [who, role, when] — script adherence: [pitched or not]

Signals (past behavior only):
  Problem: [specific episode — last time, what happened, cost in time/money]
  Emotion: [verbatim quotes with heat: "I nearly missed the deadline because ..."]
  Workarounds: [spreadsheet/VA/manual process — strongest demand evidence]
  Commitment: [paid: y/n + what for / tried: which alternatives / invested time: ...]

Verdict on the problem: validated / not yet / invalid — based on: [n episodes of real spending or heavy workaround]
Feature reactions collected (LOW trust): [what they said about our idea — note, don't conclude]
Next: [who else to interview / what behavior to observe in-product]
```

### Failure Modes
- Compliment collection: "that's great!" logged as validation → only past behavior and sunk costs count as evidence; opinions are recorded and discarded
- Leading questions smuggled in: "don't you hate how X takes forever?" — the answer was installed by the question → script questions around episodes, not evaluations
- Over-generalizing from 3 interviews: three anecdotes become a roadmap → interviews set hypotheses; in-product behavior or experiments must confirm at scale

### Evidence Strength
Practitioner consensus — grounded in well-documented survey/interview biases (social desirability, stated vs revealed preference); the method is a bias-avoidance discipline, not a statistical technique, and small-n anecdote risk remains its known limit.

### Source
Rob Fitzpatrick, *The Mom Test* (2013)

## Product Trio
> source: product-trio.md
### Core Concept
Product discovery should be conducted collaboratively by a PM + Designer + Engineer trio, not by the PM alone then handed off. The trio each represents feasibility/usability/viability perspectives, interviewing users together weekly, avoiding "discovery done but engineering can't keep up" or "great UX but high tech debt."

### Applicable Scenarios
✅ **Best for**
- Continuous discovery where discovery is still borne by PM alone
- Engineers/designers don't interact with users
- Need to introduce technical and design constraints during discovery

⚠️ **When NOT to use**
- 3-person startup where everyone already talks to everyone — the structure exists to rewire a broken handoff, not to add meetings
- Highly regulated discovery with legal in every session — the trio becomes a quartet; that's fine, but plan for it
- Teams where weekly user contact is impossible (long sales cycles, rare users) — adapt cadence, or the "weekly" ritual becomes fiction

### Key Steps
1. Form the trio: PM (value), Designer (usability), Engineer (feasibility), clarify each perspective's responsibilities
2. Establish weekly interview cadence: all three participate (can rotate facilitator, but all present)
3. Jointly maintain the Opportunity Solution Tree; all three can add/challenge opportunities
4. Solution ideation and experiment design produced jointly; technical feasibility intervenes during design phase
5. PM makes final decisions, but tech and design have veto power within their domains

### Output Template

```
Trio: PM [name] / Design [name] / Eng [name] — cadence: [weekly, day]

Interview block: [date] — participants [all three? y/n] — user profile [who]
  Signals captured: [opportunities added to tree / assumptions challenged]
  Feasibility note from Eng: [constraint spotted early]
  Usability note from Design: [interaction risk spotted early]

Tree status: opportunities [n] open / [n] covered — oldest open: [x weeks]
Decisions this week: [made jointly? by PM with vetoes noted?]
Health check: is any trio member becoming a passenger? [answer + fix]
```

### Failure Modes
- Trio in name, PM in practice: engineer silently yielding all judgment → enforce the perspective roles: engineer must voice feasibility, designer usability, every session
- Interview spectator mode: all three attend but only the facilitator talks → rotate who leads interviews; observers write notes, not novels
- Cadence collapse: interviews drift to "when there's time", discovery reverts to quarterly → protect the slot on calendars; a missed week is fine, a missed month is the old broken process

### Evidence Strength
Practitioner consensus — coherent with research on cross-functional teams and shared user exposure (decision latency and handoff loss are well-attested failure modes); the specific trio composition and weekly cadence are practice prescriptions, not validated designs, and outcomes depend on organizational support.

### Source
Teresa Torres (popularized the Product Trio concept in *Continuous Discovery Habits*)

## Opportunity Score
> source: opportunity-score.md
### Core Concept
Quantify the opportunity size for a given need using Importance × (1 − Satisfaction). Needs that are important but currently underserved score high, indicating the biggest product opportunity. Derived from Kano thinking but normalized to 0–1 for easy cross-comparison.

### Applicable Scenarios
- Have user survey data (importance + satisfaction), need to prioritize requirements
- Find "low satisfaction, high importance" quick-win opportunities
- Validate product-market fit gaps

⚠️ **When NOT to use**
- No survey data yet — scores from guessed ratings are decoration; collect importance/satisfaction first
- Needs wording is ambiguous across respondents — inconsistent stimuli produce garbage averages
- Choosing between strategic bets where satisfaction isn't the lever (new market creation) — the score presumes an existing served need

### Key Steps
1. For each candidate need/feature, ask target users to rate: Importance (1–5 or 1–10) + Current Satisfaction (1–5)
2. Normalize: map both importance and satisfaction to 0–1 (e.g. on a 5-point scale, score = (rating−1)/4)
3. Calculate Opportunity Score: Opportunity = Importance × (1 − Satisfaction)
4. Sort by Opportunity descending, focus on high scores (high importance + low satisfaction = blue ocean)
5. High-score items with already-high satisfaction are met needs; low-importance items with low satisfaction still aren't worth investing in

### Output Template

```
Survey: n=[respondents], profile [who], needs phrased as [outcomes, not features]

| Need (outcome wording)              | Imp 1-5 | Sat 1-5 | Importance norm | (1−Sat) norm | Opportunity | Read             |
| ----------------------------------- | ------- | ------- | --------------- | ------------ | ----------- | ---------------- |
| [find reusable code quickly]        | 4.6     | 2.1     | 0.90            | 0.78         | 0.70        | attack           |
| [export to any format]              | 3.9     | 4.4     | 0.73            | 0.15         | 0.11        | met need         |
| [AI-written changelogs]             | 2.0     | 1.8     | 0.25            | 0.80         | 0.20        | unimportant      |

Priorities: top [2] by opportunity — cross-check segment splits before committing (averages hide divergent segments)
```

### Failure Modes
- Feature-worded needs: "dark mode" rated, not the underlying outcome → rate outcomes; features carry solution bias
- Average masking: one segment 1-satisfied, another 5-satisfied averages to a meaningless 3 → segment the data before ranking
- Treating 0.70 vs 0.65 as decisive: rating-scale noise swamps gaps that small → separate clear tiers; below that, tie-break with evidence outside the survey

### Evidence Strength
Mixed — the importance × (1 − satisfaction) form is a sensible, widely used heuristic for spotting underserved needs, but it inherits all rating-scale weaknesses (scale-use variance, stated preference bias); Olsen presents it as a prioritization aid, not a validated instrument, and it works best when followed by behavioral confirmation.

### Source
Dan Olsen, *The Lean Product Playbook* (2015)

## ICE Framework
> source: ice-framework.md
### Core Concept
Quick prioritization using Impact × Confidence × Ease, scoring each idea 1-10 on three dimensions. A lightweight alternative to RICE when you need to screen many ideas fast (under 30 minutes) without precise metrics.

### Applicable Scenarios
- Large backlog of ideas needing quick initial screening
- Early-stage teams without reliable Reach data for RICE
- Time-constrained prioritization workshops

⚠️ **When NOT to use**
- Committing a quarter's roadmap on ICE scores — screening output feeds RICE or experimentation, not direct commitments
- One scorer with private context — unexplained individual scores produce one person's ranking wearing a formula
- Items with wildly different effort scales (a 1-hour fix vs a quarter build) — Ease compresses that into one number; split the backlog first

### Key Steps
1. List all candidate ideas/features
2. Score each on Impact (1-10): how much will this move the metric if it works?
3. Score each on Confidence (1-10): how sure are we it will work?
4. Score each on Ease (1-10): how easy is it to implement?
5. Calculate ICE = Impact × Confidence × Ease, sort descending
6. Top items go forward; discuss scoring disagreements as a team

### Output Template

```
Scoring session: [date], scorers: [names], metric focus: [activation]

| Idea | Impact | Confidence | Ease | ICE | Notes on the lowest dim                |
| ---- | ------ | ---------- | ---- | --- | -------------------------------------- |
| [A]  | 8      | 4          | 7    | 224 | confidence low — no prior data          |
| [B]  | 5      | 8          | 9    | 360 | —                                       |
| [C]  | 9      | 3          | 2    | 54  | ease low — needs legal review           |

Disagreements logged: [idea X: scorer 1 said 7, scorer 2 said 4 — resolved by evidence Y]
Next: top items → [RICE scoring / experiment design]; bottom: parked with revisit date
```

### Failure Modes
- Impact scored 10 by default: enthusiasm leaks into the dimension with no ceiling anchor → anchor scales in writing (what does a 3 vs 7 vs 10 impact look like?) before scoring
- Confidence never interrogated: everyone scores their own idea confidently → the Confidence dimension exists to discount unsupported bets; require evidence for ≥7
- Precision cosplay: two-decimal ICE averages implying measurement that doesn't exist → the output is a screening order, not a valuation

### Evidence Strength
Practitioner consensus — a folk heuristic from growth practice; deliberately unvalidated and rough (multiplicative scales with subjective anchors), it trades statistical meaning for speed. Use as a screen, then let RICE or experiments supply the actual evidence.

### Source
Sean Ellis, *Hacking Growth* (2017)

## Experiment Design Library
> source: experiment-design-library.md
### Core Concept
A menu of 7 experiment types for validating hypotheses at minimum cost before committing to full development. Each experiment type tests a specific assumption with a specific fidelity level.

### Applicable Scenarios
- Need to validate product hypotheses before building
- Choosing the right experiment type for each assumption
- Building a culture of experimentation

⚠️ **When NOT to use**
- Unnamed assumptions — picking an experiment type before stating the hypothesis guarantees a vague result; write the falsifiable hypothesis and threshold first
- Core UX validation via fake door or landing page — those measure willingness to click, not whether the product works
- Demand magnitude from interviews alone — conversations reveal problems, not quantified demand; pair with **Survey Design** or a landing-page test
- Cost-mismatched experiments — running a concierge MVP to validate copy wording is waste; match experiment cost to assumption risk

### Key Steps
1. Identify the riskiest assumption to validate
2. Select the cheapest experiment type that can test it (see types below)
3. Define success criteria in advance (minimum threshold)
4. Run the experiment with minimum investment
5. Measure results against success criteria; decide Pivot / Persevere / Kill

### Experiment Types
1. **Customer Interview** — Test problem existence (lowest fidelity)
2. **Survey** — Test demand magnitude
3. **Landing Page Test** — Test interest/click-through
4. **Fake Door Test** — Test willingness to engage
5. **Concierge MVP** — Test full solution manually
6. **Wizard of Oz** — Test with manual backend, automated frontend
7. **Prototype Test** — Test usability and desirability (highest fidelity)

### Output Template

```
Hypothesis: [we believe X; if true, Y follows]
Riskiest assumption: [the one that kills the project if wrong]
Experiment type: [interview / survey / landing page / fake door / concierge / wizard of oz / prototype]
Cost: [time, effort]  Fidelity: [low → high]
Success criteria (set BEFORE running): [metric ≥ threshold]
Run window: [duration, sample]
Result: [measured value vs threshold]
Decision: [Pivot / Persevere / Kill] — based on [evidence]
Next assumption: [what gets tested next]
```

### Failure Modes
- Criteria after the fact: defining "success" once results are in turns every outcome into a win → write the threshold and sample size before launch; pre-registration is the whole discipline
- Wrong fidelity: a fake door can't answer usability questions and a prototype can't answer demand magnitude → match experiment type to the assumption class, not to what's easiest to build
- Testing the safe assumption: validating what's easy instead of what's fatal → rank assumptions by "if wrong, the project dies" and test the top one
- Experiment theater: running tests whose results change no decision → pre-commit to the Pivot/Persevere/Kill mapping; if no outcome would change the decision, don't run it

### Evidence Strength
Practitioner consensus — the experiment menu is standard lean-startup practice synthesized from Ries, Torres and practitioner canvases; there is no comparative research ranking the experiment types against each other, and validity depends on honest pre-registered success criteria rather than on the menu itself.

### Source
Adapted from Eric Ries *The Lean Startup*, Dave lands Experiment Canvas, and Teresa Torres *Continuous Discovery Habits*.

## Category Guide
## Product Discovery

**When to use**: Continuous product discovery, hypothesis validation, user interviews, experiment design


### Minimum Information Requirements per Methodology

- **Opportunity Solution Tree**: Requires clear business Outcome + user interview data
- **Assumption Mapping**: Requires clear plan/proposal + ability to list dependent assumptions
- **Pretotypes**: Requires expressible XYZ hypothesis + execution capability for selected pretotype type
- **The Mom Test**: Requires accessible target users + interview opportunities
- **Product Trio**: Requires PM/Designer/Engineer trio available for weekly interviews
- **Opportunity Score**: Requires accessible target users for importance+satisfaction survey
- **ICE Framework**: Requires candidate idea list + 30-min team discussion
- **Experiment Design Library**: Requires clear hypotheses to validate

### Routing Trigger Signals

- "Continuous product discovery / aligning discovery to business outcomes" → Opportunity Solution Tree (primary)
- "User interviews avoiding false positive feedback" → The Mom Test (primary)
- "Quick early idea screening (<30 min)" → ICE Framework (primary)
- "Finding unmet needs / product opportunity identification" → Opportunity Score (primary)
- "Hypothesis validation experiment selection" → Experiment Design Library (primary)
- "Assumption identification and mapping" / "uncertainty mapping" → Assumption Mapping
- "Minimum viable prototype" / "pretotype" → Pretotypes
- "Product team collaboration" / "triad role" → Product Trio

### Common Combinations

- **Continuous discovery cycle**: Opportunity Solution Tree (structure outcome→opportunity) → The Mom Test (interview without false positives) → Opportunity Score (quantify which opportunity is biggest)
- **Idea triage to validation**: ICE Framework (rough screening) → Pretotypes (validate demand before code) → Experiment Design Library (pick the experiment for what survives)
- **Kickoff risk check**: Assumption Mapping (surface the bets) → Experiment Design Library (match an experiment to the riskiest assumption)
- **Weekly discovery cadence**: Product Trio (who runs discovery) → The Mom Test (how they interview)
