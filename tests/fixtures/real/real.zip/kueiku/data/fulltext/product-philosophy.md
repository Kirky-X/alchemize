# Product Philosophy (compact aggregate)
> Aggregated from `references/product-philosophy/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh product-philosophy "<methodology>"`

## Focus as No
> source: focus-as-no.md
### Core Concept
Focus is not about saying "yes" to the right things — it's about saying "no" to everything else. Radical subtraction to lock the minimum viable set. Every "yes" to a feature is a "no" to simplicity.

### Applicable Scenarios
✅ **Best for**
- Product scope decisions
- Feature trade-offs
- Preventing product bloat

⚠️ **When NOT to use**
- Compliance, safety, and platform obligations — "remove it" isn't available; scope them separately from discretionary features
- Early exploration before a core purpose is defined — subtraction needs an anchor; with no stated purpose, every feature is defensible
- Multi-sided products without per-side analysis — a feature bloating one side may be essential to the other; cut per side, not globally

### Key Steps
1. List all current features/requirements/proposals
2. For each item, ask: "If we remove this, does the product fail its core purpose?"
3. If no → it's a candidate for removal or deferral
4. Apply the "Hell Yes or No" filter: if you're not excited about it, say no
5. Lock the minimum set; defend it against scope creep

### Output Template

```
Core purpose (one sentence): [what the product must do to justify existing]

| Item          | Remove → product still serves core purpose? | Verdict        | Deferral condition        |
| ------------- | ------------------------------------------- | -------------- | ------------------------- |
| [exports]     | yes                                          | defer          | [revisit when 10+ asks/qtr]|
| [core editor] | no                                           | keep           | —                          |
| [admin theme] | yes                                          | cut            | —                          |

Scope-creep gate: new proposals answer "what does this replace?" — additions without substitutions need [explicit owner] approval
Revisit: [date] — is the minimum set still minimum, and did any cut break a promised workflow?
```

### Failure Modes
- Subtraction theater: cutting the rare-but-critical escape hatch (export, undo) that the core purpose quietly depends on → simulate the cut: walk a real task end-to-end without the item before verdicts
- "Hell yes" as veto: enthusiasm-based filtering kills necessary-but-dull requirements (onboarding, billing) → apply the excitement filter to discretionary items only; obligations get a different gate
- No defense after the workshop: the locked set erodes feature by feature → publish the list, log every exception, and count exceptions per quarter — creep that's visible gets resisted

### Evidence Strength
Practitioner consensus — a philosophy with strong practitioner advocacy (37signals lineage, essentialism literature) and intuitive support from scope-creep failure modes; there is no controlled evidence for the specific filters, and aggressive subtraction has real documented failure cases when core purpose is misstated — the method is only as good as the purpose statement it serves.

### Source
Jason Fried & David Heinemeier Hansson, *It Doesn't Have to Be Crazy at Work*; essentialism philosophy.

## Whole Widget
> source: whole-widget.md
### Core Concept
End-to-end ownership of critical decisions. If a component is core to your product's differentiation, don't outsource it — own the whole widget. Vertical integration for strategic control.

### Applicable Scenarios
✅ **Best for**
- Product architecture decisions
- Build vs buy decisions
- Vertical integration strategy

⚠️ **When NOT to use**
- Everything called "core": integration desire for control flags on every component — the analysis exists to rank, so most components must lose
- Thin markets with excellent suppliers — commodity components with multiple strong vendors punish ownership (you maintain what others share)
- Small teams: owning the whole widget means staffing every layer — the build decision includes a permanent team, not just this quarter's budget

### Key Steps
1. Identify all components/decisions in your product chain
2. For each, ask: "Is this core to our differentiation?"
3. If yes → own it (build in-house, control the decision)
4. If no → consider outsourcing/partnering
5. Validate: do you have end-to-end control of the user experience?

### Output Template

```
Component inventory:
  | Component       | Core to differentiation? | Vendor options today | Decision | Cost of owning      |
  | [input method]  | yes — the moat            | poor fit             | OWN      | [team + roadmap]    |
  | [payments]      | no                        | several excellent    | PARTNER  | [integration cost]  |
  | [cloud hosting] | no                        | several excellent    | BUY      | —                   |

Differentiation chain: [own everything between the user's intent and the differentiated experience]
User-experience control check: where can a partner decision degrade our UX without warning? [list + SLA/escape plan]
Re-decide trigger: [vendor quality collapse / differentiation shifts / cost inversion]
```

### Failure Modes
- Core creep: everything deemed strategic, nothing bought — integration as instinct → force the ranking: name the top-3 differentiating experiences; a component is core only if it shapes those
- Owning a fast-moving commodity: rebuilding what the market iterates monthly (auth, payments rails) → ownership makes sense when your iteration rate can beat the market's, which for commodities it rarely can
- Half ownership: own the component but depend on a vendor for its critical inputs — control theater → check the layer below your "owned" layer before claiming end-to-end control

### Evidence Strength
Practitioner consensus — vertical integration of differentiating layers has iconic case support (integrated hardware/software advantages are well documented) while the transaction-cost literature also explains when markets beat hierarchies; the practical difficulty is that "core" judgments are forward-looking and often wrong in both directions.

### Source
Steve Jobs' philosophy; Horace Dediu's "Whole Widget" concept.

## Technology Meets Humanities
> source: technology-meets-humanities.md
### Core Concept
Great products require 3-dimension assessment: Technology (does it work?) × Humanities (does it resonate with humans?) × Business (is it viable?). A single perspective is insufficient for good products.

### Applicable Scenarios
✅ **Best for**
- Product evaluation
- Design decisions
- Team building

⚠️ **When NOT to use**
- One dimension already binds the decision — a hard compliance, safety, or performance constraint makes a three-way assessment ceremony; score only the binding dimension and check the others for contradiction
- Pre-PMF exploration — "does it resonate with humans" cannot be read off a product that does not exist yet; this evaluates products, it does not discover them → **Design Thinking** for the discovery phase
- Incident and defect triage — the framework assesses what to build and has no mechanism for locating a live fault → root-cause analysis instead
- Team building as the deliverable — the assessment is the output; assembling T-shaped people is one implementation choice, not the framework itself

### Key Steps
1. For any product decision, assess all 3 dimensions:
   - Technology: Is it technically feasible? Scalable? Reliable?
   - Humanities: Does it resonate emotionally? Is it accessible? Does it respect users?
   - Business: Is it economically viable? Does it serve the business model?
2. If any dimension scores poorly, the product decision is incomplete
3. Build teams with T-shaped skills covering all 3 dimensions
4. Use the 3-dimension framework in design reviews

### Output Template

```
Decision: [what is being decided]
Technology: [feasible? scalable? reliable?] — evidence: [measured value, or the named unknown]
Humanities: [resonates? accessible? respects users?] — evidence: [measured value, or the named unknown]
Business: [viable? serves the model?] — evidence: [measured value, or the named unknown]
Weakest dimension: [dimension | what it costs if it stays weak]
What changes if we fix it: [the specific product decision this score flips]
```

### Failure Modes
- Scorecard without evidence: each dimension gets a confident yes or no from memory → attach measured evidence per dimension or write "unknown"; unmeasured assessments are opinions arranged in a table
- Business used as the decider: the dimension that decides is whichever one the decision-maker already favors → declare which dimension is genuinely binding before scoring
- Humanities as decoration: taste judgments dressed as research → require user evidence and separate what was observed from what is preferred
- The multiplication misread: "one weak dimension kills the product" ignores that the dimensions trade off differently and audience varies → judge each dimension against the audience you actually serve
- Framework used to justify a settled decision: the score arrives after the choice → score the strongest alternative too; a framework that only ever confirms is a rationalizer

### Evidence Strength
Mixed — the three-dimension framing is a durable synthesis of design and product practice with no controlled evidence behind the combination, and its parts are unevenly grounded: technical feasibility and business viability have established estimation disciplines, while "resonance with humans" is measured, when it is measured at all, by qualitative research whose findings are contested and sample-dependent. Its reliable use is as a completeness check that stops a single-perspective decision — usually the engineer's — from being taken as a product decision; the cost is a false sense of balance when the three scores are not comparable in rigor.

### Source
Steve Jobs: "It is in Apple's DNA that technology alone is not enough — it's technology married with liberal arts that yields the best results."

## Invisible Perfection
> source: invisible-perfection.md
### Core Concept
Internal craft quality determines external user experience. The unseen parts (code quality, internal tools, infrastructure) must be polished to the same standard as user-facing features. Users may never see the internals, but they feel the difference.

### Applicable Scenarios
✅ **Best for**
- Code quality standards
- Internal tool investment decisions
- Craft standard setting

⚠️ **When NOT to use**
- As a blanket rule against pragmatism: some internals genuinely are throwaway (spikes, prototypes) — polish proportional to lifespan
- Used to gold-plate: infinite refactoring in the name of craft while user-visible problems rot — the philosophy says internals shape experience, not that internals outrank experience
- Uneconomic domains: internal quality standard must still price the benefit; polish with no plausible user-experience payoff is cost

### Key Steps
1. List all "invisible" quality points: code quality, test coverage, internal tools, documentation, infrastructure
2. For each, assess: does this affect the user experience (directly or indirectly)?
3. Set quality standards for invisible items equal to visible items
4. Invest in internal tooling with the same rigor as external products
5. Monitor: are invisible quality points degrading?

### Output Template

```
| Invisible quality point | Path to user experience                     | Standard (same bar as visible?) | Current state | Trend |
| ----------------------- | ------------------------------------------- | ------------------------------- | ------------- | ----- |
| [build pipeline speed]  | [slow builds → slower fixes → stale bugs]   | [p95 < 10 min]                  | [18 min]      | ↓     |
| [error messages from API]| [direct user contact]                       | [actionable, localized]         | [stack traces] | →    |
| [internal admin tool]   | [support latency → user wait time]           | [support task < 5 min]          | [meets bar]   | →     |

Investment queue (UX-linked, ranked by user-experience impact): 1. [...] 2. [...]
Explicitly unpolished (prototype-grade, lifespan-limited): [items + why acceptable]
Monitor: [definition of done includes invisible items? degradation alerts on pipeline/tooling?]
```

### Failure Modes
- Craft as identity: polishing invisible internals nobody experiences while shipping quality slips on what users see → every invisible investment states its user-experience causal path; no path, no slot in the queue
- Uniform standard applied blindly: prototype code polished to production bar, production code left rough → standards attach to lifespan and blast radius, not to "internal vs external" alone
- No monitoring: decay invisible by definition — nobody notices until users feel it → the quality points list gets the same alerts/owners as user-facing SLOs

### Evidence Strength
Practitioner consensus — the causal chain (internal quality → iteration speed → user-experienced quality) is well argued and consistent with software-engineering research linking code quality to development velocity; the specific "equal polish" prescription is philosophy rather than measured policy, and its economics are context-dependent.

### Source
Pixar's philosophy: "The art challenges the technology, and the technology inspires the art." Applied to software engineering.

## Category Guide
## Product Philosophy

**When to use**: Need foundational judgment on product direction, architecture, and craft standards — not execution-level scheduling


### Minimum Information Requirements per Methodology

- **Focus as No**: Current feature/requirement list + business priority objectives
- **Whole Widget**: Product critical decision point list + outsourcing cost/benefit data per stage
- **Technology Meets Humanities**: Product technical metrics + user humanities perception data + business model
- **Invisible Perfection**: Internal craft point list + existing quality standards + automated checking capability

### Routing Trigger Signals

- "Too many features / product bloat / trying to do everything" → Focus as No (primary)
- "Should this be built in-house or outsourced / buy a solution" → Whole Widget (primary)
- "Product evaluation: technical metrics alone are insufficient / missing humanities perspective" → Technology Meets Humanities (primary)
- "Code quality / internal tools: should we invest in polishing" → Invisible Perfection (primary)

### Common Combinations

- **Product scope decision**: Focus as No (lock minimum set) → RICE (execution ranking) → Invisible Perfection (craft standards)
- **Architecture decision**: Whole Widget (identify critical decision points) → Technology Meets Humanities (3-dimension assessment)
- **New product evaluation**: Technology Meets Humanities (3-dimension assessment) → Focus as No (eliminate temptation items)
