# Financial Analysis (compact aggregate)
> Aggregated from `references/financial-analysis/` of github.com/Kirky-X/kueiku v0.1.16.
> One `## <methodology>` section per methodology. Extract one with:
> `scripts/get_methodology.sh financial-analysis "<methodology>"`

## DuPont Analysis
> source: dupont.md
### Core Concept
Decompose ROE into 3 factors: Net Profit Margin × Asset Turnover × Equity Multiplier. Identifies which driver is responsible for ROE changes and enables peer comparison.

### Applicable Scenarios
✅ **Best for**
- Financial diagnostics
- Peer comparison
- ROE anomaly analysis

⚠️ **When NOT to use**
- Questionable accounting quality — the decomposition is exact arithmetic on reported numbers, so earnings management and one-offs pass straight through; normalize or validate earnings first (audit the data with **Cognitive & Statistical Bias Checklist**)
- Banks and financial institutions — leverage is the business model, so a high equity multiplier is normal, not a red flag; the standard reading misleads
- Negative or near-zero equity — the multiplier explodes or flips sign and ROE itself stops meaning anything at the extremes
- Single-period snapshots — one year's decomposition is noise-prone; compare trends and peers, never an isolated reading

### Key Steps
1. Gather financial data: Revenue, Net Income, Total Assets, Equity
2. Calculate 3 factors: Net Profit Margin = NI/Revenue; Asset Turnover = Revenue/TA; Equity Multiplier = TA/Equity
3. Verify: ROE = NPM × AT × EM
4. Compare with peers or prior periods
5. Identify which factor drives ROE differences
6. Use chain substitution method for period-over-period decomposition

### Output Template

```
Company: [x] — period: [FY] — basis: [reported / normalized]
Net Profit Margin: [x%] (NI [x] / Revenue [x])
Asset Turnover: [x] (Revenue [x] / Total Assets [x])
Equity Multiplier: [x] (Total Assets [x] / Equity [x])
Identity check: NPM × AT × EM = [x%] — equals reported ROE? [yes/no]
Comparison: vs peer [x] or prior period [x] — NPM [x vs x], AT [x vs x], EM [x vs x]
Driver verdict: ROE differs mainly via [margin / turnover / leverage] — evidence: [numbers]
Chain substitution: ROE change [x pp] = margin [x pp] + turnover [x pp] + leverage [x pp]
```

### Failure Modes
- Trusting reported numbers: one-off gains, capitalized costs, and managed accruals distort NI and assets → normalize before decomposing and note what was adjusted
- Leverage read as quality: ROE lifted by the equity multiplier is added risk, not efficiency → report EM separately and flag when ROE growth comes from it
- Canceling drivers: two factors moving in opposite directions hide inside the ROE total → use chain substitution to attribute the change factor by factor
- Cross-industry comparison: turnover norms differ radically (retail vs software) → compare within industry or explicitly adjust expectations
- Point-in-time balance sheets: year-end asset snapshots misrepresent the year → use averages where feasible

### Evidence Strength
Practitioner consensus — the decomposition is an exact arithmetic identity, taught and used universally for a century; it reliably locates which driver differs across firms or periods, but it is a diagnostic on reported numbers, so its accuracy is capped by accounting quality and it explains drivers, not future returns.

### Source
Donaldson Brown, DuPont Corporation (1920s).

## DCF
> source: dcf.md (original title: DCF — Discounted Cash Flow)
### Core Concept
Enterprise value equals the sum of all future free cash flows discounted to present value. The most fundamental intrinsic valuation method.

### Applicable Scenarios
✅ **Best for**
- Enterprise valuation
- Investment decisions
- M&A pricing

⚠️ **When NOT to use**
- Unforecastable cash flows — early-stage, commodity-cyclical, or fast-disrupted businesses make the 10-year projection fiction; use scenario bounds (**Probabilistic Reasoning**, **Scenario Planning**) instead of a point-estimate DCF
- Terminal-value domination — when the terminal value carries most of the enterprise value, the "analysis" is one far-future assumption in present-value clothing; test that assumption directly rather than polishing the FCF table
- Indefensible WACC — a one-point change in the discount rate swings value enormously; if the rate is a guess, the output is a range at best
- Pricing-to-market questions — DCF answers intrinsic value for a long-term owner; for what the market will pay today (IPO windows, trading ranges) **Comparable Company** is the more direct tool

### Key Steps
1. Project free cash flows (FCF) for 5-10 years
2. Estimate WACC (Weighted Average Cost of Capital)
3. Calculate terminal value (Gordon Growth or Exit Multiple)
4. Discount all cash flows to present value using WACC
5. Sum PV of FCFs + PV of terminal value = Enterprise Value
6. Conduct sensitivity analysis on key assumptions (growth rate, WACC, terminal multiple)

### Output Template

```
Company: [x] — FCF definition: [state SBC / capex / working-capital treatment]
Projection [5-10y]: revenue CAGR [x%] — margin path [x% → x%] — reinvestment [x%]
WACC: [x%] — build-up: risk-free [x] + ERP [x] × beta [x] + size/other premiums [x] + after-tax cost of debt [x]
Terminal: [Gordon g = x% / exit multiple x] — PV share of EV: [x%] (flag if above ~60-70%)
Sensitivity: EV range across [g × WACC] grid: [low – high]
Verdict: value per share [x] vs price [x] — margin of safety [x%]
Assumption register: [the 2-3 assumptions the answer actually hinges on]
```

### Failure Modes
- Assumption laundering: growth and margin guesses dressed up as analysis → keep an assumption register and report the value range, not a point estimate
- Terminal-value tyranny: terminal value above ~70% of EV means the explicit forecast is decoration → shorten the horizon with an exit multiple, or state and stress the far-future assumption explicitly
- WACC arbitrage: picking the discount rate after seeing the desired valuation → build the WACC bottom-up and freeze it before computing value
- FCF definition drift: inconsistent treatment of SBC, capex, or working capital across years or companies → fix one definition, document it, apply it everywhere
- False precision: "worth $47.32" — the model's decimal places exceed its information content → present the sensitivity band as the answer

### Evidence Strength
Mixed — DCF is the theoretically correct intrinsic-value framework and the reference point of corporate finance, but its outputs are extremely assumption-sensitive: terminal value typically dominates the result and WACC shifts move value enormously, so two honest analysts applying the same method get different numbers; the honest deliverable is a defensible range plus the assumptions that drive it.

### Source
Standard finance methodology; Irving Fisher (1907), modernized by McKinsey.

## Comparable Company
> source: comparable-company.md (original title: Comparable Company Analysis)
### Core Concept
Infer a target company's value by applying valuation multiples from similar publicly traded companies. Common multiples: P/E, EV/EBITDA, EV/Revenue, P/B.

### Applicable Scenarios
✅ **Best for**
- IPO pricing
- M&A valuation
- Industry comparison

⚠️ **When NOT to use**
- No true peers — companies differing in growth, margin structure, or capital intensity make any multiple comparison garbage; if you adjust more than you compare, switch to **DCF**
- Broken denominators — negative or trough-cycle earnings make P/E and EV/EBITDA exist but signal nothing
- Sector-wide mispricing — comps price relative to today's market mood; in a bubble or panic you inherit it with false precision, so pair with an intrinsic check (**DCF**) and give a range, not a point (**Probabilistic Reasoning**)
- Owner-specific value questions — comps give the market-clearing range; synergy or strategic value to a specific acquirer needs a different model

### Key Steps
1. Select 5-10 comparable companies (similar industry, size, growth)
2. Gather financial data and calculate valuation multiples
3. Compute median/mean multiples for the peer group
4. Apply peer multiples to target company's metrics
5. Derive valuation range; cross-validate with DCF if available
6. Document adjustments for differences (growth, margin, risk)

### Output Template

```
Target: [company] — basis: [LTM / NTM], currency, adjustments: [state them]
Peer set: [5-10 companies] — comparability criteria: [industry, size, growth, margin band]
  Excluded: [who and why]
Multiples:
  P/E: peers [x, x, x] — median [x] — selected [x] (why)
  EV/EBITDA: peers [..] — median [x]
  EV/Revenue: peers [..] — median [x]
Applied: target metric [x] × selected multiple [x] → implied value range [low – high]
Adjustment rationale: [growth / margin / risk differences and how the selected multiple accounts for them]
Cross-check: DCF intrinsic value [x] — gap and explanation: [..]
```

### Failure Modes
- Garbage comps: peers chosen for convenience rather than comparability → write the comparability criteria down and name what was excluded and why
- Flattering-multiple selection: switching to EV/Revenue when EBITDA is negative → show all multiples and justify the pick; be suspicious when the chosen one is the highest
- Unadjusted quality gaps: identical multiples across different growth and margins → adjust for the differences or state why they cancel
- Definition drift: peers' "adjusted EBITDA" means different things → normalize non-GAAP definitions before comparing
- Cycle blindness: peak-cycle multiples extrapolated as permanent → use mid-cycle metrics for cyclicals

### Evidence Strength
Practitioner consensus — comps are the market-standard first-pass valuation and benchmark in every deal; the method reliably produces a market-anchored range, but its output is only as good as the peer set and the honesty of the adjustments, and it prices relative value, never intrinsic value.

### Source
Standard investment banking methodology.

## EVA
> source: eva.md (original title: EVA — Economic Value Added)
### Core Concept
EVA = NOPAT − (WACC × Invested Capital). Measures true value creation: a company creates value only when returns exceed the cost of capital.

### Applicable Scenarios
✅ **Best for**
- Performance evaluation
- Investment decisions
- Value-based management

⚠️ **When NOT to use**
- WACC noise — EVA inherits the discount-rate problem: a small WACC error flips the sign; report sensitivity before declaring "creates / destroys value"
- Early-stage or heavy-investment phases — negative EVA during build-out is by design, not destruction; judge the trajectory and returns on incremental capital, not the single-year sign
- Cross-firm comparison without normalization — invested-capital definitions and accounting choices (leases, R&D capitalization, goodwill) differ across companies; raw EVA rankings mislead
- Standalone valuation — EVA is a single-period, accounting-derived metric; for what the business is worth use **DCF**, and for market-relative pricing **Comparable Company**

### Key Steps
1. Calculate NOPAT = EBIT × (1 − Tax Rate)
2. Determine Invested Capital = Total Equity + Total Debt − Cash
3. Estimate WACC
4. Calculate EVA = NOPAT − (WACC × Invested Capital)
5. Positive EVA = value creation; Negative EVA = value destruction
6. Track EVA trends over time; diagnose drivers

### Output Template

```
Company: [x] — period: [FY]
NOPAT: EBIT [x] × (1 − tax [x%]) = [x]
Invested Capital: equity [x] + debt [x] − cash [x] = [x]
  Adjustments stated: [leases / R&D capitalization / goodwill / other: x]
WACC: [x%] — build-up: [..]
EVA = [x] − ([x%] × [x]) = [x]
Trend: EVA over [3-5y]: [x, x, x] — improving or deteriorating?
Driver diagnosis: [margin / capital efficiency / cost of capital — with numbers]
Sensitivity: EVA at WACC ±1pp: [x to x] — does the sign flip? [yes/no]
```

### Failure Modes
- Binary sign reading: one year's EVA sign treated as a verdict → read the trend and the WACC sensitivity; the sign is an estimate, not a fact
- Inconsistent invested capital: lease, R&D, and goodwill treatment differing across firms or years → fix one definition and apply it across the whole comparison
- Punishing growth investment: expansion-period EVA is negative by design → separate maintenance returns from investment-phase dilution
- WACC anchoring: choosing the rate to make the conclusion land → build it bottom-up, freeze it, then compute
- Accrual inheritance: NOPAT inherits the distortions of reported earnings → cross-check against cash-flow-based measures

### Evidence Strength
Practitioner consensus — residual income logic is coherent and EVA-based management spread widely through the 1990s corporate world; the metric reliably reframes profit against capital cost, but it inherits WACC and accounting-definition sensitivity, and claims that EVA adoption itself improves firm performance are weaker than the accounting logic behind the formula.

### Source
Stern Stewart & Co. (1990s); based on residual income theory.

## Unit Economics
> source: unit-economics.md
### Core Concept
Does one customer make or lose money, and how fast does the cash come back? Four numbers answer it: **CAC** (fully-loaded cost to acquire a customer), **contribution margin** (per-customer revenue minus variable costs of serving them), **LTV** (the margin a customer contributes over their lifetime), and **payback period** (months to recover CAC). Growth amplifies whatever the unit economics already are — scaling a negative unit economy buys losses faster, not success.

### Applicable Scenarios
✅ **Best for**
- Deciding whether to increase sales/marketing spend or scale a channel
- Startup viability checks and fundraising readiness
- Comparing channels and segments: which customers are worth acquiring

⚠️ **When NOT to use**
- Pre-revenue with no cost data — estimate ranges explicitly and revisit; do not fake precision
- Company-level P&L questions (whole-firm profitability drivers) — use DuPont Analysis for firm-level decomposition
- Fixed-cost-dominant businesses where per-customer framing misleads — contribution margin still applies; LTV framing may not

### Key Steps
1. Compute **CAC fully loaded**: all sales & marketing spend (ads + salaries + tools + agency fees) ÷ new customers acquired in the period — ads-only CAC is fiction
2. Compute **contribution margin** per customer: revenue − variable costs (COGS, support, payment fees, variable infrastructure)
3. Compute **LTV on margin, not revenue**: ARPU × gross margin × average lifetime (equivalently ARPU × gross margin ÷ churn rate); revenue-based LTV overstates health by the entire cost structure
4. Compute **payback period**: CAC ÷ monthly contribution margin per customer
5. Check health heuristics — these are inherited rules of thumb, **not laws**; state your own threshold and why:
   - LTV:CAC ≥ 3:1 (below ~1:1 you lose money per customer; just above, margin is too thin to fund growth)
   - Payback ≤ 12–18 months — for cash-constrained businesses payback is the binding constraint, not the ratio
   - Contribution margin positive and growing; SaaS extension: Rule of 40 (revenue growth % + profit margin % ≥ 40)
6. **Segment before deciding**: blended figures hide winner and loser channels — compute CAC/LTV/payback per channel and per cohort (cohort-level tracking: `data-analysis/cohort-analysis.md`)
7. Decide: scale segments that pay back inside runway; fix the inputs (price, margin, CAC, churn) or cut the rest
8. **Consistency with market sizing**: when feeding a bottom-up TAM/SOM estimate (`market-research/market-sizing.md`, customers × ARPU), reuse the same customer definition and ARPU computed here, so the market model and the unit economics reconcile instead of contradicting each other

### Output Template
```
Unit economics: [product / segment / channel]
CAC (fully loaded): [$] per customer  | blended $[x] vs [channel] $[y]
Contribution margin: [$ or %] per customer per month
LTV (margin-based): [$]  → LTV:CAC = [x.x]:1   [heuristic ≥ 3:1]
Payback: [n] months                                  [heuristic ≤ 12–18]
Blended-vs-segment note: [what the blended figure hides]
Decision: scale | fix inputs first | cut — and why
```

### Failure Modes
- Revenue-based LTV: drops the cost structure from the lifetime value → always margin-based
- Under-loaded CAC: excluding salaries and tools → fully loaded, or the ratio is fiction
- Blended CAC lies: one great channel subsidizes three broken ones inside the average → segment by channel and cohort
- Payback longer than runway: a "healthy" 3:1 with 24-month payback still bankrupts a cash-tight company → compare payback against runway months before scaling spend
- Treating 3:1 as a law: industry and margin-structure variance is wide → use it to trigger a conversation, not to end one

### Evidence Strength
Practitioner consensus — CAC, contribution margin, LTV, and payback are standard accounting identities, but the health thresholds (3:1, 12–18 months, Rule of 40) are venture-practitioner heuristics with wide industry variance, not empirical constants; they degrade outside subscription and e-commerce contexts.

### Source
David Skok, "SaaS Metrics 2.0" (unit economics canon); standard venture finance practice.
Provenance: metric set and benchmark structure absorbed from [claude-skill-management-consultant-B1](https://github.com/DogInfantry/claude-skill-management-consultant-B1) FRAMEWORKS.md §Unit Economics (Apache-2.0 license) and [knowledge-skills](https://github.com/deciqAI/knowledge-skills) `unit-economics-cac-ltv-payback` (MIT license); definitions, pitfalls, and thresholds-are-heuristics framing written for kueiku, absorbed 2026-09.
Admission: Build (new entry) — owns per-customer viability math (CAC / LTV / payback); existing financial-analysis entries value companies, not customers.

## Category Guide
## Financial Analysis

**When to use**: Need quantitative judgment on corporate financial performance, valuation, value creation


### Minimum Information Requirements per Methodology

- **DuPont Analysis**: Target company 3-factor data + peer comparison data
- **DCF**: Future cash flow projections + WACC estimate + terminal value assumptions
- **Comparable Company**: Comparable company list + valuation multiple data
- **EVA**: NOPAT + capital cost + invested capital data
- **Unit Economics**: Acquisition spend + new customers acquired + per-customer revenue & variable costs + churn rate or lifespan

### Routing Trigger Signals

- "ROE anomaly cause / financial diagnostics / profitability decomposition" → DuPont Analysis (primary)
- "Enterprise valuation / investment decision / M&A pricing" → DCF (primary)
- "IPO pricing / industry valuation comparison / comparable companies" → Comparable Company (primary)
- "True value creation / performance evaluation / capital efficiency" → EVA (primary)
- "Scale acquisition spend / unit economics health / LTV:CAC / CAC payback" → Unit Economics (primary)

### Common Combinations

- **Enterprise valuation**: DCF (intrinsic value) + Comparable Company (market reference) cross-validation
- **Financial diagnostics**: DuPont Analysis (ROE decomposition) → EVA (value creation verification)
- **Investment decision**: DuPont Analysis (quality assessment) → DCF (valuation) → EVA (holding period value creation)
- **Startup financial health**: Unit Economics (per-customer viability, payback vs runway) → DuPont Analysis (firm-level ROE decomposition)

### Relationship with Quantitative Investment

- **DCF → Factor Investing**: DCF valuation results can build value factors (EP, BP) as factor investing input
- **DCF → Portfolio Optimization**: DCF intrinsic value estimates can serve as expected return input for MVO/Black-Litterman
- **DuPont → ML Stock Selection**: Financial ratios from DuPont analysis can serve as features for ML stock selection
- **EVA → Factor Investing**: Value creation measured by EVA can build quality factors
